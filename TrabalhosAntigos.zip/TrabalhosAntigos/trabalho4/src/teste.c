#include <stdio.h>

#include "circulo.h"

int main() {

    Circulo c = criarCirculo(27, 2, 2, 2, "green", "green");

    double raio = getRCirculo(c);
    setRCirculo(c, 16);

    return 0;
}