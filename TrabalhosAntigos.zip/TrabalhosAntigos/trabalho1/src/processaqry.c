#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lancadores.h"
#include "linha.h"
#include "circulo.h"
#include "texto.h"
#include "retangulo.h"
#include "arvorebin.h"
#include "formas.h"


int tiposort(const char* co, FILE **arq){
    if(strcmp(co, "E+")==0){
        fprintf(*arq,"Método de ordenação: Euclidinana Crescente!\n");
        return 1;
    }
    if(strcmp(co, "E-")==0){
        fprintf(*arq,"Método de ordenação: Euclidinana Decrescente!\n");
        return 2;
    }
    if(strcmp(co, "L+")==0){
        fprintf(*arq,"Método de ordenação: Manhattan Crescente!\n");
        return 3;
    }
    if(strcmp(co, "L-")==0){
        fprintf(*arq,"Método de ordenação: Manhattan Decrescente!\n");
        return 4;
    }
    if(strcmp(co, "A+")==0){
        fprintf(*arq,"Método de ordenação: Área Crescente!\n");
        return 5;
    }
    if(strcmp(co, "A-")==0){
        fprintf(*arq,"Método de ordenação: Área Decrescente!\n");
        return 6;
    }
    return 1;
}

LANC get_LANCpornum(LANC L0, LANC L1, LANC L2,LANC L3, LANC L4, LANC L5, LANC L6, LANC L7, LANC L8, LANC L9, int l){
    if(l==0){
        return L0;
    }
    if(l==1){
        return L1;
    }
    if(l==2){
        return L2;
    }
    if(l==3){
        return L3;
    }
    if(l==4){
        return L4;
    }
    if(l==5){
        return L5;
    }
    if(l==6){
        return L6;
    }
    if(l==7){
        return L7;
    }
    if(l==8){
        return L8;
    }
    return L9;
}

void leitura_qry(FILE *arqqry, FILE **stxt, FILE **ssvg2, int *instru, int *formcriadas, int *id, AbdTree a1, float *xcent, float *ycent){
    float pontos=0, graus[10];
    int formascriadas=*formcriadas, formasdestruidas=0, numlancamentos=0;
    LANC L0=cria_lanc(0), L1=cria_lanc(1), L2=cria_lanc(2), L3=cria_lanc(3), L4=cria_lanc(4), L5=cria_lanc(5), L6=cria_lanc(6), L7=cria_lanc(7), L8=cria_lanc(8), L9=cria_lanc(9);
    char* str = (char*)malloc(100 * sizeof(char));
    char* tipo = (char*)malloc(4 * sizeof(char));
    while(fgets(str, 100, arqqry)){
        strncpy(tipo, str, 4);  
        tipo[3] = '\0';
        if(strcmp(tipo, "rt ")==0){
            int l;
            float g;
            sscanf(str + 3, "%d %f", &l, &g);
            graus[l]=g;
            printatxt_cabecalhort(stxt, l, g);
            fprintf(*stxt, "\n");
        }
        if(strcmp(tipo, "sel")==0){
            int l, sort;
            char t;
            float dmin, dmax;
            char* co= (char*)malloc(3 * sizeof(char));
            sscanf(str + 4, "%d %c %f %f %s", &l, &t, &dmin, &dmax, co);
            printatxt_cabecalhosel(stxt, l, t, dmin, dmax, co);
            sort=tiposort(co, stxt);
            carrega_lancador(get_LANCpornum(L0, L1, L2, L3, L4, L5, L6, L7, L8, L9, l), a1,dmin, dmax, stxt, sort, t, *xcent, *ycent);
        }
        if(strcmp(tipo,"lc ")==0){
            int l;
            numlancamentos++;
            float d;
            sscanf(str + 3, "%d %f", &l, &d);
            printatxt_cabecalholc(stxt, l, d);
            faz_lancamento(L0,L1,L2,L3,L4,L5,L6,L7,L8,L9, get_LANCpornum(L0, L1, L2, L3, L4, L5, L6, L7, L8, L9, l),ssvg2, stxt, d, a1, *xcent, *ycent, &pontos, &formascriadas, &formasdestruidas, id, graus[l]);
        }

        *instru=*instru+1;
    }
    percursoSimetrico(a1, &printasvg, ssvg2);

    fprintf(*stxt, "RESULTADO FINAL:\nPONTUAÇÃO FINAL: %0.2f\nNÚMERO DE INSTRUÇÕES EXECUTADAS: %d\nNÚMERO DE LANÇAMENTOS: %d\nNÚMERO DE FORMAS DESTRUÍDAS: %d\nNÚMERO DE FORMAS CRIADAS: %d\n", pontos, *instru,numlancamentos, formasdestruidas,formascriadas);
}

void processa_qry(const char* pathqry, const char* dirsaida, const char* nomearqsaida, const char* nomeqry, int *instru, int *formcriadas, int *id, AbdTree a1, float *xcent, float *ycent){

    char* pathqry2=(char*)malloc(sizeof(char)*(strlen(pathqry)+6+strlen(nomeqry)));
    pathqry2[0]='\0';
    strcpy(pathqry2, pathqry);
    strcat(pathqry2, nomeqry);
    printf("Diretório do arquivo qry: %s\n", pathqry2);
    FILE* arqqry = fopen(pathqry2, "r");
    if (arqqry==NULL) {
        fprintf(stderr, "Erro na abertura do arquivo QRY: %s\n", pathqry2);
        fclose(arqqry);
        exit(1);
    }
    printf("Diretorio de saida: %s\n", dirsaida);
    char saidasvg2[512];
    saidasvg2[0]='\0';
    strcat(saidasvg2, dirsaida);
    strcat(saidasvg2, nomearqsaida);
    strcat(saidasvg2, ".svg");

    char saidatxt[512];
    saidatxt[0]='\0';
    strcat(saidatxt, dirsaida);
    strcat(saidatxt, nomearqsaida);
    strcat(saidatxt, ".txt");
    printf("Diretório do arquivo svg2: %s\nDiretório do arquivo txt: %s\n", saidasvg2, saidatxt);
    FILE* ssvg2 = fopen(saidasvg2, "w");
    if (ssvg2==NULL) {
        fprintf(stderr, "Erro na criação do arquivo SVG: %s\n", saidasvg2);
        fclose(arqqry);
        fclose(ssvg2);
        exit(1);
    }

    fprintf(ssvg2, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    fprintf(ssvg2, "<svg width=\"2000\" height=\"2000\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\">\n");

    FILE* stxt = fopen(saidatxt, "w");
    if (stxt==NULL) {
        fprintf(stderr, "Erro na criação do arquivo TXT: %s\n", saidatxt);
        fclose(arqqry);
        fclose(ssvg2);
        fclose(stxt);
        exit(1);
    }

    leitura_qry(arqqry, &stxt, &ssvg2,instru, formcriadas, id, a1, xcent, ycent);

    fprintf(ssvg2, "</svg>\n");
    fclose(arqqry);
    fclose(ssvg2);
    fclose(stxt);
}

