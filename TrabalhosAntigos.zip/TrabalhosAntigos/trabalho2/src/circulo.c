#include "circulo.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "math.h"

#define M_PI 3.14159265358979323846

typedef struct Circ {
    int i;
    double x, y, r;
    char *corb, *corp;
} Circ;

Circle createCircle(int id, double x, double y, double r, char *corb, char *corp) {
    Circ *c = malloc(sizeof(Circ));
    if (c == NULL) {
        printf("Erro na alocação de memória na criação do círculo.");
        exit(1);
    }

    c->i = id;
    c->x = x;
    c->y = y;
    c->r = r;
    c->corb = (char*)malloc(strlen(corb)+1);
    if(c->corb == NULL) {
        printf("Erro na alocação de memória para a cor de borda.");
        exit(1);
    }
    strcpy(c->corb, corb);

    c->corp = (char*)malloc(strlen(corp)+1);
    if(c->corp == NULL) {
        printf("Erro na alocação de memória para a cor de preenchimento.");
        exit(1);
    }
    strcpy(c->corp, corp);

    
    return ((Circ*)c);
}

int getIdCircle (Circle c) {
    return ((Circ*)c)->i;
}

double getXCircle(Circle c) {
    return ((Circ*)c)->x;
}

double getYCircle(Circle c) {
    return ((Circ*)c)->y;
}

double getRCircle(Circle c) {
    return ((Circ*)c)->r;
}

double calcAreaCircle(double r) {
    return M_PI*pow(r, 2);
}

char *getCorbCircle(Circle c) {
    return ((Circ*)c)->corb;
}

char *getCorpCircle(Circle c) {
    return ((Circ*)c)->corp;
}

void setXCircle(Circle c, double x) {
    ((Circ*)c)->x = x;
}

void setYCircle(Circle c, double y) {
    ((Circ*)c)->y = y;
}

void setRCircle(Circle c, double radius) {
    ((Circ*)c)->r = radius;
}

void setCorbCircle(Circle c, char *corB) {
    strcpy(((Circ*)c)->corb, corB);
}

void setCorpCircle(Circle c, char *corP) {
    strcpy(((Circ*)c)->corp, corP);
}



