#ifndef FUNCOESARQUIVO_H
#define FUNCOESARQUIVO_H

#include <stdio.h>
#include <stdlib.h>
#include "lancador.h"
#include "texto.h"

typedef FILE File;
typedef void *Queue;

/**
 * @brief Abre um arquivo para leitura.
 * 
 * @param f Ponteiro para o arquivo que será aberto.
 * @param geoPath Caminho para o arquivo a ser aberto.
 * 
 * @details
 * A função tenta abrir o arquivo especificado no modo de leitura ("r").
 * Caso não consiga abrir o arquivo, exibe uma mensagem de erro e encerra o programa.
 */

void openFile(File **f, char *geoPath);

/**
 * @brief Lê e processa as linhas de um arquivo de entrada.
 * 
 * @param f Ponteiro para o arquivo de entrada.
 * @param lRect Lançador de retângulos.
 * @param lCircle Lançador de círculos.
 * @param lLine Lançador de linhas.
 * @param lText Lançador de textos.
 * @param ts Estilo de texto.
 * @param s Ponteiro para o arquivo SVG de saída.
 * @param id Ponteiro para armazenar o último ID lido.
 * @param createdForms Ponteiro para armazenar a quantidade de formas criadas
 *  
 * @details
 * A função lê o arquivo linha por linha, identifica o tipo de forma especificado,
 * e chama a função `processLineForms` para processar a linha.
 * Após processar todas as linhas, o arquivo é fechado.
 * 
 * @warning Exibe uma mensagem de erro se o arquivo não estiver aberto.
 */

void readFile(File *f, Launcher *lRect, Launcher *lCircle, Launcher *lLine, Launcher *lText, TxtStyle *ts, File *s, int *id, int *createdForms);

/**
 * @brief Processa uma linha do arquivo e cria objetos com base no tipo especificado.
 * 
 * @param line Linha a ser processada.
 * @param tipoArquivo Tipo de forma representado pela linha (e.g., "r", "c", "l", "t", "ts").
 * @param qRect Fila de retângulos.
 * @param qCircle Fila de círculos.
 * @param qText Fila de textos.
 * @param qLine Fila de linhas.
 * @param ts Estilo de texto.
 * @param s Ponteiro para o arquivo SVG de saída.
 * @param idFormas Ponteiro para armazenar o ID do último objeto criado.
 * @param createdForms Ponteiro para armazenar a quantidade de formas criadas
 * 
 * @details
 * A função utiliza o tipo da forma para identificar o que deve ser feito com a linha.
 * Dependendo do tipo:
 * - "t" (texto): Cria um texto e o insere na fila de textos.
 * - "c" (círculo): Cria um círculo e o insere na fila de círculos.
 * - "r" (retângulo): Cria um retângulo e o insere na fila de retângulos.
 * - "l" (linha): Cria uma linha e a insere na fila de linhas.
 * - "ts" (estilo de texto): Atualiza o estilo de texto global.
 * 
 * Se o tipo da linha não for reconhecido, exibe uma mensagem de aviso.
 */

void processLineForms(char *line, char *tipoArquivo, Queue *qRect, Queue *qCircle, Queue *qText, Queue *qLine, TxtStyle *ts, File *s, int *id, int *createdForms);

#endif