#include "stdio.h"
#include "string.h"
#include "math.h"
#include "stdbool.h"

bool rectangleIntersection(double x1, double y1, double w1, double h1, double x2, double y2, double w2, double h2) {
    return !(x1 + w1 < x2 || x2 + w2 < x1 || y1 + h1 < y2 || y2 + h2 < y1);
}

bool circleIntersection(double x1, double y1, double r1, double x2, double y2, double r2) {
    double dx = x1 - x2;
    double dy = y1 - y2;
    double distancia = sqrt(dx * dx + dy * dy);
    return distancia <= (r1 + r2);
}

bool circleRectangleIntersection(double cx, double cy, double r, double rx, double ry, double rw, double rh) {
    double ponto_mais_proximo_x = fmax(rx, fmin(cx, rx + rw));
    double ponto_mais_proximo_y = fmax(ry, fmin(cy, ry + rh));
    double dx = cx - ponto_mais_proximo_x;
    double dy = cy - ponto_mais_proximo_y;
    return (dx * dx + dy * dy) <= (r * r);
}

bool linesIntersection(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4) {
    double det = (x2 - x1) * (y4 - y3) - (y2 - y1) * (x4 - x3);
    if (det == 0) return false; 

    double u = ((x3 - x1) * (y4 - y3) - (y3 - y1) * (x4 - x3)) / det;
    double v = ((x3 - x1) * (y2 - y1) - (y3 - y1) * (x2 - x1)) / det;

    return (u >= 0 && u <= 1 && v >= 0 && v <= 1);
}

bool lineRectangleIntersection(double lx1, double ly1, double lx2, double ly2, double rx, double ry, double rw, double rh) {
    double r1x = rx, r1y = ry;
    double r2x = rx + rw, r2y = ry;
    double r3x = rx + rw, r3y = ry + rh;
    double r4x = rx, r4y = ry + rh;

    // Verificar interseção com cada aresta
    return linesIntersection(lx1, ly1, lx2, ly2, r1x, r1y, r2x, r2y) ||
           linesIntersection(lx1, ly1, lx2, ly2, r2x, r2y, r3x, r3y) ||
           linesIntersection(lx1, ly1, lx2, ly2, r3x, r3y, r4x, r4y) ||
           linesIntersection(lx1, ly1, lx2, ly2, r4x, r4y, r1x, r1y);
}

bool lineCircleIntersection(double lx1, double ly1, double lx2, double ly2, double cx, double cy, double r) {
    double dx = lx2 - lx1;
    double dy = ly2 - ly1;

    // Parâmetros da projeção
    double t = ((cx - lx1) * dx + (cy - ly1) * dy) / (dx * dx + dy * dy);

    // Limitar t ao segmento da linha
    t = fmax(0, fmin(1, t));

    // Coordenadas do ponto mais próximo
    double px = lx1 + t * dx;
    double py = ly1 + t * dy;

    // Distância entre o ponto mais próximo e o centro do círculo
    double distancia = sqrt((px - cx) * (px - cx) + (py - cy) * (py - cy));
    return distancia <= r;
}

bool textLineIntersection(double tx, double ty, int num_caracteres, double lx1, double ly1, double lx2, double ly2, char tipo) {
    double comprimento = 10.0 * num_caracteres;
    double t1x, t1y, t2x, t2y;

    if (tipo == 'i') { // Âncora no início
        t1x = tx;
        t2x = tx + comprimento;
    } else if (tipo == 'm') { // Âncora no meio
        t1x = tx - comprimento / 2;
        t2x = tx + comprimento / 2;
    } else { // Âncora no fim ('f')
        t1x = tx - comprimento;
        t2x = tx;
    }
    t1y = t2y = ty;

    return linesIntersection(t1x, t1y, t2x, t2y, lx1, ly1, lx2, ly2);
}

bool textIntersection(double tx, double ty, int num_caracteres,  char tipo, double t2x, double t2y, int num_caracteres2,  char tipo2) {
    double comprimento = 10.0 * num_caracteres;
    double tx1, ty1, tx2, ty2, t2x1, t2y1, t2x2, t2y2;

    if (tipo == 'i') { // Âncora no início
        tx1 = tx;
        tx2 = tx + comprimento;
    } else if (tipo == 'm') { // Âncora no meio
        tx1 = tx - comprimento / 2;
        tx2 = tx + comprimento / 2;
    } else { // Âncora no fim ('f')
        tx1 = tx - comprimento;
        tx2 = tx;
    }
    ty1 = ty2 = ty;

    if (tipo2 == 'i') { // Âncora no início
        t2x1 = tx;
        t2x2 = tx + comprimento;
    } else if (tipo == 'm') { // Âncora no meio
        t2x1 = tx - comprimento / 2;
        t2x2 = tx + comprimento / 2;
    } else { // Âncora no fim ('f')
        t2x1 = tx - comprimento;
        t2x2 = tx;
    }
    t2y1 = t2y2 = ty;

    return linesIntersection(tx1, ty1, tx2, ty2, t2x1, t2y1, t2x2, t2y2);
}


bool textRectangleIntersection(double tx, double ty, int num_caracteres, double rx, double ry, double rw, double rh, char tipo) {
    double comprimento = 10.0 * num_caracteres;
    double t1x, t1y, t2x, t2y;

    if (tipo == 'i') { // Âncora no início
        t1x = tx;
        t2x = tx + comprimento;
    } else if (tipo == 'm') { // Âncora no meio
        t1x = tx - comprimento / 2;
        t2x = tx + comprimento / 2;
    } else { // Âncora no fim ('f')
        t1x = tx - comprimento;
        t2x = tx;
    }
    t1y = t2y = ty;


    return lineRectangleIntersection(t1x, t1y, t2x, t2y, rx, ry, rw, rh);
}

bool textCircleIntersection(double tx, double ty, int num_caracteres, double cx, double cy, double r, char tipo) {
    double comprimento = 10.0 * num_caracteres;
    double t1x, t1y, t2x, t2y;

    if (tipo == 'i') { // Âncora no início
        t1x = tx;
        t2x = tx + comprimento;
    } else if (tipo == 'm') { // Âncora no meio
        t1x = tx - comprimento / 2;
        t2x = tx + comprimento / 2;
    } else { // Âncora no fim ('f')
        t1x = tx - comprimento;
        t2x = tx;
    }
    t1y = t2y = ty;

    return lineCircleIntersection(t1x, t1y, t2x, t2y, cx, cy, r);
}