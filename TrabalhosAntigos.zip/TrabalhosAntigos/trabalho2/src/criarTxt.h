#ifndef CRIARTXT_H
#define CRIARTXT_H

#include <stdio.h>
#include <stdlib.h>
#include "retangulo.h"
#include "circulo.h"
#include "linha.h"
#include "texto.h"

typedef FILE File;
typedef void *Forma;

/**
 * @brief Abre um arquivo de texto para gravação.
 * 
 * @param saida Ponteiro duplo para o endereço do arquivo.
 * @param exitPath Ponteiro para o caminho onde será salvo o arquivo de texto.
 * 
 * @details
 * A função tenta abrir o arquivo especificado pelo caminho `exitPath` no modo de gravação (`"w"`).
 * Caso não seja possível abrir o arquivo, exibe uma mensagem de erro e encerra o programa com `exit(1)`.
 * 
 * @note Certifique-se de fechar o arquivo após a gravação para evitar vazamentos de memória.
 * @warning Se o arquivo não puder ser aberto, o programa será encerrado.
 */

void openTxtFile(File **saida, char *exitPath);

/**
 * @brief Imprime um comando no arquivo de texto.
 * 
 * @param saida Ponteiro duplo para o arquivo de saída.
 * @param command String contendo o comando a ser registrado.
 * 
 * @details
 * A função registra no arquivo o comando recebido, precedido por um indicador `[ * ]`.
 */

void printCommandLine(File **saida, char *command);

/**
 * @brief Imprime a posição do lançador no arquivo de texto.
 * 
 * @param saida Ponteiro duplo para o arquivo de saída.
 * @param degree Ângulo de abertura do lançador.
 * @param formType Tipo da forma associada ao lançador.
 * 
 * @details A função escreve o tipo de forma e o ângulo de abertura do lançador no arquivo de texto.
 */

void printPositionLauncher(File **saida, int degree, char *formType); 

/**
 * @brief Imprime informações sobre o alvo no arquivo de texto.
 * 
 * @param saida Ponteiro duplo para o arquivo de saída.
 * @param typeTarget Tipo do alvo, identificado por um código numérico.
 * 
 * @details
 * A função utiliza a função `returnNameLauncher` para obter o nome do alvo correspondente ao código
 * e escreve no arquivo de texto.
 */

void printTargetInfo(File **saida, int typeTarget);

/**
 * @brief Imprime informações sobre a ogiva no arquivo de texto.
 * 
 * @param saida Ponteiro duplo para o arquivo de saída.
 * @param typeWarhead Tipo da ogiva, identificado por um código numérico.
 * 
 * @details
 * A função utiliza a função `returnNameLauncher` para obter o nome da ogiva correspondente ao código
 * e escreve no arquivo de texto.
 */

void printWarheadInfo(File **saida, int typeWarhead);

/**
 * @brief Retorna o nome associado a um código de lançador.
 * 
 * @param type Código numérico que identifica o tipo de lançador.
 * @return String contendo o nome do lançador.
 * 
 * @details
 * A função mapeia códigos numéricos a tipos de lançadores, como Retângulo, Círculo, Linha e Texto.
 * Retorna NULL se o código não for reconhecido.
 */

char *returnNameLauncher(int type);

/**
 * @brief Imprime informações sobre um círculo no arquivo de texto.
 * 
 * @param saida Ponteiro duplo para o arquivo de saída.
 * @param id ID do círculo.
 * @param x Coordenada X do círculo.
 * @param y Coordenada Y do círculo.
 * @param r Raio do círculo.
 * @param corb Cor da borda do círculo.
 * @param corp Cor de preenchimento do círculo.
 * 
 * @details
 * A função registra no arquivo os dados do círculo, incluindo suas coordenadas,
 * raio e cores de borda e preenchimento.
 */

void printCircleInfo(File **saida, int id, double x, double y, double r, char *corb, char *corp);

/**
 * @brief Imprime informações sobre um retângulo no arquivo de texto.
 * 
 * @param saida Ponteiro duplo para o arquivo de saída.
 * @param id ID do retângulo.
 * @param x Coordenada X do retângulo.
 * @param y Coordenada Y do retângulo.
 * @param h Altura do retângulo.
 * @param w Largura do retângulo.
 * @param corb Cor da borda do retângulo.
 * @param corp Cor de preenchimento do retângulo.
 * 
 * @details
 * A função registra no arquivo os dados do retângulo, incluindo suas coordenadas,
 * dimensões e cores de borda e preenchimento.
 */

void printRectInfo(File **saida, int id, double x, double y, double h, double w, char *corb, char *corp);

/**
 * @brief Imprime informações sobre uma linha no arquivo de texto.
 * 
 * @param saida Ponteiro duplo para o arquivo de saída.
 * @param id ID da linha.
 * @param x Coordenada X inicial da linha.
 * @param y Coordenada Y inicial da linha.
 * @param x2 Coordenada X final da linha.
 * @param y2 Coordenada Y final da linha.
 * @param cor Cor da linha.
 * 
 * @details
 * A função registra no arquivo os dados da linha, incluindo suas coordenadas iniciais
 * e finais, além da cor.
 */

void printLineInfo(File **saida, int id, double x, double y, double x2, double y2, char *cor);

/**
 * @brief Imprime informações sobre um texto no arquivo de texto.
 * 
 * @param saida Ponteiro duplo para o arquivo de saída.
 * @param id ID do texto.
 * @param x Coordenada X do texto.
 * @param y Coordenada Y do texto.
 * @param corb Cor da borda do texto.
 * @param corp Cor de preenchimento do texto.
 * @param a Âncora do texto.
 * @param txto Conteúdo do texto.
 * 
 * @details
 * A função registra no arquivo os dados do texto, incluindo suas coordenadas,
 * cores, âncora e conteúdo textual.
 */

void printTextInfo(File **saida, int id, double x, double y, char *corb, char *corp, char *a, char *txto);

/**
 * @brief Imprime as coordenadas finais de uma linha no arquivo de texto.
 * 
 * @param saida Ponteiro duplo para o arquivo de saída.
 * @param form Nome da linha.
 * @param x1 Coordenada X inicial.
 * @param y1 Coordenada Y inicial.
 * @param x2 Coordenada X final.
 * @param y2 Coordenada Y final.
 * 
 * @details
 * A função registra no arquivo as coordenadas iniciais e finais de uma linha especificada.
 */

void printFinalCoord(File **saida, char *form, double x, double y);

/**
 * @brief Registra o status final do lançamento no arquivo de texto.
 * 
 * @param saida Ponteiro duplo para o arquivo de saída.
 * @param targetSituation Situação do alvo.
 * @param warheadSituation Situação da ogiva.
 * @param launchSituation Situação do lançamento.
 * 
 * @details
 * A função registra no arquivo o status final de um lançamento, incluindo informações
 * sobre o alvo, a ogiva e o próprio lançamento.
 */

void printFinalCoordLine(File **saida, char *form, double x1, double y1, double x2, double y2);

/**
 * @brief Registra o status final do lançamento no arquivo de texto.
 * 
 * @param saida Ponteiro duplo para o arquivo de saída.
 * @param targetSituation Situação do alvo.
 * @param warheadSituation Situação da ogiva.
 * @param launchSituation Situação do lançamento.
 * 
 * @details
 * A função registra no arquivo o status final de um lançamento, incluindo informações
 * sobre o alvo, a ogiva e o próprio lançamento.
 */

void finalStatusLaunch(File **saida, char *target, char *warhead, char *launchSituation);

/**
 * @brief Registra os resultados finais do jogo no arquivo de texto.
 * 
 * @param saida Ponteiro duplo para o arquivo de saída.
 * @param pont Pontuação final do jogo.
 * @param instructions Número total de instruções processadas.
 * @param totalLaunch Número total de lançamentos realizados.
 * @param destroyedForms Número de formas destruídas.
 * @param createdForms Número de formas criadas.
 * 
 * @details
 * A função registra no arquivo os resultados finais do jogo, incluindo pontuação,
 * estatísticas de instruções, lançamentos, formas criadas e destruídas.
 */

void printGameResults(File **saida, double pont, int instructions, int totalLaunch, int destroyedForms, int createdForms);

#endif