#ifndef TEXTO_H
#define TEXTO_H

typedef void *Text;
typedef void *TxtStyle;

/**
 * @brief Cria um círculo com os atributos especificados.
 * 
 * @param family string referente à font-family.
 * @param weight string referente à font-weight.
 * @param size string referente à font-size.
 * 
 * @return Um ponteiro para o objeto `TxtStyle` criado.
 * 
 * @details
 * A função aloca memória para uma nova definição de estilo e inicializa seus atributos.
 * Se ocorrer erro na alocação de memória, o programa será encerrado com uma mensagem de erro.
 */

TxtStyle createTxtStyle(char *family, char *weight, char *size);

/**
 * @brief Cria um texto com os atributos especificados.
 * 
 * @param id Identificador único do texto.
 * @param x Coordenada x do texto.
 * @param y Coordenada y do texto.
 * @param corb Cor da borda do texto.
 * @param corp Cor de preenchimento do texto.
 * @param a Âncora do texto.
 * @param txto Conteúdo do texto.
 * 
 * @return Um ponteiro para o objeto `Text` criado.
 * 
 * @details
 * A função aloca memória para um novo texto e inicializa seus atributos.
 * Se ocorrer erro na alocação de memória, o programa será encerrado com uma mensagem de erro.
 */

Text createText(int id, double x, double y, char *corb, char *corp, char *a, char *txto);

// Funções para txtStyle

/**
 * @brief Pega a font-family do texto.
 * 
 * @param tS O text style do qual será pego a font-family.
 * 
 * @return O font-family da forma.  
 * 
*/

char *getFamily(TxtStyle tS);

/**
 * @brief Pega a font-weight do texto.
 * 
 * @param tS O text style do qual será pego o font-weight.
 * 
 * @return O font-weight da forma.  
 * 
*/

char *getWeight(TxtStyle tS);

/**
 * @brief Pega o font-size do texto.
 * 
 * @param tS O text style do qual será pego o font-size.
 * 
 * @return O font-size da forma.  
 * 
*/

char *getSize(TxtStyle tS);

/**
 * @brief Pega o id do texto.
 * 
 * @param t O texto do qual será pego o id.
 * 
 * @return O id da forma.  
 * 
*/

int getIdText (Text t);

/**
 * @brief Pega a coordenada x do texto.
 * 
 * @param t O texto do qual será pego a coordenada x.
 * 
 * @return A coordenada x da forma.  
 * 
*/

double getXText(Text t);

/**
 * @brief Pega a coordenada y do texto.
 * 
 * @param t O texto do qual será pego a coordenada y.
 * 
 * @return A coordenada y da forma.  
 * 
*/

double getYText(Text t);

/**
 * @brief Calcula a área do texto.
 * 
 * @param txto O conteúdo do texto.
 * 
 * @return O valor da área da forma.  
 * 
*/

double calcAreaText(char *txto);

/**
 * @brief Pega a cor de borda do texto.
 * 
 * @param t O texto do qual será pego a cor de borda.
 * 
 * @return Uma string com a cor de borda da forma.  
 * 
*/

char *getCorbText(Text t);

/**
 * @brief Pega a cor de preenchimento do texto.
 * 
 * @param t O texto do qual será pego a cor de preenchimento.
 * 
 * @return Uma string com a cor de preenchimento da forma.  
 * 
*/

char *getCorpText(Text t);

/**
 * @brief Pega a âncora do texto.
 * 
 * @param t O texto do qual será pego a sua âncora.
 * 
 * @return Uma string com a âncora da forma.  
 * 
*/

char *getAText(Text t);

/**
 * @brief Pega o conteúdo do texto.
 * 
 * @param t O texto do qual será pego o conteúdo.
 * 
 * @return Uma string com o conteúdo da forma.  
 * 
*/

char *getTxtoText(Text t);

/**
 * @brief Define o valor da coordenada X do texto.
 * 
 * @param t O texto do qual será definido a coordenada x.
 * @param x O novo valor para a coordenada x.
*/

void setXText(Text t, double x);

/**
 * @brief Define o valor da coordenada Y do texto.
 * 
 * @param t O texto do qual será definido a coordenada y.
 * @param y O novo valor para a coordenada y.
*/

void setYText(Text t, double y);

/**
 * @brief Define a string da cor da borda do texto.
 * 
 * @param t O texto do qual será definido a cor da borda.
 * @param corB O novo valor para a cor da borda.
*/

void setCorbText(Text t, char *corB);

/**
 * @brief Define a string da cor de preenchimento do texto.
 * 
 * @param t O texto do qual será definido a cor de preenchimento.
 * @param corP O novo valor para a cor de preenchimento.
*/

void setCorpText(Text t, char *corP);

/**
 * @brief Define a âncora do texto.
 * 
 * @param t O texto do qual será definido a cor de preenchimento.
 * @param a O novo valor para a âncora .
*/

void setAText(Text t, char *a);

/**
 * @brief Define a âncora do texto.
 * 
 * @param t O texto do qual será definido o seu conteúdo.
 * @param txto O novo conteúdo da forma.
*/

void setTxtoText(Text t, char *txto);

/**
 * @brief Define a font-family do texto.
 * 
 * @param tS O texto do qual será definido a sua font-family.
 * @param family A nova font-family.
*/

void setFamily(TxtStyle tS, char *family);

/**
 * @brief Define a font-weight do texto.
 * 
 * @param tS O texto do qual será definido o seu font-weight.
 * @param weight O novo font-weight.
*/

void setWeight(TxtStyle tS, char *weight);

/**
 * @brief Define o font-size do texto.
 * 
 * @param tS O texto do qual será definido o seu font-size.
 * @param size O novo font-size.
*/

void setSize(TxtStyle tS, char *size);

#endif