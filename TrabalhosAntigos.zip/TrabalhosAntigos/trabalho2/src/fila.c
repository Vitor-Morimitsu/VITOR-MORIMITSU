#include "fila.h"
#include "stdio.h"
#include "stdlib.h"
#include "criarSVG.h"
#include "texto.h" 
#include "lancador.h"

typedef void *form;

typedef struct aux 
{
    form *form;
    char type;
    struct aux *next
} Aux;

typedef struct queue
{
    Aux *first;
    Aux *last;
    int size;
} queueC;

Queue createQueue() {
    queueC *q = malloc(sizeof(queueC)); 
    if (q == NULL) {
        printf("Falha na alocação de memória!\n");
        exit(1); 
    }

    q->first = NULL;
    q->last = NULL;
    q->size = 0;

    return ((queueC*)q);
}

void insertQueue(Queue *queue, Form f) {
    queueC *q = ((queueC *)queue);
    
    // printf("\n%d\n", getIdCircle(getFirstElement(q)));

    Aux *newForm = (Aux *)malloc(sizeof(Aux));
    if (newForm == NULL) {
        printf("Falha na alocação de memória!");
    }

    newForm->form = f;
    newForm->next = NULL;

   

    if (q->last == NULL) {  
        q->first = newForm;
        q->last = newForm;
    } else {
        q->last->next = newForm;     
        q->last = newForm;
    }
    q->size++;
}

Queue getFirstElement(Queue *queue) {
    queueC *q = ((queueC *)queue);
    if (q->first == NULL) {
        return NULL;
    }
    // printf("ID: %d\n", getIdCircle(q->first->form));
    return q->first->form;
}

Form getNextElement(Queue *queue) {
    queueC *q = ((queueC *)queue);
    if (q->first == NULL || q->first->next == NULL) {
        printf("Não há elementos suficientes na fila.");
        return NULL;
    }
    return q->first->next->form;
}

void withdrawQueue(Queue *queue) {
    queueC *q = ((queueC *)queue);
    if (q->first == NULL) {
        printf("A fila está vazia!");
        exit(1);
    }

    Aux *firstElement = q->first;
    
    q->first = q->first->next;
    if (q->first == NULL) {
        q->last = NULL;
    }
    free(firstElement);
    q->size--;
}

void killQueue(Queue *queue) {
    queueC *q = ((queueC *)queue);
 
    Aux *currentElement = q->first;

    while (currentElement != NULL) {
        Aux *nextElement = currentElement->next;
        free(currentElement);
        currentElement = nextElement;
    }

    q->first = NULL;
    q->last = NULL;
    q->size = 0;
}

void passthroughQueue(Queue *queue, int queueType, File *s, TxtStyle ts) {
    queueC *q = ((queueC *)queue);
    Aux *currentElement = q->first;

    while (currentElement != NULL) {
        selectQueue(currentElement->form, queueType, s, ts);
        Aux *nextElement = currentElement->next;
        currentElement = nextElement;
    }
}

void selectQueue (Form *f, int queueType, File *s, TxtStyle ts) {
    switch (queueType)
    {
    case 1:
        insertRectSVG(s, f);
        break;
    case 2:
        insertCircleSVG(s, f);
        break;
    case 3:
        insertLineSVG(s, f);
        break;
    case 4:
        insertTextSVG(s, f, ts);
        break;
    default:
        break;
    }
}