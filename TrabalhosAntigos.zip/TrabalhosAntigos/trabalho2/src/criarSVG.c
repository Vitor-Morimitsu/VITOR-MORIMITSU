#include "criarSVG.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "circulo.h"
#include "retangulo.h"
#include "texto.h"
#include "linha.h"

void openExitFile(File **saida, char *exitPath) {
    *saida = fopen(exitPath, "w");
    if (*saida == NULL) {
        printf("Memória não alocadaaaa!");
        exit(1);
    }
}

void startSVG(File *saida) {
    fprintf(saida, "<svg xmlns:svg=\"http://www.w3.org/2000/svg\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\">\n");
}

void insertCircleSVG(File *saida, Circle c) {
    fprintf(saida, "<circle id=\"%d\" style=\"fill:%s;fill-opacity:0.5;stroke:%s\" r=\"%lf\" cy=\"%lf\" cx=\"%lf\" />\n", getIdCircle(c), getCorpCircle(c), getCorbCircle(c), getRCircle(c), getYCircle(c), getXCircle(c));
}

void insertRectSVG(File *saida, Rectangle r) {
    fprintf(saida, "<rect id=\"%d\" style=\"fill:%s;fill-opacity:0.5;stroke:%s\" height=\"%lf\" width=\"%lf\" y=\"%lf\" x=\"%lf\" />\n", getIdRect(r),getCorpRect(r), getCorbRect(r), getHRect(r), getWRect(r), getYRect(r), getXRect(r));
}

void insertLineSVG(File *saida, Line l) {
    fprintf(saida, "<line id=\"%d\" x1=\"%lf\" y1=\"%lf\" x2=\"%lf\" y2=\"%lf\" stroke=\"%s\" stroke-width=\"2\" />\n", getIdLine(l), getX1Line(l), getY1Line(l), getX2Line(l), getY2Line(l), getCorLine(l));
}

void insertTextSVG(File *saida, Text t, TxtStyle ts) {
    fprintf(saida, "<text id=\"%d\" style=\"font-size:%s;line-height:%s;fill:%s\" font-size=\"5\" y=\"%lf\" x=\"%lf\"> %s </text>\n", getIdText(t), getSize(ts), getFamily(ts), getYText(t), getXText(t), getT(t));
}

void closeSVG(File *saida) {
    fprintf(saida, "</svg>\n");
}

