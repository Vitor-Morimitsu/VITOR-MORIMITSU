#include "lancador.h"
#include "stdio.h"
#include "stdlib.h"
#include "stdbool.h"
#include "string.h"
#include "fila.h"
#include "math.h"
#include "circulo.h"
#include "retangulo.h"
#include "linha.h"
#include "texto.h"
#include "retroceder.h"
#include "colisao.h"
#include "criarTxt.h"

#define M_PI 3.14159265358979323846

typedef struct launcher {
    Queue *q;
    double degree;
    int id;  // 0 - sem forma, 1 - Rectangle, 2 - circle, 3 - line, 4 - text
} launch;

Launcher createLauncher(Queue *q, int id) {
    launch *launc = (launch *)malloc(sizeof(launch));
    if (launc == NULL) {
        printf("Erro na alocação de memória no lançador!");
        exit(1);
    }

    launc->q = q;
    launc->degree = 0.0;
    launc->id = id;
    return launc;
}

Queue getQueueLauncher(Launcher *l) {
    launch *launc = ((launch *)l);
    return launc->q;
}

int getIdLauncher(Launcher *l) {
    return ((launch *)l)->id;
}

double getLauncherDegree(Launcher *l) {
    return ((launch *)l)->degree;
}

void positionLauncher(Launcher *launc, double d, FILE **sTxt) {
    ((launch *)launc)->degree = d;
    selectLauncherType(launc, d, sTxt);
}

void selectLauncherType(Launcher *launc, double d, FILE **sTxt){
    switch (getIdLauncher(launc))
    {
    case 1:
        printPositionLauncher(sTxt, d, "Retângulo");
        break;
    case 2:
        printPositionLauncher(sTxt, d, "Círculo");
        break;
    case 3:
        printPositionLauncher(sTxt, d, "Linha");
        break;
    case 4:
        printPositionLauncher(sTxt, d, "Texto");
        break;
    default:
        break;
    }
}

double calculaDistancia(double degree, double d, int axle) {
    double dResultante;
    switch (axle)
    {
    case 0:
        // Cálculo de DX - Cateto Adjacente
        dResultante = cos(degree * M_PI / 180.0)*d;
        break;
    case 1:
        // Cálculo de DY - Cateto Oposto
        dResultante = sin(degree * M_PI / 180.0)*d;
        break;
    default:
        printf("Eixo não específicado, cálculo não realizado.");
        break;
    }

    return dResultante;
}

void singleLaunch(Launcher *launcRef, double d, FILE **sTxt) {
    // Pegar ângulo de abertura e calcular a posição final, calcular dx e dy
    launch *launc = ((launch*)launcRef); 
    double x, y, x2, y2, nX, nY, nX2, nY2;
    if (!launc || !launc->q) {
        printf("Launcher ou elementos inválidos.\n");
        return;
    }
    double dx = calculaDistancia(launc->degree, d, 0);
    double dy = calculaDistancia(launc->degree, d, 1);

    

    switch (launc->id)
    {
    case 1:
        
        x = getXRect(getFirstElement(getQueueLauncher(launc)));
        y = getYRect(getFirstElement(getQueueLauncher(launc)));
        nX = x + dx;
        nY = y + dy;
        printRectInfo(sTxt, getIdRect(getFirstElement(getQueueLauncher(launc))), getXRect(getFirstElement(getQueueLauncher(launc))), getYRect(getFirstElement(getQueueLauncher(launc))), getHRect(getFirstElement(getQueueLauncher(launc))), getWRect(getFirstElement(getQueueLauncher(launc))), getCorbRect(getFirstElement(getQueueLauncher(launc))), getCorpRect(getFirstElement(getQueueLauncher(launc))));

        setXRect(getFirstElement(launc->q), nX);
        setYRect(getFirstElement(launc->q), nY);
        break;
    case 2:
        x = getXCircle(getFirstElement(launc->q));
        y = getYCircle(getFirstElement(launc->q));
        nX = x + dx;
        nY = y + dy;
        
        printCircleInfo(sTxt, getIdCircle(getFirstElement(getQueueLauncher(launc))), getXCircle(getFirstElement(getQueueLauncher(launc))), getYCircle(getFirstElement(getQueueLauncher(launc))),getRCircle(getFirstElement(getQueueLauncher(launc))), getCorbCircle(getFirstElement(getQueueLauncher(launc))), getCorpCircle(getFirstElement(getQueueLauncher(launc))));

        setXCircle(getFirstElement(launc->q), nX);
        setYCircle(getFirstElement(launc->q), nY);    
        
        break;
    case 3:
        x = getX1Line(getFirstElement(launc->q));
        y = getY1Line(getFirstElement(launc->q));
        x2 = getX2Line(getFirstElement(launc->q));
        y2 = getY2Line(getFirstElement(launc->q));

        nX = x + dx;
        nY = y + dy;
        nX2 = x2 + dx;
        nY2 = y2 + dy;

        printLineInfo(sTxt, getIdLine(getFirstElement(getQueueLauncher(launc))), getX1Line(getFirstElement(getQueueLauncher(launc))), getY1Line(getFirstElement(getQueueLauncher(launc))), getX2Line(getFirstElement(getQueueLauncher(launc))), getY2Line(getFirstElement(getQueueLauncher(launc))), getCorLine(getFirstElement(getQueueLauncher(launc))));

        setX1Line(getFirstElement(launc->q), nX);
        setX2Line(getFirstElement(launc->q), nX2);
        setY1Line(getFirstElement(launc->q), nY);
        setY2Line(getFirstElement(launc->q), nY2);
        break;
    case 4: 
        x = getXText(getFirstElement(launc->q));
        y = getYText(getFirstElement(launc->q));
        nX = x + dx;
        nY = y + dy;

        printTextInfo(sTxt, getIdText(getFirstElement(getQueueLauncher(launc))), getXText(getFirstElement(getQueueLauncher(launc))), getYText(getFirstElement(getQueueLauncher(launc))), getCorbText(getFirstElement(getQueueLauncher(launc))), getCorpText(getFirstElement(getQueueLauncher(launc))), getAText(getFirstElement(getQueueLauncher(launc))), getTxtoText(getFirstElement(getQueueLauncher(launc))));
        
        setXText(getFirstElement(launc->q), nX);
        setYText(getFirstElement(launc->q), nY);
        break;
    default:
        printf("Identificador de forma inválido");
        break;
    }
}

void singleLaunchSameForm(Launcher *launcRef, double d, FILE **sTxt) {
    launch *launc = ((launch*)launcRef); 
    double x, y, x2, y2, nX, nY, nX2, nY2;
    if (!launc || !launc->q) {
        printf("Launcher ou elementos inválidos.\n");
        return;
    }
    double dx = calculaDistancia(launc->degree, d, 0);
    double dy = calculaDistancia(launc->degree, d, 1);
    
    

    switch (launc->id)
    {
    case 1:   
        x = getXRect(getNextElement(launc->q));   
        y = getYRect(getNextElement(launc->q));
        nX = x + dx;
        nY = y + dy;
        
        // printf("\nTeste: %lf\n", getWRect(getNextElement(launc)));

        printRectInfo(sTxt, getIdRect(getNextElement(launc->q)), getXRect(getNextElement(launc->q)), getYRect(getNextElement(launc->q)), getHRect(getNextElement(launc->q)), getWRect(getNextElement(launc->q)), getCorbRect(getNextElement(launc->q)), getCorpRect(getNextElement(launc->q)));
    
        setXRect(getNextElement(launc->q), nX);
        setYRect(getNextElement(launc->q), nY);
        break;
    case 2:
        x = getXCircle(getNextElement(launc->q));
        y = getYCircle(getNextElement(launc->q));
        nX = x + dx;
        nY = y + dy;
        
        printCircleInfo(sTxt, getIdCircle(getNextElement(launc->q)), getXCircle(getNextElement(launc->q)), getYCircle(getNextElement(launc->q)),getRCircle(getNextElement(launc->q)), getCorbCircle(getNextElement(launc->q)), getCorpCircle(getNextElement(launc->q)));

        setXCircle(getNextElement(launc->q), nX);
        setYCircle(getNextElement(launc->q), nY);    
        
        break;
    case 3:
        x = getX1Line(getNextElement(launc->q));
        y = getY1Line(getNextElement(launc->q));
        x2 = getX2Line(getNextElement(launc->q));
        y2 = getY2Line(getNextElement(launc->q));

        nX = x + dx;
        nY = y + dy;
        nX2 = x2 + dx;
        nY2 = y2 + dy;

        printLineInfo(sTxt, getIdLine(getNextElement(launc->q)), getX1Line(getNextElement(launc->q)), getY1Line(getNextElement(launc->q)), getX2Line(getNextElement(launc->q)), getY2Line(getNextElement(launc->q)), getCorLine(getNextElement(launc->q)));

        setX1Line(getNextElement(launc->q), nX);
        setX2Line(getNextElement(launc->q), nX2);
        setY1Line(getNextElement(launc->q), nY);
        setY2Line(getNextElement(launc->q), nY2);
        break;
    case 4: 
        x = getXText(getNextElement(launc->q));
        y = getYText(getNextElement(launc->q));
        nX = x + dx;
        nY = y + dy;

        printTextInfo(sTxt, getIdText(getNextElement(launc->q)), getXText(getNextElement(launc->q)), getYText(getNextElement(launc->q)), getCorbText(getNextElement(launc->q)), getCorpText(getNextElement(launc->q)), getAText(getNextElement(launc->q)), getTxtoText(getNextElement(launc->q)));
        
        setXText(getNextElement(launc->q), nX);
        setYText(getNextElement(launc->q), nY);
        break;
    default:
        printf("Identificador de forma inválido");
        break;
    }

    
}

void doubleLaunch(Launcher *launcA, double dA, Launcher *launcB, double dB, double *pont, int *id, FILE **sTxt, int *destroyedForms, int *createdForms, int repeatedForm) {
    //Lançamento da forma
    printTargetInfo(sTxt, getIdLauncher(launcA));
    singleLaunch(launcA, dA, sTxt);
    //Lançamento da ogiva
    printWarheadInfo(sTxt, getIdLauncher(launcB));
    if (repeatedForm == 0) {
        singleLaunch(launcB, dB, sTxt);
    } else {
        singleLaunchSameForm(launcB, dB, sTxt);
    }

    double areaLA = returnAreaForm(launcA, repeatedForm);
    double areaLO = returnAreaForm(launcB, repeatedForm);

    double topLimit = 0.0;
    double inferiorLimit = 0.0;
    double smallerForm = 0.0;
    int selectedLauncher = 0; //0 -> indefinido; 1 -> launcA; 2 -> launcB

    if (areaLA >= areaLO) {
        topLimit = areaLA + (areaLA*0.1);
        inferiorLimit = areaLA - (areaLA*0.1);
        smallerForm = areaLO;
        selectedLauncher = 1;
    } else if(areaLA <= areaLO) {
        topLimit = areaLO + (areaLO*0.1);
        inferiorLimit = areaLO - (areaLO*0.1);
        smallerForm = areaLA;
        selectedLauncher = 2;
    }

    if (selectedColisionType(launcA, launcB, sTxt) == true) {
        if (smallerForm >= inferiorLimit && smallerForm <= topLimit) {
            targetSimilarWarhead(launcA, dA, launcB, dB, getLauncherDegree(launcA), getLauncherDegree(launcB), id, repeatedForm);
            finalStatusLaunch(sTxt, "clonado", "clonado", "alvo e ogiva de tamanhos similares");
            *createdForms = *createdForms + 2;
        }
        if (selectedLauncher == 1) {
            if (smallerForm < inferiorLimit) {
                targetBiggerThanWarhead(launcA,areaLA, dA, launcB, areaLO, dB, getLauncherDegree(launcA), getLauncherDegree(launcB), repeatedForm);
                finalStatusLaunch(sTxt, "na arena", "na arena", "alvo maior que ogiva");
            }
        } else {
            if (smallerForm < inferiorLimit) {
                targetSmallerThanWarhead(getQueueLauncher(launcA), getQueueLauncher(launcB), pont, areaLA, areaLO, repeatedForm);
                finalStatusLaunch(sTxt, "destruído", "recarregado", "alvo menor que ogiva");
                *destroyedForms = *destroyedForms + 1;
            }
        }
        
    } else {
        miss(getQueueLauncher(launcA), getQueueLauncher(launcB), repeatedForm);
        finalStatusLaunch(sTxt, "recarregado", "destruído", "erro");
        *destroyedForms = *destroyedForms  + 1;
    }
}

double returnAreaForm(Launcher *launc, int repeatedForm) {
    launch *l = ((launch *)launc);

    switch (l->id)
    {
    case 1:
        if (repeatedForm == 0) {
            return calcAreaRect(getWRect(getFirstElement(getQueueLauncher(launc))), getHRect(getFirstElement(getQueueLauncher(launc))));
        } else {
            return calcAreaRect(getWRect(getNextElement(getQueueLauncher(launc))), getHRect(getNextElement(getQueueLauncher(launc))));
        }
        break;
    case 2:
        if (repeatedForm == 0) {
            return calcAreaCircle(getRCircle(getFirstElement(getQueueLauncher(launc))));
        } else {
            return calcAreaCircle(getRCircle(getNextElement(getQueueLauncher(launc))));
        }
        break;
    case 3:
        if (repeatedForm == 0) {
            return calcAreaLine(getX1Line(getFirstElement(getQueueLauncher(launc))), getX2Line(getFirstElement(getQueueLauncher(launc))), getY1Line(getFirstElement(getQueueLauncher(launc))), getY2Line(getFirstElement(getQueueLauncher(launc))));
        } else {
            return calcAreaLine(getX1Line(getNextElement(getQueueLauncher(launc))), getX2Line(getNextElement(getQueueLauncher(launc))), getY1Line(getNextElement(getQueueLauncher(launc))), getY2Line(getNextElement(getQueueLauncher(launc))));
        }
        break;  
    case 4: 
        if (repeatedForm == 0) {
            return calcAreaText(getTxtoText(getFirstElement(getQueueLauncher(launc))));
        } else {
            return calcAreaText(getTxtoText(getNextElement(getQueueLauncher(launc))));
        }
        break;
    default:
        printf("Identificador de forma inválido");
        return 0.0;
        break;
    }
}

bool selectedColisionType(Launcher launcA, Launcher launcB, FILE **sTxt) {
    launch *lA = ((launch *)launcA);
    launch *lB = ((launch *)launcB);

    Queue *qA = getQueueLauncher(launcA);
    Queue *qB = getQueueLauncher(launcB);
    
    if (lA->id == 1 && lB->id == 2) {
        printFinalCoord(sTxt, "Retângulo", getXRect(getFirstElement(getQueueLauncher(launcA))), getYRect(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoord(sTxt, "Círculo", getXRect(getFirstElement(getQueueLauncher(launcB))), getYRect(getFirstElement(getQueueLauncher(launcB))));

        return circleRectangleIntersection(getXCircle(getFirstElement(qB)), getYCircle(getFirstElement(qB)), getRCircle(getFirstElement(qB)), getXRect(getFirstElement(qA)), getYRect(getFirstElement(qA)), getWRect(getFirstElement(qA)), getHRect(getFirstElement(qA)));
    } else if (lA->id == 1 && lB->id == 3) {
        printFinalCoord(sTxt, "Retângulo", getXRect(getFirstElement(getQueueLauncher(launcA))), getYRect(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoordLine(sTxt, "Linha", getX1Line(getFirstElement(getQueueLauncher(launcB))), getY1Line(getFirstElement(getQueueLauncher(launcB))), getX2Line(getFirstElement(getQueueLauncher(launcB))), getY2Line(getFirstElement(getQueueLauncher(launcB))));

        return lineRectangleIntersection(getX1Line(getFirstElement(qB)), getY1Line(getFirstElement(qB)), getX2Line(getFirstElement(qB)), getY2Line(getFirstElement(qB)), getXRect(getFirstElement(qA)), getYRect(getFirstElement(qA)), getWRect(getFirstElement(qA)), getHRect(getFirstElement(qA)));
    } else if (lA->id == 1 && lB->id == 4) {
        printFinalCoord(sTxt, "Retângulo", getXRect(getFirstElement(getQueueLauncher(launcA))), getYRect(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoord(sTxt, "Texto", getXText(getFirstElement(getQueueLauncher(launcB))), getYText(getFirstElement(getQueueLauncher(launcB))));
 
        return textRectangleIntersection(getXText(getFirstElement(qB)), getYText(getFirstElement(qB)), strlen(getTxtoText(getFirstElement(qB))), getXRect(getFirstElement(qA)), getYRect(getFirstElement(qA)), getWRect(getFirstElement(qA)), getHRect(getFirstElement(qA)), *getAText(getFirstElement(qB)));
    } else if (lA->id == 1 && lB->id == 1) {
        printFinalCoord(sTxt, "Retângulo", getXRect(getFirstElement(getQueueLauncher(launcA))), getYRect(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoord(sTxt, "Retângulo", getXRect(getNextElement(getQueueLauncher(launcB))), getYRect(getNextElement(getQueueLauncher(launcB))));

        return rectangleIntersection(getXRect(getFirstElement(getQueueLauncher(launcA))), getYRect(getFirstElement(getQueueLauncher(launcA))), getHRect(getFirstElement(getQueueLauncher(launcA))), getWRect(getFirstElement(getQueueLauncher(launcA))), getXRect(getNextElement(getQueueLauncher(launcB))), getYRect(getNextElement(getQueueLauncher(launcB))), getHRect(getNextElement(getQueueLauncher(launcB))), getWRect(getNextElement(getQueueLauncher(launcB))));
    }

    if (lA->id == 2 && lB->id == 1) {
        printFinalCoord(sTxt, "Círculo", getXCircle(getFirstElement(getQueueLauncher(launcA))), getYCircle(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoord(sTxt, "Retângulo", getXRect(getFirstElement(getQueueLauncher(launcB))), getYRect(getFirstElement(getQueueLauncher(launcB))));

        return circleRectangleIntersection(getXCircle(getFirstElement(qA)), getYCircle(getFirstElement(qA)), getRCircle(getFirstElement(qA)), getXRect(getFirstElement(qB)), getYRect(getFirstElement(qB)), getWRect(getFirstElement(qB)), getHRect(getFirstElement(qB)));
    } else if (lA->id == 2 && lB->id == 3) {
        printFinalCoord(sTxt, "Círculo", getXCircle(getFirstElement(getQueueLauncher(launcA))), getYCircle(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoordLine(sTxt, "Linha", getX1Line(getFirstElement(getQueueLauncher(launcB))), getY1Line(getFirstElement(getQueueLauncher(launcB))), getX2Line(getFirstElement(getQueueLauncher(launcB))), getY2Line(getFirstElement(getQueueLauncher(launcB))));

        return lineCircleIntersection(getX1Line(getFirstElement(qB)), getY1Line(getFirstElement(qB)), getX2Line(getFirstElement(qB)), getY2Line(getFirstElement(qB)), getXCircle(getFirstElement(qA)), getYCircle(getFirstElement(qA)), getRCircle(getFirstElement(qA)));
    } else if (lA->id == 2 && lB->id == 4) {
        printFinalCoord(sTxt, "Círculo", getXCircle(getFirstElement(getQueueLauncher(launcA))), getYCircle(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoord(sTxt, "Texto", getXText(getFirstElement(getQueueLauncher(launcB))), getYText(getFirstElement(getQueueLauncher(launcB))));

        return textCircleIntersection(getXText(getFirstElement(qB)), getYText(getFirstElement(qB)), strlen(getTxtoText(getFirstElement(qB))), getXCircle(getFirstElement(qA)), getYCircle(getFirstElement(qA)), getRCircle(getFirstElement(qA)), *getAText(getFirstElement(qB)));
    } else if (lA->id == 2 && lB->id == 2) {
        printFinalCoord(sTxt, "Círculo", getXCircle(getFirstElement(getQueueLauncher(launcA))), getYCircle(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoord(sTxt, "Círculo", getXCircle(getNextElement(getQueueLauncher(launcB))), getYCircle(getNextElement(getQueueLauncher(launcB))));

        return circleIntersection(getXCircle(getFirstElement(qA)), getYCircle(getFirstElement(qA)), getRCircle(getFirstElement(qA)), getXCircle(getNextElement(qB)), getYCircle(getNextElement(qB)), getRCircle(getNextElement(qB)));
    }

    if (lA->id == 3 && lB->id == 1) {
        printFinalCoordLine(sTxt, "Linha", getX1Line(getFirstElement(getQueueLauncher(launcA))), getY1Line(getFirstElement(getQueueLauncher(launcA))), getX2Line(getFirstElement(getQueueLauncher(launcA))), getY2Line(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoord(sTxt, "Retângulo", getXRect(getFirstElement(getQueueLauncher(launcB))), getYRect(getFirstElement(getQueueLauncher(launcB))));
   
        return lineRectangleIntersection(getX1Line(getFirstElement(qA)), getY1Line(getFirstElement(qA)), getX2Line(getFirstElement(qA)), getY2Line(getFirstElement(qA)), getXRect(getFirstElement(qB)), getYRect(getFirstElement(qB)), getWRect(getFirstElement(qB)), getHRect(getFirstElement(qB)));
    } else if (lA->id == 3 && lB->id == 2) {
        printFinalCoordLine(sTxt, "Linha", getX1Line(getFirstElement(getQueueLauncher(launcA))), getY1Line(getFirstElement(getQueueLauncher(launcA))), getX2Line(getFirstElement(getQueueLauncher(launcA))), getY2Line(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoord(sTxt, "Círculo", getXCircle(getFirstElement(getQueueLauncher(launcB))), getYCircle(getFirstElement(getQueueLauncher(launcB))));

        return lineCircleIntersection(getX1Line(getFirstElement(qA)), getY1Line(getFirstElement(qA)), getX2Line(getFirstElement(qA)), getY2Line(getFirstElement(qA)), getXCircle(getFirstElement(qB)), getYCircle(getFirstElement(qB)), getRCircle(getFirstElement(qB)));
    } else if (lA->id == 3 && lB->id == 4) {
        printFinalCoordLine(sTxt, "Linha", getX1Line(getFirstElement(getQueueLauncher(launcA))), getY1Line(getFirstElement(getQueueLauncher(launcA))), getX2Line(getFirstElement(getQueueLauncher(launcA))), getY2Line(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoord(sTxt, "Texto", getXText(getFirstElement(getQueueLauncher(launcB))), getYText(getFirstElement(getQueueLauncher(launcB))));

        return textLineIntersection(getXText(getFirstElement(qB)), getYText(getFirstElement(qB)), strlen(getTxtoText(getFirstElement(qB))), getX1Line(getFirstElement(qA)), getY1Line(getFirstElement(qA)), getX2Line(getFirstElement(qA)), getY2Line(getFirstElement(qA)), *getAText(getFirstElement(qB)));
    } else if (lA->id == 3 && lB->id == 3) {
        printFinalCoordLine(sTxt, "Linha", getX1Line(getFirstElement(getQueueLauncher(launcA))), getY1Line(getFirstElement(getQueueLauncher(launcA))), getX2Line(getFirstElement(getQueueLauncher(launcA))), getY2Line(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoordLine(sTxt, "Linha", getX1Line(getFirstElement(getQueueLauncher(launcB))), getY1Line(getFirstElement(getQueueLauncher(launcB))), getX2Line(getFirstElement(getQueueLauncher(launcB))), getY2Line(getFirstElement(getQueueLauncher(launcB))));
     
        return linesIntersection(getX1Line(getFirstElement(qA)), getY1Line(getFirstElement(qA)), getX2Line(getFirstElement(qA)), getY2Line(getFirstElement(qA)), getX1Line(getNextElement(qB)), getY1Line(getNextElement(qB)), getX2Line(getNextElement(qB)), getY2Line(getNextElement(qB)));
    }

    if (lA->id == 4 && lB->id == 1) {
        printFinalCoord(sTxt, "Texto", getXText(getFirstElement(getQueueLauncher(launcA))), getYText(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoord(sTxt, "Retângulo", getXRect(getFirstElement(getQueueLauncher(launcB))), getYRect(getFirstElement(getQueueLauncher(launcB))));

        return textRectangleIntersection(getXText(getFirstElement(qA)), getYText(getFirstElement(qA)), strlen(getTxtoText(getFirstElement(qA))), getXRect(getFirstElement(qB)), getYRect(getFirstElement(qB)), getWRect(getFirstElement(qB)), getHRect(getFirstElement(qB)), *getAText(getFirstElement(qA)));
    } else if (lA->id == 4 && lB->id == 2) {
        printFinalCoord(sTxt, "Texto", getXText(getFirstElement(getQueueLauncher(launcA))), getYText(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoord(sTxt, "Círculo", getXCircle(getFirstElement(getQueueLauncher(launcB))), getYCircle(getFirstElement(getQueueLauncher(launcB))));

        return textCircleIntersection(getXText(getFirstElement(qA)), getYText(getFirstElement(qA)), strlen(getTxtoText(getFirstElement(qA))), getXCircle(getFirstElement(qB)), getYCircle(getFirstElement(qB)), getRCircle(getFirstElement(qB)), *getAText(getFirstElement(qA)));
    } else if (lA->id == 4 && lB->id == 3) {
        printFinalCoord(sTxt, "Texto", getXText(getFirstElement(getQueueLauncher(launcA))), getYText(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoordLine(sTxt, "Linha", getX1Line(getFirstElement(getQueueLauncher(launcB))), getY1Line(getFirstElement(getQueueLauncher(launcB))), getX2Line(getFirstElement(getQueueLauncher(launcB))), getY2Line(getFirstElement(getQueueLauncher(launcB))));

        return textLineIntersection(getXText(getFirstElement(qA)), getYText(getFirstElement(qA)), strlen(getTxtoText(getFirstElement(qA))), getX1Line(getFirstElement(qB)), getY1Line(getFirstElement(qB)), getX2Line(getFirstElement(qB)), getY2Line(getFirstElement(qB)), *getAText(getFirstElement(qA)));
    } else if (lA->id == 4 && lB->id == 4) {
        printFinalCoord(sTxt, "Texto", getXText(getFirstElement(getQueueLauncher(launcA))), getYText(getFirstElement(getQueueLauncher(launcA))));

        printFinalCoord(sTxt, "Texto", getXText(getFirstElement(getQueueLauncher(launcB))), getYText(getFirstElement(getQueueLauncher(launcB))));

        return textIntersection(getXText(getFirstElement(qA)), getYText(getFirstElement(qA)), strlen(getTxtoText(getFirstElement(qA))), getAText(getFirstElement(qA)), getXText(getNextElement(qB)), getYText(getNextElement(qB)), strlen(getTxtoText(getNextElement(qB))), getAText(getNextElement(qB)));
    }

    return false;
}