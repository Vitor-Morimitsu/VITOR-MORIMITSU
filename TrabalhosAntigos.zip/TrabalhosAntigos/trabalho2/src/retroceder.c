#include "stdio.h"
#include "string.h"
#include "retroceder.h"
#include "retangulo.h"
#include "linha.h"
#include "texto.h"
#include "circulo.h"
#include "math.h"

#define M_PI 3.14159265358979323846

void targetSimilarWarhead(Launcher *target, double dA, Launcher *warhead, double dO, double degreeA, double degreeO, int *id, int repeatedForm) {
    double rewindXTarget = dA/2 * cos(degreeA * M_PI / 180.0);
    double rewindYTarget = dA/2 * sin(degreeA * M_PI / 180.0);
    double rewindXWarhead = dO/2 * cos(degreeO * M_PI / 180.0);
    double rewindYWarhead = dO/2 * sin(degreeO * M_PI / 180.0);

    createClone(target, id, 0);
    createClone(warhead, id, repeatedForm);

    calcRewind(target, rewindXTarget, rewindYTarget, repeatedForm);
    calcRewind(warhead, rewindXWarhead, rewindYWarhead, repeatedForm);
    
    insertQueue(getQueueLauncher(target), getFirstElement(getQueueLauncher(target)));
    withdrawQueue(getQueueLauncher(target));
    
    insertQueue(getQueueLauncher(warhead), getFirstElement(getQueueLauncher(warhead)));
    withdrawQueue(getQueueLauncher(warhead));
}

void targetBiggerThanWarhead(Launcher *target, double targetArea, double dA, Launcher *warhead, double warheadArea, double dO, double degreeA, double degreeO, int repeatedForm) {
    double totalArea = targetArea + warheadArea;
    double rewindTarget = targetArea/totalArea; 
    double rewindWarhead = warheadArea/totalArea;

    // Valores para retroceder nas coordenadas do alvo e ogiva
    double rewindXTarget = dA * rewindTarget * cos(degreeA * M_PI / 180.0);
    double rewindYTarget = dA * rewindTarget * sin(degreeA * M_PI / 180.0);
    double rewindXWarhead = dO * rewindWarhead * cos(degreeO * M_PI / 180.0);
    double rewindYWarhead = dO * rewindWarhead * sin(degreeO * M_PI / 180.0);
    
    calcRewind(target, rewindXTarget, rewindYTarget, repeatedForm);
    calcRewind(warhead, rewindXWarhead, rewindYWarhead, repeatedForm);

    insertQueue(getQueueLauncher(target), getFirstElement(getQueueLauncher(target)));
    withdrawQueue(getQueueLauncher(target));
    
    insertQueue(getQueueLauncher(warhead), getFirstElement(getQueueLauncher(warhead)));
    withdrawQueue(getQueueLauncher(warhead));
}

void calcRewind(Launcher *l, double dX, double dY, int repeatedForm) {
    double x, y, x2, y2;

    switch (getIdLauncher(l))
    {
    case 1:
        x = getXRect(getFirstElement(getQueueLauncher(l)));
        y = getYRect(getFirstElement(getQueueLauncher(l)));

        setXRect(getFirstElement(getQueueLauncher(l)), x - dX);
        setYRect(getFirstElement(getQueueLauncher(l)), y - dY);
        
        break;
    case 2:
        x = getXCircle(getFirstElement(getQueueLauncher(l)));
        y = getYCircle(getFirstElement(getQueueLauncher(l)));
        
        setXCircle(getFirstElement(getQueueLauncher(l)), x - dX);
        setYCircle(getFirstElement(getQueueLauncher(l)), y - dY);

        break;
    case 3:
        x = getX1Line(getFirstElement(getQueueLauncher(l)));
        y = getY1Line(getFirstElement(getQueueLauncher(l)));
        x2 = getX2Line(getFirstElement(getQueueLauncher(l)));
        y2 = getY2Line(getFirstElement(getQueueLauncher(l)));

        setX1Line(getFirstElement(getQueueLauncher(l)), x - dX);
        setX2Line(getFirstElement(getQueueLauncher(l)), x2 - dX);
        setY1Line(getFirstElement(getQueueLauncher(l)), y - dY);
        setY2Line(getFirstElement(getQueueLauncher(l)), y2 - dY);
        break;
    case 4: 
        x = getXText(getFirstElement(getQueueLauncher(l)));
        y = getYText(getFirstElement(getQueueLauncher(l)));
        
        setXText(getFirstElement(getQueueLauncher(l)), x - dX);
        setYText(getFirstElement(getQueueLauncher(l)), y - dY);
        break;
    default:
        printf("Identificador de forma inválido");
        break;
    }
}

void targetSmallerThanWarhead(Queue target, Queue warhead, double *pont, double targetArea, double warheadArea, int repeatedForm) {
    withdrawQueue(target);
    insertQueue(warhead, getFirstElement(warhead));
    withdrawQueue(warhead);
    double area = targetArea/warheadArea*100;
    *pont = *pont + area;
}

void miss(Queue target, Queue warhead, int repeatedForm) {
    if (repeatedForm == 0) {
        withdrawQueue(warhead);      
        insertQueue(target, getFirstElement(target));
        withdrawQueue(target); 
    } else {
        insertQueue(target, getFirstElement(target));
        withdrawQueue(target);
        withdrawQueue(warhead);
    }
}

void createClone(Launcher *l, int *id, int repeatedForm) {
    *id = *id + 1;
    switch (getIdLauncher(l))
    {
    case 1:
        if (repeatedForm == 0) {   
            insertQueue(getQueueLauncher(l), createRectangle(*id, getXRect(getFirstElement(getQueueLauncher(l))), getYRect(getFirstElement(getQueueLauncher(l))), getWRect(getFirstElement(getQueueLauncher(l))), getHRect(getFirstElement(getQueueLauncher(l))), "#d400aa", getCorpRect(getFirstElement(getQueueLauncher(l)))));
        } else {
            insertQueue(getQueueLauncher(l), createRectangle(*id, getXRect(getNextElement(getQueueLauncher(l))), getYRect(getNextElement(getQueueLauncher(l))), getWRect(getNextElement(getQueueLauncher(l))), getHRect(getNextElement(getQueueLauncher(l))), "#d400aa", getCorpRect(getNextElement(getQueueLauncher(l)))));
        }
        break;
    case 2:
        if (repeatedForm == 0) {
            insertQueue(getQueueLauncher(l), createCircle(*id, getXCircle(getFirstElement(getQueueLauncher(l))), getYCircle(getFirstElement(getQueueLauncher(l))), getRCircle(getFirstElement(getQueueLauncher(l))), "#d400aa", getCorpCircle(getFirstElement(getQueueLauncher(l)))));
        } else {
            insertQueue(getQueueLauncher(l), createCircle(*id, getXCircle(getNextElement(getQueueLauncher(l))), getYCircle(getNextElement(getQueueLauncher(l))), getRCircle(getNextElement(getQueueLauncher(l))), "#d400aa", getCorpCircle(getNextElement(getQueueLauncher(l)))));
        }
        break;
    case 3:
        if (repeatedForm == 0) {
            insertQueue(getQueueLauncher(l), createLine(*id, getX1Line(getFirstElement(getQueueLauncher(l))), getX2Line(getFirstElement(getQueueLauncher(l))), getY1Line(getFirstElement(getQueueLauncher(l))), getY2Line(getFirstElement(getQueueLauncher(l))), "#d400aa"));
        } else {
            insertQueue(getQueueLauncher(l), createLine(*id, getX1Line(getNextElement(getQueueLauncher(l))), getX2Line(getNextElement(getQueueLauncher(l))), getY1Line(getNextElement(getQueueLauncher(l))), getY2Line(getNextElement(getQueueLauncher(l))), "#d400aa"));
        }
        break; 
    case 4: 
        if (repeatedForm == 0) {
            insertQueue(getQueueLauncher(l), createText(*id, getXText(getFirstElement(getQueueLauncher(l))), getYText(getFirstElement(getQueueLauncher(l))), "#d400aa", getCorpText(getFirstElement(getQueueLauncher(l))), getAText(getFirstElement(getQueueLauncher(l))), getTxtoText(getFirstElement(getQueueLauncher(l)))));
        } else {
            insertQueue(getQueueLauncher(l), createText(*id, getXText(getNextElement(getQueueLauncher(l))), getYText(getNextElement(getQueueLauncher(l))), "#d400aa", getCorpText(getNextElement(getQueueLauncher(l))), getAText(getNextElement(getQueueLauncher(l))), getTxtoText(getNextElement(getQueueLauncher(l)))));
        }
        
        break;
    default:
        printf("Launcher inexistente!");
        break;
    }
}
