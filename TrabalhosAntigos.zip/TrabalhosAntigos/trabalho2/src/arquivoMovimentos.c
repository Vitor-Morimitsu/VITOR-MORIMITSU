#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arquivoMovimentos.h"
#include "retangulo.h"
#include "linha.h"
#include "fila.h"
#include "criarTxt.h"

void openMovementsFile(FILE **m, char *qryPath) {
    *m = fopen(qryPath, "r");
    if (*m == NULL) {
        printf("Não foi possível alocar memória para o arquivo de movimentos");
        exit(1);
    }
}

void readMovementsFile(FILE *m, Launcher *lRect, Launcher *lCircle, Launcher *lText, Launcher *lLine, double *pont, int *id, FILE **sTxt, int *totalLaunch, int *totalInstructions, int *createdForms, int *destroyedForms) {
    if (m == NULL) {
        printf("Arquivo não foi aberto");
        return;
    }

    char line[256];
    char moveType[3];
    while (fgets(line, sizeof(line), m)) {
        if (sscanf(line, "%2s", moveType) == 1) {
            processLineMoves(line, moveType, lRect, lCircle, lText, lLine, pont, id, sTxt, totalLaunch, totalInstructions, createdForms, destroyedForms);
        } else {
            printf("Erro ao processar linha: %s\n", line);
        }
    }

    fclose(m);
}

void processLineMoves(char *line, char *moveType, Launcher *lRect, Launcher *lCircle, Launcher *lText, Launcher *lLine, double *pont, int *id, FILE **sTxt, int *totalLaunch, int *totalInstructions, int *createdForms, int *destroyedForms) {
    char launcherTypeA[2], launcherTypeO[2], type[3];
    double degree, dA, dO;
    
    if (strcmp(moveType, "rt") == 0) {
        if (sscanf(line, "%2s %1s %lf", type, launcherTypeA, &degree) == 3) {
            printCommandLine(sTxt, line);
            if (strcmp(launcherTypeA, "T") == 0) {
                positionLauncher(lText, degree, sTxt);
            } else if (strcmp(launcherTypeA, "R") == 0) {
                positionLauncher(lRect, degree, sTxt);
            } else if (strcmp(launcherTypeA, "L") == 0) {
                positionLauncher(lLine, degree, sTxt);
            } else if (strcmp(launcherTypeA, "C") == 0) {
                positionLauncher(lCircle, degree, sTxt);
            } else {
                printf("Forma não existente!");
            }
            *totalInstructions = *totalInstructions + 1;
        } else {
            printf("Erro no sscanf RT\n");
        }
    } else if (strcmp(moveType, "lc") == 0) {
        if (sscanf(line, "%2s %1s %lf %1s %lf", type, launcherTypeA, &dA, launcherTypeO, &dO) == 5) {
            printCommandLine(sTxt, line);
            if (strcmp(launcherTypeA, "T") == 0) {
                *totalLaunch = *totalLaunch + 1;
                if (strcmp(launcherTypeO, "R") == 0) {
                    doubleLaunch(lText, dA, lRect, dO, pont, id, sTxt, destroyedForms, createdForms, 0);
                } else if (strcmp(launcherTypeO, "L") == 0) {
                    doubleLaunch(lText, dA, lLine, dO, pont, id, sTxt, destroyedForms, createdForms, 0);
                } else if (strcmp(launcherTypeO, "C") == 0) {
                    doubleLaunch(lText, dA, lCircle, dO, pont, id, sTxt, destroyedForms, createdForms, 0);
                } else if (strcmp(launcherTypeO, "T") == 0) {
                    doubleLaunch(lText, dA, lText, dO, pont, id, sTxt, destroyedForms, createdForms, 1);
                } 
            } else if (strcmp(launcherTypeA, "R") == 0) {
                *totalLaunch = *totalLaunch + 1;
                if (strcmp(launcherTypeO, "T") == 0) {
                    doubleLaunch(lRect, dA, lText, dO, pont, id, sTxt, destroyedForms, createdForms, 0);
                } else if (strcmp(launcherTypeO, "L") == 0) {
                    doubleLaunch(lRect, dA, lLine, dO, pont, id, sTxt, destroyedForms, createdForms, 0);
                } else if (strcmp(launcherTypeO, "C") == 0) {
                    doubleLaunch(lRect, dA, lCircle, dO, pont, id, sTxt, destroyedForms, createdForms, 0);
                } else if (strcmp(launcherTypeO, "R") == 0) {
                    
                    doubleLaunch(lRect, dA, lRect, dO, pont, id, sTxt, destroyedForms, createdForms, 1);
                }
            } else if (strcmp(launcherTypeA, "L") == 0) {
                *totalLaunch = *totalLaunch + 1;
                if (strcmp(launcherTypeO, "T") == 0) {
                    doubleLaunch(lLine, dA, lText, dO, pont, id, sTxt, destroyedForms, createdForms, 0);
                } else if (strcmp(launcherTypeO, "R") == 0) {
                    doubleLaunch(lLine, dA, lRect, dO, pont, id, sTxt, destroyedForms, createdForms, 0);
                } else if (strcmp(launcherTypeO, "C") == 0) {
                    doubleLaunch(lLine, dA, lCircle, dO, pont, id, sTxt, destroyedForms, createdForms, 0);
                } else if (strcmp(launcherTypeO, "L") == 0) {
                    doubleLaunch(lLine, dA, lLine, dO, pont, id, sTxt, destroyedForms, createdForms, 1);
                }
            } else if (strcmp(launcherTypeA, "C") == 0) {
                *totalLaunch = *totalLaunch + 1;
                if (strcmp(launcherTypeO, "T") == 0) {
                    doubleLaunch(lCircle, dA, lText, dO, pont, id, sTxt, destroyedForms, createdForms, 0);
                } else if (strcmp(launcherTypeO, "L") == 0) {
                    doubleLaunch(lCircle, dA, lLine, dO, pont, id, sTxt, destroyedForms, createdForms, 0);
                } else if (strcmp(launcherTypeO, "R") == 0) {
                    doubleLaunch(lCircle, dA, lRect, dO, pont, id, sTxt, destroyedForms, createdForms, 0);
                } else if (strcmp(launcherTypeO, "C") == 0) {
                    doubleLaunch(lCircle, dA, lCircle, dO, pont, id, sTxt, destroyedForms, createdForms, 1);
                }           
            } else {
                printf("Forma não existente! launcherTypeA: %s, launcherTypeO: %s\n", launcherTypeA, launcherTypeO);
            }
        } else {
            printf("Erro no sscanf LC\n");
        }
    } else {
        printf("A forma solicitada não está no registro!\n");
        return;
    }
}