#ifndef FILA_H
#define FILA_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "texto.h"
#include "lancador.h"

typedef FILE File;
typedef void *Queue;
typedef void *Form;

/**
 * @brief Cria uma nova fila vazia.
 * 
 * @return Ponteiro para a nova fila criada.
 * 
 * @details
 * A função aloca memória para a estrutura de fila e inicializa seus atributos,
 * como o ponteiro para o primeiro e último elementos e o tamanho da fila.
 * 
 * @warning Encerra o programa com `exit(1)` se não for possível alocar memória.
 */

Queue createQueue();

/**
 * @brief Insere um elemento na fila.
 * 
 * @param queue Ponteiro para a fila onde o elemento será inserido.
 * @param f Forma a ser inserida na fila.
 * 
 * @details
 * A função cria um novo nó para armazenar a forma e a insere no final da fila.
 * Caso a fila esteja vazia, o novo nó se torna o primeiro e o último elemento.
 * 
 * @warning Encerra o programa se ocorrer falha na alocação de memória.
 */

void insertQueue(Queue *q, Form f);

/**
 * @brief Remove o primeiro elemento da fila.
 * 
 * @param queue Ponteiro para a fila de onde o elemento será removido.
 * 
 * @details
 * A função libera a memória do primeiro nó da fila e ajusta os ponteiros
 * do primeiro e último elementos, conforme necessário.
 * 
 * @warning Encerra o programa se a fila estiver vazia.
 */

void withdrawQueue(Queue *q);

/**
 * @brief Obtém o primeiro elemento da fila sem removê-lo.
 * 
 * @param queue Ponteiro para a fila de onde o elemento será obtido.
 * @return Ponteiro para o primeiro elemento da fila ou NULL se a fila estiver vazia.
 */

Queue getFirstElement(Queue *queue);

/**
 * @brief Obtém o próximo elemento da fila após o primeiro.
 * 
 * @param queue Ponteiro para a fila de onde o próximo elemento será obtido.
 * 
 * @return Ponteiro para o próximo elemento ou NULL se não houver elementos suficientes.
 * 
 * @details A função verifica se há pelo menos dois elementos na fila antes de retornar o próximo elemento.
 * 
 * @warning Exibe uma mensagem de erro se não houver elementos suficientes.
 */

Form getNextElement(Queue *queue);

/**
 * @brief Libera toda a memória ocupada pela fila e seus elementos.
 * 
 * @param queue Ponteiro para a fila que será destruída.
 * 
 * @details A função percorre a fila, liberando a memória de cada nó,
 * e redefine os atributos da fila para indicar que está vazia.
 */

void killQueue(Queue *q);

/**
 * @brief Percorre a fila e aplica uma ação em cada elemento.
 * 
 * @param queue Ponteiro para a fila a ser percorrida.
 * @param queueType Tipo de elementos na fila (ex.: Retângulo, Círculo, etc.).
 * @param s Ponteiro para o arquivo SVG onde os elementos serão inseridos.
 * @param ts Estilo do texto a ser usado nos elementos do tipo texto.
 * 
 * @details A função percorre todos os elementos da fila e, para cada um,
 * chama a função `selectQueue` para realizar uma ação específica baseada no tipo.
 */

void passthroughQueue(Queue *queue, int queueType, File *s, TxtStyle ts);

/**
 * @brief Seleciona a ação a ser realizada para um elemento da fila.
 * 
 * @param f Ponteiro para a forma a ser processada.
 * @param queueType Tipo do elemento (1 para Retângulo, 2 para Círculo, etc.).
 * @param s Ponteiro para o arquivo SVG onde o elemento será inserido.
 * @param ts Estilo do texto a ser usado para elementos do tipo texto.
 * 
 * @details Com base no tipo do elemento (`queueType`), a função chama a função correspondente
 * para inserir a forma no arquivo SVG.
 */

void selectQueue (Form *f, int queueType, File *s, TxtStyle ts);

#endif
