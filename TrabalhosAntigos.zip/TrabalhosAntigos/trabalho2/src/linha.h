#ifndef LINHA_H
#define LINHA_H

typedef void *Line;

/**
 * @brief Cria uma linha com os atributos especificados.
 * 
 * @param i Identificador único do linha.
 * @param x1 Coordenada x1 do centro do linha.
 * @param x2 Coordenada x2 do centro do linha.
 * @param y1 Coordenada y1 do centro do linha.
 * @param y2 Coordenada y2 do centro do linha.
 * @param cor Cor de linha.
 * 
 * @return Um ponteiro para o objeto `Linha` criado.
 * 
 * @details
 * A função aloca memória para uma nova linha e inicializa seus atributos.
 * Se ocorrer erro na alocação de memória, o programa será encerrado com uma mensagem de erro.
 */

Line createLine(int i, double x1, double x2, double y1, double y2, char *cor);

/**
 * @brief Pega o id do linha.
 * 
 * @param l a linha do qual será pego o id.
 * 
 * @return O id da forma.  
 * 
*/

int getIdLine (Line l);

/**
 * @brief Pega o valor da coordenada x1 do linha.
 * 
 * @param l A linha do qual será pego a coordenada x1.
 * 
 * @return A coordenada x1 da forma.  
 * 
*/

double getX1Line(Line l);

/**
 * @brief Pega o valor da coordenada x2 do linha.
 * 
 * @param l A linha do qual será pego a coordenada x2.
 * 
 * @return A coordenada x2 da forma.  
 * 
*/

double getX2Line(Line l);

/**
 * @brief Pega o valor da coordenada y1 do linha.
 * 
 * @param l A linha do qual será pego a coordenada y1.
 * 
 * @return A coordenada y1 da forma.  
 * 
*/

double getY1Line(Line l);

/**
 * @brief Pega o valor da coordenada y2 do linha.
 * 
 * @param l A linha do qual será pego a coordenada y2.
 * 
 * @return A coordenada y2 da forma.  
 * 
*/

double getY2Line(Line l);

/**
 * @brief Calcula a área da linha.
 * 
 * @param x1 Coordenada x1 do centro do linha.
 * @param x2 Coordenada x2 do centro do linha.
 * @param y1 Coordenada y1 do centro do linha.
 * @param y2 Coordenada y2 do centro do linha.
 * 
 * @return O valor da área da forma.  
 * 
*/

double calcAreaLine(double x1, double x2, double y1, double y2);

/**
 * @brief Pega a cor de preenchimento da linha.
 * 
 * @param l A linha do qual será pego a cor de preenchimento.
 * 
 * @return Uma string com a cor de preenchimento da forma.  
 * 
*/

char *getCorLine(Line l);

/**
 * @brief Define o valor da coordenada x da linha.
 * 
 * @param l A linha do qual será definido a coordenada x.
 * @param x O novo valor para a coordenada x.
*/

void setX1Line(Line l, double x);

/**
 * @brief Define o valor da coordenada x2 da linha.
 * 
 * @param l A linha do qual será definido a coordenada x2.
 * @param x2 O novo valor para a coordenada x2.
*/

void setX2Line(Line l, double x2);

/**
 * @brief Define o valor da coordenada y da linha.
 * 
 * @param l A linha do qual será definido a coordenada y.
 * @param y O novo valor para a coordenada y.
*/

void setY1Line(Line l, double y);

/**
 * @brief Define o valor da coordenada y2 da linha.
 * 
 * @param l A linha do qual será definido a coordenada y2.
 * @param y2 O novo valor para a coordenada y2.
*/

void setY2Line(Line l, double y2);

/**
 * @brief Define o valor da coordenada cor da linha.
 * 
 * @param l A linha do qual será definido a coordenada cor.
 * @param cor O novo valor para a coordenada cor.
*/

void setCorLine(Line l, char *cor);


#endif
