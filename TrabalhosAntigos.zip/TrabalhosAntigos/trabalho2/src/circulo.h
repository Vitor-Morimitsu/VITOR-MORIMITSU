#ifndef CIRCULO_H
#define CIRCULO_H

typedef void *Circle;

/**
 * @brief Cria um círculo com os atributos especificados.
 * 
 * @param id Identificador único do círculo.
 * @param x Coordenada x do centro do círculo.
 * @param y Coordenada y do centro do círculo.
 * @param r Raio do círculo.
 * @param corb Cor da borda do círculo.
 * @param corp Cor de preenchimento do círculo.
 * 
 * @return Um ponteiro para o objeto `Circle` criado.
 * 
 * @details
 * A função aloca memória para um novo círculo e inicializa seus atributos.
 * Se ocorrer erro na alocação de memória, o programa será encerrado com uma mensagem de erro.
 */

Circle createCircle(int id, double x, double y, double r, char *corb, char *corp);

/**
 * @brief Pega o id do círculo.
 * 
 * @param c O circulo do qual será pego o id.
 * 
 * @return O id da forma.  
 * 
*/

int getIdCircle (Circle c);

/**
 * @brief Pega o valor da coordenada x do círculo.
 * 
 * @param c O circulo do qual será pego a coordenada x.
 * 
 * @return A coordenada x da forma.  
 * 
*/

double getXCircle(Circle c);

/**
 * @brief Pega o valor da coordenada y do círculo.
 * 
 * @param c O circulo do qual será pego a coordenada y.
 * 
 * @return A coordenada y da forma.  
 * 
*/

double getYCircle(Circle c);

/**
 * @brief Pega o valor do raio do círculo.
 * 
 * @param c O circulo do qual será pego o seu raio.
 * 
 * @return O raio da forma.  
 * 
*/

double getRCircle(Circle c);

/**
 * @brief Calcula a área do círculo.
 * 
 * @param r O raio do círculo.
 * 
 * @return O valor da área da forma.  
 * 
*/

double calcAreaCircle(double r);

/**
 * @brief Pega a cor da borda do círculo.
 * 
 * @param c O circulo do qual será pego a cor da borda.
 * 
 * @return Uma string com a cor da borda da forma.  
 * 
*/

char *getCorbCircle(Circle c);

/**
 * @brief Pega a cor de preenchimento do círculo.
 * 
 * @param c O circulo do qual será pego a cor de preenchimento.
 * 
 * @return Uma string com a cor de preenchimento da forma.  
 * 
*/

char *getCorpCircle(Circle c);

/**
 * @brief Define o valor da coordenada X do círculo.
 * 
 * @param c O circulo do qual será definido a coordenada x.
 * @param x O novo valor para a coordenada x.
*/

void setXCircle(Circle c, double x);

/**
 * @brief Define o valor da coordenada Y do círculo.
 * 
 * @param c O circulo do qual será definido a coordenada y.
 * @param y O novo valor para a coordenada y.
*/

void setYCircle(Circle c, double y);

/**
 * @brief Define o valor do raio do círculo.
 * 
 * @param c O circulo do qual será definido o raio.
 * @param radius O novo valor para o raio.
*/

void setRCircle(Circle c, double radius);

/**
 * @brief Define a cor da borda do círculo.
 * 
 * @param c O circulo do qual será definido a cor da sua borda.
 * @param corB A nova cor para a borda da forma.
*/

void setCorbCircle(Circle c, char *corB);

/**
 * @brief Define a cor de preenchimento do círculo.
 * 
 * @param c O circulo do qual será definido a cor de preenchimento.
 * @param corP A nova cor para o preenchimento da forma.
*/

void setCorpCircle(Circle c, char *corP);

#endif