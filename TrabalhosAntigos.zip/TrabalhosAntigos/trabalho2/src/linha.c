#include "linha.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "math.h"

typedef struct line {
    int i;
    double x1, x2, y1, y2;
    char *cor;
} Lin;

Line createLine(int i, double x1, double x2, double y1, double y2, char *cor) {
    Lin *l = malloc(sizeof(Lin));
    if (l == NULL) {
        printf("Erro na alocação de memória na criação da linha");
        exit(1);
    }

    l->i = i;
    l->x1 = x1;
    l->y1 = y1;
    l->x2 = x2;
    l->y2 = y2;

    l->cor = (char*)malloc(strlen(((char*)cor)));
    if (l->cor == NULL) {
        printf("Erro na alocação de memória na cor do texto");
        exit(1);
    }
    strcpy(l->cor, cor);

    return ((Lin*)l);
}

int getIdLine (Line l) {
    return ((Lin*)l)->i;
}

double getX1Line(Line l) {
    return ((Lin*)l)->x1;
}

double getX2Line(Line l) {
    return ((Lin*)l)->x2;
}

double getY1Line(Line l) {
    return ((Lin*)l)->y1;
}

double getY2Line(Line l) {
    return ((Lin*)l)->y2;
}

double calcAreaLine(double x1, double x2, double y1, double y2) {
    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2)) * 1.5;
}

char *getCorLine(Line l) {
    return ((Lin*)l)->cor;
}

void setX1Line(Line l, double x) {
    ((Lin*)l)->x1 = x;
}

void setX2Line(Line l, double x2) {
    ((Lin*)l)->x2 = x2;
}

void setY1Line(Line l, double y) {
    ((Lin*)l)->y1 = y;
}

void setY2Line(Line l, double y2) {
    ((Lin*)l)->y2 = y2;
}

void setCorLine(Line l, char *cor) {
    strcpy(((Lin*)l)->cor, cor);
}