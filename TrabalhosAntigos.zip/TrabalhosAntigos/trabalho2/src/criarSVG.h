#include <stdio.h>
#include <stdlib.h>
#include "retangulo.h"
#include "circulo.h"
#include "linha.h"
#include "texto.h"
#ifndef CRIARSVG_H
#define CRIARSVG_H

typedef FILE File;
typedef void *Forma;

/**
 * @brief Cria o arquivo de saída SVG (.svg).
 * 
 * @param saida Ponteiro duplo para o endereço do arquivo.
 * @param exitPath Ponteiro com o nome do arquivo de saída criado.
 * @return A função não retorna nada, apenas faz o ponteiro apontar para o endereço do arquivo.
 * 
 * @details
 * A função tenta abrir o arquivo especificado pelo caminho `exitPath` no modo de escrita (`"w"`).
 * Se não for possível abrir o arquivo, a função exibe uma mensagem de erro e encerra o programa com `exit(1)`.
 * 
 * @note O ponteiro para o arquivo será atualizado com o resultado de `fopen`. 
 * Certifique-se de fechar o arquivo após usá-lo para evitar vazamentos de recursos.
 * 
 * @warning Se o arquivo não puder ser aberto, o programa será encerrado.
 */


void openExitFile(File **saida, char *exitPath);

/**
 * @brief Adiciona a tag inicial do arquivo SVG.
 * 
 * @param saida Ponteiro para o arquivo de saída.
 */

void startSVG(File *saida);

/**
 * @brief Adiciona a tag rect do arquivo SVG.
 * 
 * @param saida Ponteiro para o arquivo de saída.
 * @param r Forma do retângulo
 */

void insertRectSVG(File *saida, Rectangle r);

/**
 * @brief Adiciona a tag circle do arquivo SVG.
 * 
 * @param saida Ponteiro para o arquivo de saída.
 * @param c Forma do círculo
 */

void insertCircleSVG(File *saida, Circle c);

/**
 * @brief Adiciona a tag text do arquivo SVG.
 * 
 * @param saida Ponteiro para o arquivo de saída.
 * @param t Forma do texto
 * @param ts Atributos estéticos do texto
 */

void insertTextSVG(File *saida, Text t, TxtStyle ts);

/**
 * @brief Adiciona a tag line do arquivo SVG.
 * 
 * @param saida Ponteiro para o arquivo de saída.
 * @param l Forma da linha
 */

void insertLineSVG(File *saida, Line l);

/**
 * @brief Adiciona a tag final do arquivo SVG.
 * 
 * @param saida Ponteiro para o arquivo de saída.
 */

void closeSVG(File *saida);

#endif