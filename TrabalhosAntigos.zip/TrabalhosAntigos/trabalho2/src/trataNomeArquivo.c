#include "trataNomeArquivo.h"

#define PATH_LEN 250
#define FILE_NAME_LEN 100
#define MSG_LEN 1000

void trataPath(char *path, int tamMax, char *arg) {
    int argLen = strlen(arg);
    assert(argLen < tamMax);
    if (arg[argLen - 1] == '/') {
        arg[argLen - 1] = '\0';
    }
    strcpy(path, arg);
}

void trataNomeArquivo(char *path, int tamMax, char *arg) {
    int argLen = strlen(arg);
    assert((argLen + 4) < tamMax);
    sprintf(path, "%s.txt", arg);
}

void archiveNameCombination(char *geoName, char *qryName, char *exitPath, int size) {
    char geo[FILE_NAME_LEN], qry[FILE_NAME_LEN];
    char *fullPathExit[FILE_NAME_LEN];
    strcpy(geo, geoName);
    char *extensionGeo = strrchr(geo, '.');
    if (extensionGeo) *extensionGeo = '\0';


    if (qryName && strlen(qryName) > 0) {
        strcpy(qry, qryName);
        char *extensionQry = strrchr(qry, '.');
        if (extensionQry) *extensionQry = '\0';
        snprintf(exitPath, size, "%s-%s", geo, qry);
    } else { 
        snprintf(exitPath, size, "%s", geo);
    }
}