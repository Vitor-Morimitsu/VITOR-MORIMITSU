#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcoesArquivo.h"
#include "arquivoMovimentos.h"
#include "lancador.h"
#include "retangulo.h"
#include "circulo.h"
#include "linha.h"
#include "texto.h"
#include "fila.h"
#include "criarSVG.h"
#include "criarTxt.h"
#include "trataNomeArquivo.h"

#define PATH_LEN 250
#define FILE_NAME_LEN 100
#define MSG_LEN 1000

int main(int argc, char *argv[]) {
    char dirEntrada[PATH_LEN] = "."; 
    char dirSaida[PATH_LEN] = ".";    
    char nomeArquivoGeo[FILE_NAME_LEN] = ""; 
    char nomeArquivoQry[FILE_NAME_LEN] = ""; 
    char fullPathGeo[PATH_LEN + FILE_NAME_LEN];
    char fullPathQry[PATH_LEN + FILE_NAME_LEN]; 
    char fullPathSaida[PATH_LEN + FILE_NAME_LEN]; 
    char nomeBaseSaida[FILE_NAME_LEN];
    char arquivoSaidaSvg[PATH_LEN + FILE_NAME_LEN];
    char arquivoSaidaSvgMovs[PATH_LEN + FILE_NAME_LEN];
    char arquivoSaidaTxt[PATH_LEN + FILE_NAME_LEN]; 
    char onlyQry[FILE_NAME_LEN] = "";
    int hasGeo = 0, hasSaida = 0; 
    
    int i = 1;
    while (i < argc) {
        if (strcmp(argv[i], "-e") == 0) {
            i++;
            if (i >= argc) {
                fprintf(stderr, "Erro: falta parâmetro após -e\n");
                return EXIT_FAILURE;
            }
            trataPath(dirEntrada, PATH_LEN, argv[i]);
        } else if (strcmp(argv[i], "-o") == 0) {
            i++;
            if (i >= argc) {
                fprintf(stderr, "Erro: falta parâmetro após -o\n");
                return EXIT_FAILURE;
            }
            trataPath(dirSaida, PATH_LEN, argv[i]);
            hasSaida = 1;
        } else if (strcmp(argv[i], "-f") == 0) {
            i++;
            if (i >= argc) {
                fprintf(stderr, "Erro: falta parâmetro após -f\n");
                return EXIT_FAILURE;
            }
            strcpy(nomeArquivoGeo, argv[i]);
            hasGeo = 1;
        } else if (strcmp(argv[i], "-q") == 0) {
            i++;
            if (i >= argc) {
                fprintf(stderr, "Erro: falta parâmetro após -q\n");
                return EXIT_FAILURE;
            }  
            strcpy(nomeArquivoQry, argv[i]);
            char *onlyNameQry = strrchr(argv[i], '/');
            if (onlyNameQry) {
                onlyNameQry++;
            } else {
                onlyNameQry = argv[i];
            }
            strcpy(onlyQry, onlyNameQry);
        } else {
            fprintf(stderr, "Parâmetro desconhecido: %s\n", argv[i]);
            return EXIT_FAILURE;
        }
        i++;
    }

    if (!hasGeo) {
        fprintf(stderr, "Erro: o parâmetro -f (arquivo .geo) é obrigatório\n");
        return EXIT_FAILURE;
    }
    if (!hasSaida) {
        fprintf(stderr, "Erro: o parâmetro -o (diretório de saída) é obrigatório\n");
        return EXIT_FAILURE;
    }

    snprintf(fullPathGeo, sizeof(fullPathGeo), "%s/%s", dirEntrada, nomeArquivoGeo);
    if (strlen(nomeArquivoQry) > 0) {
        snprintf(fullPathQry, sizeof(fullPathQry), "%s/%s", dirEntrada, nomeArquivoQry);
    }
    snprintf(fullPathSaida, sizeof(fullPathSaida), "%s", dirSaida);

    FILE *f = NULL;
    FILE *s = NULL;
    FILE *sMovs = NULL;
    FILE *sTxt = NULL;
    FILE *m = NULL;

    openFile(&f, fullPathGeo);
    
    archiveNameCombination(nomeArquivoGeo, onlyQry, nomeBaseSaida, FILE_NAME_LEN);
    snprintf(arquivoSaidaSvg, sizeof(arquivoSaidaSvg), "%s/%s.svg", fullPathSaida, nomeArquivoGeo);
    snprintf(arquivoSaidaSvgMovs, sizeof(arquivoSaidaSvgMovs), "%s/%s.svg", fullPathSaida, nomeBaseSaida);
    snprintf(arquivoSaidaTxt, sizeof(arquivoSaidaTxt), "%s/%s.txt", fullPathSaida, nomeBaseSaida);
    
    
    openExitFile(&s, arquivoSaidaSvg);
    
    openExitFile(&sMovs, arquivoSaidaSvgMovs);

    if (strlen(nomeArquivoQry) > 0) {
        openMovementsFile(&m, fullPathQry);
        openTxtFile(&sTxt, arquivoSaidaTxt);
    }

    

    int id = 0, createdForms = 0, destroyedForms = 0, totalLaunch = 0, totalInstructions = 0;
    double pont;
    TxtStyle *tS = createTxtStyle("", "", "");
    Queue *qRect = createQueue();
    Queue *qCircle = createQueue();
    Queue *qLine = createQueue();
    Queue *qText = createQueue();

    Launcher *lRect = createLauncher(qRect, 1);
    Launcher *lCircle = createLauncher(qCircle, 2);
    Launcher *lLine = createLauncher(qLine, 3);
    Launcher *lText = createLauncher(qText, 4);
    

    // Leitura e extração de dados do arquivo de formas
    readFile(f, lRect, lCircle, lLine, lText, tS, s, &id, &createdForms);

    startSVG(s);
    passthroughQueue(getQueueLauncher(lRect), getIdLauncher(lRect), s, tS);
    passthroughQueue(getQueueLauncher(lCircle), getIdLauncher(lCircle), s, tS);
    passthroughQueue(getQueueLauncher(lLine), getIdLauncher(lLine), s, tS);
    passthroughQueue(getQueueLauncher(lText), getIdLauncher(lText), s, tS);

    closeSVG(s);

    // Leitura e extração de dados do arquivo de lançamentos(movimentos)
    if (strlen(nomeArquivoQry) > 0) {
        readMovementsFile(m, lRect, lCircle, lText, lLine, &pont, &id, sTxt, &totalLaunch, &totalInstructions, &createdForms, &destroyedForms);
        printGameResults(sTxt, pont, totalInstructions, totalLaunch, destroyedForms, createdForms);
    }
    
    startSVG(sMovs);
    passthroughQueue(getQueueLauncher(lRect), getIdLauncher(lRect), sMovs, tS);
    passthroughQueue(getQueueLauncher(lCircle), getIdLauncher(lCircle), sMovs, tS);
    passthroughQueue(getQueueLauncher(lLine), getIdLauncher(lLine), sMovs, tS);
    passthroughQueue(getQueueLauncher(lText), getIdLauncher(lText), sMovs, tS);

    closeSVG(sMovs);

    return 0;
}