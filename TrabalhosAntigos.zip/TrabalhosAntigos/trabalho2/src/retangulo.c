#include "retangulo.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"

typedef struct rect {
    int i;
    double x, y, w, h;
    char *corb, *corp;
} Rect;

Rectangle createRectangle(int id, double x, double y, double w, double h, char * corb, char *corp) {
    Rect *r = (Rect *)malloc(sizeof(Rect));
    if (r == NULL) {
        printf("Erro na alocação de memória");
        return NULL;
    }

    r->i = id;
    r->x = x;
    r->y = y;
    r->w = w;
    r->h = h;
    
    r->corb = (char *)malloc(strlen(corb)+1);
    if (r->corb == NULL) {
        printf("Erro na alocação de memória para corb");
        free(r);
        exit(1);
    }

    strcpy(r->corb, corb);

    r->corp = (char *)malloc(strlen(corp)+1);
    if (r->corp == NULL) {
        printf("Erro na alocação de memória");
        free(r);
        exit(1);
    }

    strcpy(r->corp, corp);

    return ((Rect*)r);
}

int getIdRect (Rectangle r) {
    return ((Rect*)r)->i;
}

double getXRect(Rectangle r) {
    return ((Rect*)r)->x;
}

double getYRect(Rectangle r) {
    return ((Rect*)r)->y;
}

double getWRect(Rectangle r) {
    return ((Rect*)r)->w;
}

double calcAreaRect(double w, double h) {
    return w*h;
}

double getHRect(Rectangle r) {
    return ((Rect*)r)->h;
}

char *getCorbRect(Rectangle r) {
    return ((Rect*)r)->corb;
}

char *getCorpRect(Rectangle r) {
    return ((Rect*)r)->corp;
}

void setXRect(Rectangle r, double x) {
    ((Rect*)r)->x = x;
}

void setYRect(Rectangle r, double y) {
    ((Rect*)r)->y = y;
}

void setWRect(Rectangle r, double w) {
    ((Rect*)r)->w = w;
}

void setHRect(Rectangle r, double h) {
    ((Rect*)r)->h = h;
}

void setCorbRect(Rectangle r, char *corB) {
    strcpy(((Rect*)r)->corb, corB);
}

void setCorpRect(Rectangle r, char *corP) {
    strcpy(((Rect*)r)->corp, corP);
}

