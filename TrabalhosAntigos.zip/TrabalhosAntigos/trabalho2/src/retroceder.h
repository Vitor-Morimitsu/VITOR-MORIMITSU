#include "fila.h"
#include "lancador.h"

#ifndef COLISAO_H
#define COLISAO_H

/**
 * @brief Simula um ataque entre dois lançadores, com base em um alvo e uma ogiva de tamanhos semelhantes.
 * 
 * @param target Ponteiro para o lançador do alvo.
 * @param dA Distância do alvo a ser retrocedida.
 * @param warhead Ponteiro para o lançador da ogiva.
 * @param dO Distância da ogiva a ser retrocedida.
 * @param degreeA Ângulo de movimento do alvo.
 * @param degreeO Ângulo de movimento da ogiva.
 * @param id Ponteiro para o identificador a ser incrementado.
 * @param repeatedForm Indica se o formato é repetido ou não.
 */

void targetSimilarWarhead(Launcher *target, double dA, Launcher *warhead, double dO, double degreeA, double degreeO, int *id, int repeatedForm);

/**
 * @brief Simula um ataque entre dois lançadores, considerando a área do alvo maior que da ogiva.
 * 
 * @param target Ponteiro para o lançador do alvo.
 * @param targetArea Área do alvo.
 * @param dA Distância do alvo a ser retrocedida.
 * @param warhead Ponteiro para o lançador da ogiva.
 * @param warheadArea Área da ogiva.
 * @param dO Distância da ogiva a ser retrocedida.
 * @param degreeA Ângulo de movimento do alvo.
 * @param degreeO Ângulo de movimento da ogiva.
 * @param repeatedForm Indica se o formato é repetido ou não.
 */

void targetBiggerThanWarhead(Launcher *target, double targeArea, double dA, Launcher *warhead, double warheadArea, double dO, double degreeA, double degreeO, int repeatedForm);

/**
 * @brief Trata a situação em que o alvo é menor que a ogiva, calculando a pontuação.
 * 
 * @param target Fila contendo o alvo.
 * @param warhead Fila contendo a ogiva.
 * @param pont Ponteiro para a pontuação a ser modificada.
 * @param targetArea Área do alvo.
 * @param warheadArea Área da ogiva.
 * @param repeatedForm Indica se o formato é repetido ou não.
 */

void targetSmallerThanWarhead(Queue target, Queue warhead, double *pont, double targetArea, double warheadArea, int repeatedForm);

/**
 * @brief Calcula a retrocedência de um lançador com base em um deslocamento nas coordenadas.
 * 
 * @param l Ponteiro para o lançador a ser retrocedido.
 * @param dX Deslocamento nas coordenadas X.
 * @param dY Deslocamento nas coordenadas Y.
 * @param repeatedForm Indica se o formato é repetido ou não.
 */

void calcRewind(Launcher *l, double dX, double dY, int repeatedForm);

/**
 * @brief Trata a situação de falha, onde a ogiva não atinge o alvo.
 * 
 * @param target Fila contendo o alvo.
 * @param warhead Fila contendo a ogiva.
 * @param repeatedForm Indica se o formato é repetido ou não.
 */

void miss(Queue target, Queue warhead, int repeatedForm);

/**
 * @brief Cria uma cópia de um lançador e adiciona à fila.
 * 
 * @param l Ponteiro para o lançador a ser copiado.
 * @param id Ponteiro para o identificador a ser incrementado.
 * @param repeatedForm Indica se o formato é repetido ou não.
 */

void createClone(Launcher *l, int *id, int repeatedForm);

#endif