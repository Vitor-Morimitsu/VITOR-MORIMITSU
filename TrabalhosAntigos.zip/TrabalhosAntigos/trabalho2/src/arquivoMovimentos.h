#ifndef ARQUIVOMOVIMENTOS_H
#define ARQUIVOMOVIMENTOS_H

#include <stdio.h>
#include <stdlib.h>
#include "lancador.h"

/**
 * @brief Abre o arquivo com os movimentos (.qry).
 * 
 * @param m Ponteiro duplo para o endereço do arquivo.
 * @param qryPath Ponteiro para o caminho onde se encontra o arquivo qry.
 * @return A função não retorna nada, apenas faz o ponteiro apontar para o endereço do arquivo.
 * 
 * @details
 * A função tenta abrir o arquivo especificado pelo caminho `qryPath` no modo de leitura (`"r"`).
 * Se não for possível abrir o arquivo (por exemplo, se o arquivo não existir ou o sistema não tiver permissões suficientes),
 * a função exibe uma mensagem de erro e encerra o programa com `exit(1)`.
 * 
 * @note O ponteiro para o arquivo será atualizado com o resultado de `fopen`. 
 * Certifique-se de fechar o arquivo após usá-lo para evitar vazamentos de recursos.
 * 
 * @warning Se o arquivo não puder ser aberto, o programa será encerrado.
 */

void openMovementsFile(FILE **m, char *qryPath);

/**
 * @brief Faz a leitura do arquivo de movimentos (.qry).
 * 
 * @param m Ponteiro para o endereço do arquivo.
 * @param lRect Ponteiro para o lançador de retângulos.
 * @param lCircle Ponteiro para o lançador de círculos.
 * @param lText Ponteiro para o lançador de texto.
 * @param lLine Ponteiro para o lançador de Linhas.
 * @param pont Ponteiro para a variável de pontuação.
 * @param id Ponteiro para o id da última forma implementada.
 * @param sTxt Ponteiro duplo para o arquivo de texto com a descrição dos acontecimentos do jogo.
 * @param totalLaunch Ponteiro para a variável referente a quantidade total de lançamentos.
 * @param totalInstructions Ponteiro para a variável referente a quantidade total de instruções.
 * @param createdForms Ponteiro para a variável refente a quantidade total de formas criadas.
 * @param destroyedForms Ponteiro para a variável refente a quantidade total de formas destruídas.
 * @return A função não retorna nada, apenas faz a leitura de cada linha do arquivo de movimentos e executa a função processLineMoves.
 * 
 * @details
 * A função lê cada linha do arquivo especificado e interpreta o tipo de movimento 
 * através do comando identificado. Em seguida, delega o processamento à função 
 * `processLineMoves`. 
 * 
 * - Cada linha do arquivo deve conter um comando válido para ser processado.
 * - Se o arquivo não puder ser aberto, a função exibe uma mensagem de erro e retorna.
 * - Após a leitura, o arquivo é fechado automaticamente.
 * 
 * @note Certifique-se de que o arquivo fornecido no parâmetro `m` está aberto no modo leitura.
 * @warning O formato da linha no arquivo deve ser compatível com o esperado pela função `processLineMoves`.
 */

void readMovementsFile(FILE *m, Launcher *lRect, Launcher *lCircle, Launcher *lText, Launcher *lLine, double *pont, int *id, FILE **sTxt, int *totalLaunch, int *totalInstructions, int *createdForms, int *destroyedForms);

/**
 * @brief Faz o processamento de cada linha do arquivo de movimentos verificando se será executado o posicionamento de lançador ou o lançamento duplo de formas.
 * 
 * @param line Ponteiro para a linha extraída da função readMovementsFile.
 * @param moveType O tipo de movimento a ser executado ("rt" para rotação ou "lc" para lançamento duplo).
 * @param lRect Ponteiro para o lançador de retângulos.
 * @param lCircle Ponteiro para o lançador de círculos.
 * @param lText Ponteiro para o lançador de texto.
 * @param lLine Ponteiro para o lançador de Linhas.
 * @param pont Ponteiro para a variável de pontuação.
 * @param id Ponteiro para o id da última forma implementada.
 * @param sTxt Ponteiro duplo para o arquivo de texto com a descrição dos acontecimentos do jogo.
 * @param totalLaunch Ponteiro para a variável referente a quantidade total de lançamentos.
 * @param totalInstructions Ponteiro para a variável referente a quantidade total de instruções.
 * @param createdForms Ponteiro para a variável refente a quantidade total de formas criadas.
 * @param destroyedForms Ponteiro para a variável refente a quantidade total de formas destruídas.
 * @return A função não retorna nada, apenas faz a leitura de cada linha do arquivo de movimentos e executa a função processLineMoves.
 * 
 * @details
 * - Se `moveType` for "rt", a função executa uma rotação do launcher especificado.
 * - Se `moveType` for "lc", a função realiza um lançamento duplo entre dois launchers.
 * - O tipo de launcher é identificado pelas letras "T", "R", "L" e "C" (Texto, Retângulo, Linha e Círculo, respectivamente).
 * - Incrementa contadores relevantes com base na operação executada.
 * 
 * @note Essa função assume que o arquivo de movimentos não esteja vazio para que possa ser realizados os lançamentos e posicionamento de lançadores.
 */

void processLineMoves(char *line, char *moveType, Launcher *lRect, Launcher *lCircle, Launcher *lText, Launcher *lLine, double *pont, int *id, FILE **sTxt, int *totalLaunch, int *totalInstructions, int *createdForms, int *destroyedForms);

#endif