#ifndef RETANGULO_H
#define RETANGULO_H

typedef void *Rectangle;

/**
 * @brief Cria e inicializa um novo retângulo com os valores fornecidos.
 *
 * @param id Identificador único para o retângulo.
 * @param x Coordenada x do ponto superior esquerdo do retângulo.
 * @param y Coordenada y do ponto superior esquerdo do retângulo.
 * @param w Largura do retângulo.
 * @param h Altura do retângulo.
 * @param corb Cor de borda do retângulo (como string).
 * @param corp Cor de preenchimento do retângulo (como string).
 *
 * @return Retorna um ponteiro para o retângulo recém-criado, ou NULL em caso de erro de alocação de memória.
 */

Rectangle createRectangle(int id, double x, double y, double w, double h, char * corb, char *corp);

/**
 * @brief Obtém o identificador único do retângulo.
 *
 * @param r Retângulo para o qual o identificador será recuperado.
 *
 * @return O identificador do retângulo.
 */

int getIdRect (Rectangle r);

/**
 * @brief Obtém a coordenada x do retângulo.
 *
 * @param r Retângulo para o qual a coordenada x será recuperada.
 *
 * @return A coordenada x do retângulo.
 */

double getXRect(Rectangle r);

/**
 * @brief Obtém a coordenada y do retângulo.
 *
 * @param r Retângulo para o qual a coordenada y será recuperada.
 *
 * @return A coordenada y do retângulo.
 */

double getYRect(Rectangle r);

/**
 * @brief Obtém a largura do retângulo.
 *
 * @param r Retângulo para o qual a largura será recuperada.
 *
 * @return A largura do retângulo.
 */

double getWRect(Rectangle r);

/**
 * @brief Obtém a altura do retângulo.
 *
 * @param r Retângulo para o qual a altura será recuperada.
 *
 * @return A altura do retângulo.
 */ 

double getHRect(Rectangle r);

/**
 * @brief Calcula a área de um retângulo com base na largura e altura fornecidas.
 *
 * @param w Largura do retângulo.
 * @param h Altura do retângulo.
 *
 * @return A área do retângulo.
 */

double calcAreaRect(double w, double h);

/**
 * @brief Obtém a cor de borda do retângulo.
 *
 * @param r Retângulo para o qual a cor de borda será recuperada.
 *
 * @return A cor de borda do retângulo.
 */

char *getCorbRect(Rectangle r);

/**
 * @brief Obtém a cor de preenchimento do retângulo.
 *
 * @param r Retângulo para o qual a cor de preenchimento será recuperada.
 *
 * @return A cor de preenchimento do retângulo.
 */

char *getCorpRect(Rectangle r);

/**
 * @brief Define a coordenada x do retângulo.
 *
 * @param r Retângulo para o qual a coordenada x será modificada.
 * @param x Nova coordenada x a ser definida.
 */

void setXRect(Rectangle r, double x);

/**
 * @brief Define a coordenada y do retângulo.
 *
 * @param r Retângulo para o qual a coordenada y será modificada.
 * @param y Nova coordenada y a ser definida.
 */

void setYRect(Rectangle r, double y);

/**
 * @brief Define a largura do retângulo.
 *
 * @param r Retângulo para o qual a largura será modificada.
 * @param w Nova largura a ser definida.
 */

void setWRect(Rectangle r, double w);

/**
 * @brief Define a altura do retângulo.
 *
 * @param r Retângulo para o qual a altura será modificada.
 * @param h Nova altura a ser definida.
 */

void setHRect(Rectangle r, double h);

/**
 * @brief Define a cor de borda do retângulo.
 *
 * @param r Retângulo para o qual a cor de borda será modificada.
 * @param corB Nova cor de borda a ser definida.
 */

void setCorbRect(Rectangle r, char *corB);

/**
 * @brief Define a cor de preenchimento do retângulo.
 *
 * @param r Retângulo para o qual a cor de preenchimento será modificada.
 * @param corP Nova cor de preenchimento a ser definida.
 */

void setCorpRect(Rectangle r, char *corP);

#endif