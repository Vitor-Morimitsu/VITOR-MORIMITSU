#ifndef LANCADOR_H
#define LANCADOR_H

#include "stdbool.h"
#include <stdio.h>
#include <stdlib.h>

typedef void *Launcher;
typedef void *Queue;

/**
 * @brief Cria e inicializa um lançador.
 * 
 * @param q Ponteiro para a fila de elementos associados ao lançador.
 * @param id Identificador do tipo do lançador (1: Retângulo, 2: Círculo, 3: Linha, 4: Texto).
 * @return Ponteiro para o lançador criado.
 * 
 * @note O programa será encerrado com `exit(1)` caso ocorra falha na alocação de memória.
 */

Launcher createLauncher(Queue *q, int id);

/**
 * @brief Obtém a fila associada a um lançador.
 * 
 * @param l Ponteiro para o lançador.
 * @return Ponteiro para a fila associada ao lançador.
 * 
 * @note Comportamento indefinido se `l` for nulo.
 */

Queue getQueueLauncher(Launcher *l);

/**
 * @brief Retorna o identificador do tipo do lançador.
 * 
 * @param l Ponteiro para o lançador.
 * @return Inteiro representando o identificador do tipo do lançador.
 * 
 * @note Comportamento indefinido se `l` for nulo.
 */

int getIdLauncher(Launcher *l);

/**
 * @brief Recupera o ângulo atual do lançador.
 * 
 * @param l Ponteiro para o lançador.
 * @return Ângulo do lançador em graus.
 * 
 * @note Comportamento indefinido se `l` for nulo.
 */

double getLauncherDegree(Launcher *l);

/**
 * @brief Atualiza a posição do lançador para o ângulo especificado e registra a operação.
 * 
 * @param launc Ponteiro para o lançador.
 * @param d Novo ângulo do lançador em graus.
 * @param sTxt Ponteiro para um arquivo onde a operação será registrada.
 * 
 */

void positionLauncher(Launcher *launc, double degree, FILE **sTxt);

/**
 * @brief Realiza o lançamento de um único elemento, calculando e atualizando sua posição.
 * 
 * @param launcRef Ponteiro para o lançador.
 * @param d Distância do lançamento.
 * @param sTxt Ponteiro para um arquivo onde as informações serão registradas.
 * 
 * @note A função valida se o lançador ou sua fila são nulos.
 */

void singleLaunch(Launcher *launcRef, double d, FILE **sTxt);

/**
 * @brief Realiza o lançamento de um único elemento - vindo de um lançador já usado no lançamento duplo -, calculando e atualizando sua posição, mantendo a forma.
 * 
 * @param launcRef Ponteiro para o lançador.
 * @param d Distância do lançamento.
 * @param sTxt Ponteiro para um arquivo onde as informações serão registradas.
 * 
 */

void singleLaunchSameForm(Launcher *launcRef, double d, FILE **sTxt);

/**
 * @brief Realiza dois lançamentos de formas (uma de um lançador e outra de uma ogiva) e verifica colisão entre elas.
 * 
 * @param launcA Ponteiro para o primeiro lançador.
 * @param dA Distância do primeiro lançamento.
 * @param launcB Ponteiro para o segundo lançador (ogiva).
 * @param dB Distância do segundo lançamento (ogiva).
 * @param pont Ponteiro para o valor de pontos a ser atualizado com base nos lançamentos.
 * @param id Identificador da colisão, atualizado com o status da colisão.
 * @param sTxt Ponteiro para o arquivo onde as informações serão registradas.
 * @param destroyedForms Ponteiro para o número de formas destruídas, que será atualizado.
 * @param createdForms Ponteiro para o número de formas criadas, que será atualizado.
 * @param repeatedForm Flag indicando se o formato foi repetido (0: não, 1: sim).
 * 
 * @note Atualiza os valores de `destroyedForms` e `createdForms` com base no resultado da colisão.
 */

void doubleLaunch(Launcher *launcA, double dA, Launcher *launcB, double dB, double *pont, int *id, FILE **sTxt, int *destroyedForms, int *createdForms, int repeatedForm);

/**
 * @brief Calcula a área de uma forma associada a um lançador.
 * 
 * @param launc Ponteiro para o lançador.
 * @param repeatedForm Flag indicando se o formato foi repetido (0: não, 1: sim).
 * @return A área da forma associada ao lançador.
 * 
 * @note Retorna 0.0 em caso de erro ou identificador de forma inválido.
 */

double returnAreaForm(Launcher *launc, int repeatedForm);

/**
 * @brief Verifica o tipo de colisão entre dois Launchers e executa a verificação de interseção
 *        dependendo das formas envolvidas (Retângulo, Círculo, Linha ou Texto).
 *
 * @param launcA Launcher que representa o primeiro objeto a ser verificado.
 * @param launcB Launcher que representa o segundo objeto a ser verificado.
 * @param sTxt Ponteiro para o arquivo onde as coordenadas finais e informações serão impressas.
 *
 * @return Retorna true se houver interseção entre os objetos, caso contrário, retorna false.
 */

bool selectedColisionType(Launcher launcA, Launcher launcB, FILE **sTxt);

/**
 * @brief Seleciona o tipo de lançador e registra sua posição.
 * 
 * @param launc Ponteiro para o lançador.
 * @param d Ângulo atual do lançador em graus.
 * @param sTxt Ponteiro para um arquivo onde as informações serão registradas.
 * 
 */

void selectLauncherType(Launcher *launc, double d, FILE **sTxt);

/**
 * @brief Calcula a distância em uma direção específica a partir do ângulo.
 * 
 * @param degree Ângulo em graus.
 * @param d Distância total.
 * @param axle Eixo de cálculo (0: eixo X, 1: eixo Y).
 * @return A distância calculada no eixo especificado.
 * 
 * @note Retorna 0 se o eixo especificado for inválido.
 */

double calculaDistancia(double degree, double d, int axle);

#endif