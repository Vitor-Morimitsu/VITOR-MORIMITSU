#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcoesArquivo.h"
#include "retangulo.h"
#include "circulo.h"
#include "linha.h"
#include "texto.h"
#include "fila.h"
#include "lancador.h"

#define MAX_FONT 64
#define MAX_COLOR 8
#define MAX_TEXT 1024

void openFile(File **f, char *geoPath) {
    *f = fopen(geoPath, "r");
    if (*f == NULL) {
        printf("Erro na abertura do arquivo!\n");
        exit(1);
    }
}

void readFile(File *f, Launcher *lRect, Launcher *lCircle, Launcher *lLine, Launcher *lText, TxtStyle *ts, File *s, int *id, int *createdForms) {
    if (f == NULL) {
        printf("Arquivo não foi aberto");
        return;
    }

    char line[256];
    char tipoArquivo[3];
    while (fgets(line, sizeof(line), f)) {
        int i = 0;
        while (line[i] != ' ' && line[i] != '\0') { // Compara com o caractere nulo
            tipoArquivo[i] = line[i];
            i++;
        }
        tipoArquivo[i] = '\0';
        processLineForms(line, tipoArquivo, getQueueLauncher(lRect), getQueueLauncher(lCircle), getQueueLauncher(lText), getQueueLauncher(lLine), ts, s, id, createdForms);
        tipoArquivo[0] = '\0';
    }

    if (f != NULL) {
        fclose(f);

    }
}

void processLineForms(char *line, char *tipoArquivo, Queue *qRect, Queue *qCircle, Queue *qText, Queue *qLine, TxtStyle *ts, File *s, int *idFormas, int *createdForms) {
    int id;
    double x, x2, y, y2, r, w, h;
    char corb[MAX_COLOR], corp[MAX_COLOR], cor[MAX_COLOR], a[2];
    char font[MAX_FONT], size[MAX_FONT], weight[MAX_FONT];
    char txto[MAX_TEXT], type[3];
   
    if (strcmp(tipoArquivo, "t") == 0) {
        sscanf(line, "%2s %d %lf %lf %7s %7s %1s %1023[^\n]", type, &id, &x, &y, corb, corp, a, txto);
        insertQueue(qText, createText(id, x, y, corb, corp, a, txto));
        *createdForms = *createdForms+1;
    } else if (strcmp(tipoArquivo, "c") == 0) {
        sscanf(line, "%2s %d %lf %lf %lf %7s %7s", type, &id, &x, &y, &r, corp, corb);
        insertQueue(qCircle, createCircle(id, x, y, r, corb, corp));
        *createdForms = *createdForms+1;
    } else if (strcmp(tipoArquivo, "r") == 0) {
        sscanf(line, "%2s %d %lf %lf %lf %lf %7s %7s", type, &id, &x, &y, &w, &h, corb, corp); 
        insertQueue(qRect, createRectangle(id, x, y, w, h, corb, corp));
        *createdForms = *createdForms+1;
    } else if (strcmp(tipoArquivo, "l") == 0) {
        sscanf(line, "%2s %d %lf %lf %lf %lf %7s", type, &id, &x, &y, &x2, &y2, cor);
        insertQueue(qLine, createLine(id, x, x2, y, y2, cor));
        *createdForms = *createdForms+1;
    } else if (strcmp(tipoArquivo, "ts") == 0) {
        sscanf(line, "%2s %255s %1s %255s", type, font, weight, size);
        setFamily(ts, font);
        setWeight(ts, weight);
        setSize(ts, size);
    } else {
        printf("A forma solicitada não está no registro: %s\n", line);
    }
    *idFormas = id;

}