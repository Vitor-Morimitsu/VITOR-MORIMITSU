#ifndef TRATANOMEARQUIVO_H
#define TRATANOMEARQUIVO_H

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

/**
 * @brief Manipula o caminho do arquivo fornecido removendo a barra final (se presente) e copia para o destino.
 *
 * Esta função modifica a string `path` com o conteúdo de `arg`, removendo a barra final se ela estiver presente.
 *
 * @param path [out] O caminho do arquivo a ser preenchido.
 * @param tamMax O tamanho máximo do caminho permitido.
 * @param arg O caminho do arquivo de origem que será manipulado.
 */

void trataPath(char *path, int tamMax, char *arg);

/**
 * @brief Adiciona a extensão ".txt" ao nome do arquivo fornecido.
 *
 * A função cria um nome de arquivo no formato "arg.txt", onde `arg` é o nome do arquivo fornecido.
 *
 * @param path [out] O caminho final do arquivo com a extensão ".txt".
 * @param tamMax O tamanho máximo do caminho permitido.
 * @param arg O nome do arquivo a ser formatado.
 */

void trataNomeArquivo(char *path, int tamMax, char *arg);

/**
 * @brief Combina os nomes dos arquivos geográficos e de consulta para gerar um caminho de saída.
 *
 * A função cria um caminho de saída combinando o nome do arquivo geográfico (`geoName`) e o nome do arquivo de consulta (`qryName`).
 * Se o nome do arquivo de consulta não for fornecido, apenas o nome do arquivo geográfico é usado.
 *
 * @param geoName Nome do arquivo geográfico.
 * @param qryName Nome do arquivo de consulta (opcional).
 * @param exitPath [out] O caminho de saída combinado.
 * @param size O tamanho máximo do caminho de saída.
 */

void archiveNameCombination(char *geoName, char *qryName, char *exitPath, int size);

#endif