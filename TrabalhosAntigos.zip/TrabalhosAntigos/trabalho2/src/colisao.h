#ifndef CRIARSVG_H
#define CRIARSVG_H

/**
 * @brief Verifica se dois retângulos se intersectam.
 * 
 * @param x1 Coordenada x do canto superior esquerdo do primeiro retângulo.
 * @param y1 Coordenada y do canto superior esquerdo do primeiro retângulo.
 * @param w1 Largura do primeiro retângulo.
 * @param h1 Altura do primeiro retângulo.
 * @param x2 Coordenada x do canto superior esquerdo do segundo retângulo.
 * @param y2 Coordenada y do canto superior esquerdo do segundo retângulo.
 * @param w2 Largura do segundo retângulo.
 * @param h2 Altura do segundo retângulo.
 * 
 * @return `true` se os retângulos se intersectam, caso contrário, `false`.
 */

bool rectangleIntersection(double x1, double y1, double w1, double h1, double x2, double y2, double w2, double h2);

/**
 * @brief Verifica se dois círculos se intersectam.
 * 
 * @param x1 Coordenada x do centro do primeiro círculo.
 * @param y1 Coordenada y do centro do primeiro círculo.
 * @param r1 Raio do primeiro círculo.
 * @param x2 Coordenada x do centro do segundo círculo.
 * @param y2 Coordenada y do centro do segundo círculo.
 * @param r2 Raio do segundo círculo.
 * 
 * @return `true` se os círculos se intersectam, caso contrário, `false`.
 */

bool circleIntersection(double x1, double y1, double r1, double x2, double y2, double r2);

/**
 * @brief Verifica se um círculo e um retângulo se intersectam.
 * 
 * @param cx Coordenada x do centro do círculo.
 * @param cy Coordenada y do centro do círculo.
 * @param r Raio do círculo.
 * @param rx Coordenada x do canto superior esquerdo do retângulo.
 * @param ry Coordenada y do canto superior esquerdo do retângulo.
 * @param rw Largura do retângulo.
 * @param rh Altura do retângulo.
 * 
 * @return `true` se o círculo e o retângulo se intersectam, caso contrário, `false`.
 */

bool circleRectangleIntersection(double cx, double cy, double r, double rx, double ry, double rw, double rh);

/**
 * @brief Verifica se duas linhas se intersectam.
 * 
 * @param x1 Coordenada x do ponto inicial da primeira linha.
 * @param y1 Coordenada y do ponto inicial da primeira linha.
 * @param x2 Coordenada x do ponto final da primeira linha.
 * @param y2 Coordenada y do ponto final da primeira linha.
 * @param x3 Coordenada x do ponto inicial da segunda linha.
 * @param y3 Coordenada y do ponto inicial da segunda linha.
 * @param x4 Coordenada x do ponto final da segunda linha.
 * @param y4 Coordenada y do ponto final da segunda linha.
 * 
 * @return `true` se as linhas se intersectam, caso contrário, `false`.
 */

bool linesIntersection(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4);

/**
 * @brief Verifica se uma linha e um retângulo se intersectam.
 * 
 * @param lx1 Coordenada x do ponto inicial da linha.
 * @param ly1 Coordenada y do ponto inicial da linha.
 * @param lx2 Coordenada x do ponto final da linha.
 * @param ly2 Coordenada y do ponto final da linha.
 * @param rx Coordenada x do canto superior esquerdo do retângulo.
 * @param ry Coordenada y do canto superior esquerdo do retângulo.
 * @param rw Largura do retângulo.
 * @param rh Altura do retângulo.
 * 
 * @return `true` se a linha e o retângulo se intersectam, caso contrário, `false`.
 */

bool lineRectangleIntersection(double lx1, double ly1, double lx2, double ly2, double rx, double ry, double rw, double rh);

/**
 * @brief Verifica se uma linha e um círculo se intersectam.
 * 
 * @param lx1 Coordenada x do ponto inicial da linha.
 * @param ly1 Coordenada y do ponto inicial da linha.
 * @param lx2 Coordenada x do ponto final da linha.
 * @param ly2 Coordenada y do ponto final da linha.
 * @param cx Coordenada x do centro do círculo.
 * @param cy Coordenada y do centro do círculo.
 * @param r Raio do círculo.
 * 
 * @return `true` se a linha e o círculo se intersectam, caso contrário, `false`.
 */

bool lineCircleIntersection(double lx1, double ly1, double lx2, double ly2, double cx, double cy, double r);

/**
 * @brief Verifica se um texto e uma linha se intersectam.
 * 
 * @param tx Coordenada x do texto.
 * @param ty Coordenada y do texto.
 * @param num_caracteres Número de caracteres do texto.
 * @param lx1 Coordenada x do ponto inicial da linha.
 * @param ly1 Coordenada y do ponto inicial da linha.
 * @param lx2 Coordenada x do ponto final da linha.
 * @param ly2 Coordenada y do ponto final da linha.
 * @param tipo Tipo de alinhamento do texto ('i', 'm' ou 'f').
 * 
 * @return `true` se o texto e a linha se intersectam, caso contrário, `false`.
 */

bool textLineIntersection(double tx, double ty, int num_caracteres, double lx1, double ly1, double lx2, double ly2, char tipo);

/**
 * @brief Verifica se um texto e um retângulo se intersectam.
 * 
 * @param tx Coordenada x do texto.
 * @param ty Coordenada y do texto.
 * @param num_caracteres Número de caracteres do texto.
 * @param rx Coordenada x do canto superior esquerdo do retângulo.
 * @param ry Coordenada y do canto superior esquerdo do retângulo.
 * @param rw Largura do retângulo.
 * @param rh Altura do retângulo.
 * @param tipo Tipo de alinhamento do texto ('i' - início, 'm' - meio, 'f' - fim).
 * 
 * @return `true` se o texto e o retângulo se intersectam, caso contrário, `false`.
 */

bool textRectangleIntersection(double tx, double ty, int num_caracteres, double rx, double ry, double rw, double rh, char tipo);

/**
 * @brief Verifica se um texto e um círculo se intersectam.
 * 
 * @param tx Coordenada x do texto.
 * @param ty Coordenada y do texto.
 * @param num_caracteres Número de caracteres do texto.
 * @param cx Coordenada x do centro do círculo.
 * @param cy Coordenada y do centro do círculo.
 * @param r Raio do círculo.
 * @param tipo Tipo de alinhamento do texto ('i' - início, 'm' - meio, 'f' - fim).
 * 
 * @return `true` se o texto e o círculo se intersectam, caso contrário, `false`.
 */

bool textCircleIntersection(double tx, double ty, int num_caracteres, double cx, double cy, double r, char tipo);

/**
 * @brief Verifica se dois textos se intersectam.
 * 
 * @param tx Coordenada x do primeiro texto.
 * @param ty Coordenada y do primeiro texto.
 * @param num_caracteres Número de caracteres do primeiro texto.
 * @param tipo Tipo de alinhamento do primeiro texto ('i' - início, 'm' - meio, 'f' - fim).
 * @param t2x Coordenada x do segundo texto.
 * @param t2y Coordenada y do segundo texto.
 * @param num_caracteres2 Número de caracteres do segundo texto.
 * @param tipo2 Tipo de alinhamento do segundo texto ('i' - início, 'm' - meio, 'f' - fim).
 * 
 * @return `true` se os dois textos se intersectam, caso contrário, `false`.
 */

bool textIntersection(double tx, double ty, int num_caracteres,  char tipo, double t2x, double t2y, int num_caracteres2,  char tipo2);

#endif