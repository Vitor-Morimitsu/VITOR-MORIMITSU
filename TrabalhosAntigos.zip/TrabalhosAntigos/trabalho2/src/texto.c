#include "texto.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"

typedef struct txtStyle {
    char *family;
    char *weight;
    char *size;
} txtStyle;

typedef struct txt {
    int i;
    double x, y;
    char *corb, *corp, *a, *txto;
    txtStyle style;
} Txt;

TxtStyle createTxtStyle(char *family, char *weight, char *size) {
    txtStyle *tS = (txtStyle *)malloc(sizeof(txtStyle));
    if (tS == NULL) {
        printf("Erro na alocação de memória na criação do texto");
        exit(1);
    }

    tS->family = (char *)malloc(strlen(family)+1);
    if (tS->family == NULL) {
        printf("Erro na alocação de memória da font-family");
        exit(1);
    }
    strcpy(tS->family, "");

    tS->weight = (char *)malloc(strlen(weight)+1);
    if (tS->weight == NULL) {
        printf("Erro na alocação de memória do comprimento do texto");
        exit(1);
    }
    strcpy(tS->weight, "");

    tS->size = (char *)malloc(strlen(size)+1);
    if (tS->size == NULL) {
        printf("Erro na alocação de memória do font-size");
        exit(1);
    }
    strcpy(tS->size, "");

    return tS;
}

Text createText(int id, double x, double y, char *corb, char *corp, char *a, char *txto) {
    Txt *t = (Txt *)malloc(sizeof(Txt));
    if (t == NULL) {
        printf("Erro na alocação de memória na criação do texto");
        exit(1);
    }

    t->i = id;
    t->x = x;
    t->y = y;
    
    t->corb = (char *)malloc(strlen(corb)+1);
    if (t->corb == NULL) {
        printf("Erro na alocação de memória da cor de borda");
        exit(1);
    }
    strcpy(t->corb, corb);

    t->corp = (char *)malloc(strlen(corp)+1);
    if (t->corp == NULL) {
        printf("Erro na alocação de memória da cor de preenchimento");
        exit(1);
    }
    strcpy(t->corp, corp);

    t->a = (char *)malloc(strlen(a)+1);
    if (t->a == NULL) {
        printf("Erro na alocação de memória na criação da âncora");
        exit(1);
    }
    strcpy(t->a, a);

    t->txto = (char *)malloc(strlen(txto)+1);
    if (t->txto == NULL) {
        printf("Erro na alocação de memória no texto");
        exit(1);
    }
    strcpy(t->txto, txto);

    return t;
}

// Funções para txtStyle
char *getFamily(TxtStyle tS) {
    return ((txtStyle*)tS)->family;
}

char *getWeight(TxtStyle tS) {
    return ((txtStyle*)tS)->weight;
}

char *getSize(TxtStyle tS) {
    return ((txtStyle*)tS)->size;
}

void setFamily(TxtStyle tS, char *family) { 
    strcpy(((txtStyle*)tS)->family, family);
}

void setWeight(TxtStyle tS, char *weight) {
    strcpy(((txtStyle*)tS)->weight, weight);
}

void setSize(TxtStyle tS, char *size) {
    strcpy(((txtStyle*)tS)->size, size);
}

int getIdText (Text t) {
    return ((Txt*)t)->i;
}

double getXText(Text t) {
    return ((Txt*)t)->x;
}

double getYText(Text t) {
    return ((Txt*)t)->y;
}

double calcAreaText(char *txto) {
    return 10.0 * strlen(txto);
}

char *getCorbText(Text t) {
    return ((Txt*)t)->corb;
}

char *getCorpText(Text t) {
    return ((Txt*)t)->corp;
}

char *getAText(Text t) {
    return ((Txt*)t)->a;
}

char *getTxtoText(Text t) {
    return ((Txt*)t)->txto;
}

void setXText(Text t, double x) {
    ((Txt*)t)->x = x;
}

void setYText(Text t, double y) {
    ((Txt*)t)->y = y;
}

void setCorbText(Text t, char *corB) {
    strcpy(((Txt*)t)->corb, corB);
}

void setCorpText(Text t, char *corP) {
    strcpy(((Txt*)t)->corp, corP);
}

void setAText(Text t, char *a) {
    strcpy(((Txt*)t)->a, a);
}

void setTxtoText(Text t, char *txto) {
    strcpy(((Txt*)t)->txto, txto);
}
