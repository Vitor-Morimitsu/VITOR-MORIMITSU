#include "criarTxt.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "circulo.h"
#include "retangulo.h"
#include "texto.h"
#include "linha.h"

void openTxtFile(File **saida, char *exitPath) {
    *saida = fopen(exitPath, "w");
    if (*saida == NULL) {
        printf("Memória não alocada!");
        exit(1);
    }
}

void printCommandLine(File **saida, char *command) {
    fprintf(saida, "[*] %s", command);
}

void printPositionLauncher(File **saida, int degree, char *formType) {
    fprintf(saida, "Tipo de Forma: %s\nÂngulo de abertura: %d\n\n", formType, degree);
}

void printTargetInfo(File **saida, int typeTarget) {
    fprintf(saida, "ALVO: %s\n", returnNameLauncher(typeTarget));
}

void printWarheadInfo(File **saida, int typeWarhead) {
    fprintf(saida, "OGIVA: %s\n", returnNameLauncher(typeWarhead));
}

char *returnNameLauncher(int type) {
    switch (type)
    {
    case 1:
        return "Retângulo";
        break;
    case 2:
        return "Círculo";
        break;
    case 3:
        return "Linha";
        break;
    case 4:
        return "Texto";
        break;
    default:
        break;
    }
}

void printCircleInfo(File **saida, int id, double x, double y, double r, char *corb, char *corp) {
    fprintf(saida, "ID: %d;\nCOORDENADAS: X->%lf, Y->%lf;\nRAIO->%lf;\nCor de Borda: %s;\nCor de Preenchimento: %s\n\n", id, x, y, r, corb, corp);
}

void printRectInfo(File **saida, int id, double x, double y, double h, double w, char *corb, char *corp) {
    fprintf(saida, "ID: %d;\nCOORDENADAS: X->%lf, Y->%lf;\nALTURA->%lf, LARGURA->%lf;\nCor de Borda: %s;\nCor de Preenchimento: %s\n\n", id, x, y, h, w, corb, corp);
}

void printLineInfo(File **saida, int id, double x, double y, double x2, double y2, char *cor) {
    fprintf(saida, "ID: %d\nCOORDENADAS: X->%lf, Y->%lf, X2->%lf; Y2->%lf;\nCor: %s\n\n", id, x, y, x2, y2, cor);
}

void printTextInfo(File **saida, int id, double x, double y, char *corb, char *corp, char *a, char *txto) {
    fprintf(saida, "ID: %d\nCOORDENADAS: X->%lf, Y->%lf;\nCor de Borda: %s;\nCor de Preenchimento: %s\nÂncora do texto: %s\nConteúdo do texto: %s\n\n", id, x, y, corb, corp, a, txto);
}

void printFinalCoord(File **saida, char *form, double x, double y) {
    fprintf(saida, "Coordenadas Finais %s: X->%lf, Y->%lf;\n", form, x, y);
}

void printFinalCoordLine(File **saida, char *form, double x1, double y1, double x2, double y2) {
    fprintf(saida, "Coordenadas Finais %s: X->%lf, Y->%lf, X2->%lf, Y2->%lf\n", form, x1, y1, x2, y2);
}

void finalStatusLaunch(File **saida, char *targetSituation, char *warheadSituation, char *launchSituation) {
    fprintf(saida, "\nSituação de Lançamento: %s;\nSituação do Alvo: %s;\nSituação da Ogiva: %s;\n\n", launchSituation, targetSituation, warheadSituation);
}

void printGameResults(File **saida, double pont, int instructions, int totalLaunch, int destroyedForms, int createdForms) {
    fprintf(saida, "\n|Resultados|\n-> Pontuação Final: %.2lf;\n-> Número Total de Instruções: %d;\n-> Número Total de Lançamentos: %d;\n-> Número de Formas Destruídas: %d;\n-> Número de Formas Criadas: %d.", pont, instructions, totalLaunch, destroyedForms, createdForms);
}