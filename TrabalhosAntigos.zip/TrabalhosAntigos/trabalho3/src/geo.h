#ifndef GEO_H
#define GEO_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "smutreap.h"
#include "texto.h"

/*
    Arquivo .h relacionado ao processamento e leitura do arquivo .geo.
*/

/// @brief realiza a leitura do .geo dado e preenche a SmuTreap com as suas informações
/// @param svg1 arquivo svg inicial que será gerado por meio da leitura do .geo
/// @param arqgeo arquivo geo que será lido
/// @param dot1 nome do arquivo dot que será gerado após leitura do .geo
/// @param hitCount numero máximo que um node na SmuTreap pode ser acessado antes de sua promoção
/// @param promRate numero multplicativo usado para a promoção de um node na SmuTreap
/// @param prioMax prioridade maxima na qual as prioridades serão geradas para a SmuTreap
/// @param maiorID valor inicilamente igual a 0, será preenchido com o maior id registrado no .geo
/// @return retorna a SmuTreap preenchida com as informações do .geo 
SmuTreap LeituraCompletaGeo(FILE **svg1, FILE *arqgeo, char *dot1, int *hitCount, double *promRate, int *prioMax, int *maiorID);

/// @brief realiza o processamento e preparação do .geo a ser lido 
/// @param pathgeo path do .geo a ser acessado e lido
/// @param dirsaida path dos diretorios de saida
/// @param nomegeo nome do arquivo geo
/// @param hitCount numero máximo que um node na SmuTreap pode ser acessado antes de sua promoção
/// @param promRate numero multplicativo usado para a promoção de um node na SmuTreap
/// @param prioMax prioridade maxima na qual as prioridades serão geradas para a SmuTreap
/// @param maiorID valor inicilamente igual a 0, será preenchido com o maior id registrado no .geo
/// @return retorna uma SmuTreap vazia para ser preenchida na função LeituraCompletaGeo
SmuTreap ProcessaGeo(const char *pathgeo, const char *dirsaida, const char *nomegeo, int *promCount, double *promRate, int *prioMax, int *maiorID);


#endif