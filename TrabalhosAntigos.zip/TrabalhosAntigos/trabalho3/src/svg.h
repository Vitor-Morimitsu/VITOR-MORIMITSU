#ifndef SVG_H
#define SVG_H

#include "leituraArquivo.h"
#include "circulo.h"
#include "retangulo.h"
#include "linha.h"
#include "texto.h"
#include "boundingbox.h"
#include "smutreap.h"

/*
    Arquivo .h relacionado ao tratamento e insercao de figuras e formas em um arquivo .svg.
*/

/// @brief inicia o cabecalho do svg ja aberto 
/// @param saida arquivo svg aberto para escrita
void startSVG(ArqLeitura saida);

/// @brief insere um circulo ao svg 
/// @param saida arquivo svg aberto para escrita
/// @param c circulo c
void insertCircleSVG(ArqLeitura saida, Circulo c);

/// @brief insere um retangulo ao svg 
/// @param saida arquivo svg aberto para escrita
/// @param r retangulo r
void insertRectSVG(ArqLeitura saida, Retangulo r);

/// @brief insere uma linha ao svg
/// @param saida arquivo svg aberto para escrita
/// @param l linha l
void insertLineSVG(ArqLeitura saida, Linha l);


/// @brief insere um texto ao svg
/// @param saida arquivo svg aberto para escrita
/// @param t texto t
void insertTextSVG(ArqLeitura saida, Texto t);


/// @brief escreve no svg o seu final com "</svg>\n"
/// @param saida arquivo svg aberto para escrita
void closeSVG(ArqLeitura saida);

/// @brief funcao especifica para a geracao do svg percorrendo a SmuTreap e inserindo suas informacoes em um svg
/// @param r Node r da SmuTreap
/// @param i Info i do node
/// @param x Ancora x do node
/// @param y Ancora y do node
/// @param aux void pointer para dados auxiliares para a funcao
void gerarSVG(Node r, Info i, double x, double y, void *aux);

#endif