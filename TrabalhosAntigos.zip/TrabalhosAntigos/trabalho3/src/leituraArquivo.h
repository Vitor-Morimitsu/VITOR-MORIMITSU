#ifndef LEITURAARQUIVO_H
#define LEITURAARQUIVO_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

typedef FILE* ArqLeitura;
/*
    Arquivo .h relacionado a tratamento de arquivos, operacoes basicas como abrir, fechar e ler linhas dos arquivos.
*/

/// @brief cria e abre para leitura um arquivo com nome fn
/// @param fn nome do arquivo a ser criado 
/// @return retorna o arquivo para leitura criado
ArqLeitura abreArquivoLeitura(char *fn);

/// @brief cria e abre para escrita um arquivo com nome fn
/// @param fn nome do arquivo a ser criado 
/// @return retorna o arquivo para escrita criado
ArqLeitura abreArquivoEscrita(char *fn);

/// @brief faz a leitura de uma linha do arquivo
/// @param arq arquivo a ser lido
/// @param linha string linha passada por referencia para receber toda a linha do arquivo
/// @param max_size tamanho maximo que a linha pode assumir
/// @return retorna true se a linha foi lida e associada, retorna false se chega ao fim do arquivo (linha vazia)
bool leituraLinha(FILE *arq, char *linha, int max_size);

/// @brief obtém o i-ésimo parâmetro de uma linha de texto separada por espaços
/// @param linha string contendo a linha original (será modificada pela função)
/// @param i índice do parâmetro a ser obtido (iniciando em 0)
void getParametroI(char *linha, int i);

/// @brief fecha o arquivo de leitura
/// @param arq arquivo de leitura a ser fechado
void fechaArquivoLeitura(FILE *arq);

#endif