#include "circulo.h"
#include "retangulo.h"
#include "texto.h"
#include "linha.h"
#include "smutreap.h"
#include "leituraArquivo.h"
#include "geo.h"
#include "boundingbox.h"
#include "svg.h"

#define MAX_SIZE 10000
#define TPC 0
#define TPL 1
#define TPR 2
#define TPT 3

SmuTreap LeituraCompletaGeo(FILE **svg1, FILE *arqgeo, char *dot1, int *hitCount, double *promRate, int *prioMax, int *maiorID) {
    double raio, xc, yc, x, y, w, h, x1, y1, x2, y2;
    int id; 
    char corp[300], corb[300], cor[300], txt[300], comando[10], tipo_forma, a;
    char family[300], weight[300], size[300];
    Estilo ts;

    SmuTreap t = newSmuTreap(*hitCount, *promRate, 0.0001, *prioMax);

    char linha[MAX_SIZE];
    char aux[MAX_SIZE];

    while(leituraLinha(arqgeo, linha, 1000)) {

        aux[0] = '\0'; // Esvazia a variavel aux e comando a cada iteracao
        comando[0] = '\0';
        strcpy(aux, linha);
        sscanf(aux, "%s", comando);

        if(strcmp(comando, "c") == 0) {
            sscanf(aux, "%c %d %lf %lf %lf %s %s", &tipo_forma, &id, &xc, &yc, &raio, corb, corp);
            insertSmuT(t, xc, yc, criarCirculo(id, xc, yc, raio, corb, corp, false, -1), TPC, calculaParametroBBCirculo);
            if(id > maiorID) maiorID = id;
        }

        else if(strcmp(comando, "ts") == 0) {
            sscanf(aux, "%2s %s %s %s", &tipo_forma, family, weight, size);
            ts = criarEstilo(family, weight, size);
        }

        else if(strcmp(comando, "r") == 0) {
            sscanf(aux, "%c %d %lf %lf %lf %lf %s %s", &tipo_forma, &id, &x, &y, &w, &h, corb, corp);
            insertSmuT(t, x, y, criarRetangulo(id, x, y, w, h, corb, corp, false, -1), TPR, calculaParametroBBRetangulo);
            if(id > maiorID) maiorID = id;
        }

        else if(strcmp(comando, "l") == 0) {
            sscanf(aux, "%c %d %lf %lf %lf %lf %s", &tipo_forma, &id, &x1, &y1, &x2, &y2, cor);
            insertSmuT(t, x1, y1, criarLinha(id, x1, y1, x2, y2, cor, false, -1), TPL, calculaParametroBBLinha);
            if(id > maiorID) maiorID = id;
        }

        else if(strcmp(comando, "t") == 0) {
            sscanf(aux, "%c %d %lf %lf %s %s %c \"%[^\"]\"", &tipo_forma, &id, &x, &y, corb, corp, &a, txt);
            insertSmuT(t, x, y, criarTexto(id, x, y, corb, corp, a, txt, ts, false, -1), TPT, calculaParametroBBTexto);
            if(id > maiorID) maiorID = id;
        }
    }
    visitaProfundidadeSmuT(t, gerarSVG, *svg1);
    printDotSmuTreap(t, dot1);
    return t;
}

SmuTreap ProcessaGeo(const char *pathgeo, const char *dirsaida, const char *nomegeo, int *promCount, double *promRate, int *prioMax, int *maiorID) {
    FILE *arqgeo = fopen(pathgeo, "r");
    printf("Diretorio do arquivo geo: %s\n", pathgeo);
    if (arqgeo==NULL) {
        fprintf(stderr, "Erro na abertura do arquivo GEO: %s\n", pathgeo);
        exit(1);
    }

    char saidasvg1[512];
    saidasvg1[0] = '\0';
    strcat(saidasvg1, dirsaida);
    strcat(saidasvg1, nomegeo);
    strcat(saidasvg1, ".svg");
    printf("Diretorio do arquivo svg1: %s\n", saidasvg1);

    FILE *svg1 = fopen(saidasvg1, "w");
    if (svg1==NULL) {
        fprintf(stderr, "Erro na criação do arquivo SVG: %s\n", saidasvg1);
        exit(1);
    }

    char saidadot1[512];
    saidadot1[0] = '\0';
    strcat(saidadot1, dirsaida);
    strcat(saidadot1, nomegeo);
    strcat(saidadot1, ".dot");
    printf("Diretorio do arquivo dot1: %s\n", saidadot1);

    fprintf(svg1, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    fprintf(svg1, "<svg width=\"2000\" height=\"2000\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\">\n");

    SmuTreap t = LeituraCompletaGeo(&svg1, arqgeo, saidadot1, promCount, promRate, prioMax, maiorID);

    fprintf(svg1, "</svg>\n");
    fclose(arqgeo);
    fclose(svg1);
    return t;
}

