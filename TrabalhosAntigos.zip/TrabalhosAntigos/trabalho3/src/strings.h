#ifndef STRINGS_H
#define STRINGS_H

/*
    Arquivo .h relacionado ao tratamento de strings e paths associados a arquivos.
*/

/// @brief concatena e conserta a string relacionada ao argumento .geo e a retorna ao main
/// @param arqgeo nome e path do arquivo .geo
/// @return retorna o nome para qual o .geo vai ser reconhecido
char* getNomeGeo(const char* arqgeo);

/// @brief concatena e conserta a string relacionada ao argumento .qry e a retorna ao main
/// @param arqqry nome e path do arquivo .qry
/// @return retorna o nome para qual o .qry vai ser reconhecido 
char* getNomeQry(const char* arqqry);


/// @brief trata, concatena e formata corretamente a string de diretorio para entrada e saida
/// @param str string de argumento do path de saida ou entrada
/// @return retorna o diretorio/path corretamente formatado
char* trataDirEntrada(const char* str);

/// @brief concatena o nome do arquivo de saida unindo o nome do arquivo .geo e do nome do caso teste
/// @param nomegeo string com nome do arquivo .geo
/// @param nomeqry string com nome do arquivo .qry
/// @return retorna a string concatenada do arquivo de saida
char* concatenaNomeQry(const char* nomegeo, const char* nomeqry);

#endif