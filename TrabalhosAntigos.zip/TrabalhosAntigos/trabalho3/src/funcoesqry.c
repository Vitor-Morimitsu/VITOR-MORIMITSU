#include "circulo.h"
#include "retangulo.h"
#include "linha.h"
#include "texto.h"
#include "smutreap.h"
#include "boundingbox.h"
#include <math.h>
#include "lista.h"
#include "svg.h"
#include <time.h>

#define TPC 0
#define TPL 1
#define TPR 2
#define TPT 3

char* DescritorParaForma(int descritor) {
    switch(descritor) {
        case 0:
            return "Circulo";
            break;
        case 1:
            return "Linha";
            break;
        case 2:
            return "Retangulo";
            break;
        case 3:
            return "Texto";
            break;
        default:
            return "Froma Desconhecida";
            break;
    }
}

void seli(SmuTreap t, int n, double x, double y) {
    Node r = getNodeSmuT(t, x, y);
    Info forma = getInfoSmuT(t, r);
    DescritorTipoInfo d = getTypeInfoSrbT(t, r);
    switch(d) {
        case TPC:
            setNCirculo(forma, n);
            break;
        case TPL:
            setNLinha(forma, n);
            break;
        case TPR:
            setNRetangulo(forma, n);
            break;
        case TPT:
            setNTexto(forma, n);
            break;
        default:
            return;
    }
}

typedef struct {
    int id_alvo;
    int descritor;
    double ancx;
    double ancy;
    Node auxpararemocao;
} VerificacaoInfo;

typedef VerificacaoInfo* VInfo;

void verificaoIDIgual(Node r, Info i, double ancx, double ancy, void *dados) {
    VInfo aux = (VerificacaoInfo*)dados;
    
    int d = getTypeInfoSrbT(0, r);
    int id = -1;
    switch(d) {
        case TPC:
            id = getICirculo(i);
            break;
        case TPL:
            id = getILinha(i);
            break;
        case TPR:
            id = getIRetangulo(i);
            break;
        case TPT:
            id = getITexto(i);
            break;
        default:
            return;
    }

    if(aux->id_alvo == id) {
        aux->auxpararemocao = r;
        aux->descritor = d;
        aux->ancx = ancx;
        aux->ancy = ancy;
    }
}

void transp(SmuTreap t, int id, double x, double y, FILE *txt) {
    VInfo dados = malloc(sizeof(VerificacaoInfo));
    dados->id_alvo = id;
    dados->descritor = -1;
    dados->auxpararemocao = NULL;
    dados->ancx = -127;
    dados->ancy = -127;

    visitaProfundidadeSmuT(t, verificaoIDIgual, dados);

        if (dados->auxpararemocao != NULL) {
            Info infoOriginal = getInfoSmuT(t, dados->auxpararemocao);
            int tipo = dados->descritor;

            switch(tipo) {
                case TPC:
                    insertSmuT(t, x, y,
                        criarCirculo(dados->id_alvo, x, y, getRCirculo(infoOriginal),
                        getCorbCirculo(infoOriginal), getCorpCirculo(infoOriginal), false, -1),
                        tipo, calculaParametroBBCirculo);
                    fprintf(txt, "%d Circulo => Posicao Original: %.2lf %.2lf\n", getICirculo(infoOriginal), getXCirculo(infoOriginal), getYCirculo(infoOriginal));
                    break;
                case TPL:
                    insertSmuT(t, x, y,
                        criarLinha(dados->id_alvo, x, y, getX2Linha(infoOriginal),
                        getY2Linha(infoOriginal), getCorLinha(infoOriginal), false, -1),
                        tipo, calculaParametroBBLinha);
                    fprintf(txt, "%d Linha => Posicao Original: %.2lf %.2lf\n", getILinha(infoOriginal), getX1Linha(infoOriginal), getY1Linha(infoOriginal));
                    break;
                case TPR:
                    insertSmuT(t, x, y,
                        criarRetangulo(dados->id_alvo, x, y, getWRetangulo(infoOriginal),
                        getHRetangulo(infoOriginal), getCorbRetangulo(infoOriginal),
                        getCorpRetangulo(infoOriginal), false, -1),
                        tipo, calculaParametroBBRetangulo);
                    fprintf(txt, "%d Retangulo => Posicao Original: %.2lf %.2lf\n", getIRetangulo(infoOriginal), getXRetangulo(infoOriginal), getYRetangulo(infoOriginal));
                    break;
                case TPT:
                    insertSmuT(t, x, y,
                        criarTexto(dados->id_alvo, x, y, getCorbTexto(infoOriginal),
                        getCorpTexto(infoOriginal), getATexto(infoOriginal),
                        getTextTexto(infoOriginal), getStyle(infoOriginal), false, -1),
                        tipo, calculaParametroBBTexto);
                    fprintf(txt, "%d Texto => Posicao Original: %.2lf %.2lf\n", getITexto(infoOriginal), getXTexto(infoOriginal), getYTexto(infoOriginal));
                    break;
                default:
                    return;
            }
            removeNoSmuT(t, dados->auxpararemocao);
    }
    else {
        printf("Nao existe Node com este id.\n");
    }   
}

typedef struct {
    int id_alvo;
    Info linha;
    SmuTreap t;
} BuscaLinha;

void verificaoIDLinha(Node r, Info i, double ancx, double ancy, void *dados) {
    BuscaLinha *aux = (BuscaLinha*)dados;
    
    int d = getTypeInfoSrbT(aux->t, r);
    int id = -1;
    switch(d) {
        case TPC:
            id = getICirculo(i);
            break;
        case TPL:
            id = getILinha(i);
            break;
        case TPR:
            id = getIRetangulo(i);
            break;
        case TPT:
            id = getITexto(i);
            break;
        default:
            return;
    }

    if(aux->id_alvo == id && d == TPL) {
        printf("LINHA com ID igual a %d foi cadastrada\n\n", aux->id_alvo);
        aux->linha = getInfoSmuT(aux->t, r);
    }
}

typedef struct {
    double x, y;
} Coord;

typedef struct StructFormasN {
    int n_alvo;
    Lista pontos;
    Lista disparados;
    SmuTreap t;
} FormasN;

#define VALOR_INVALIDO -5  // Substitui o valor mágico

void verifFormasN(Node r, Info i, double ancx, double ancy, void *dados) {
    // Verificações iniciais robustas
    if(r == NULL || i == NULL || dados == NULL) return;

    FormasN *aux = (FormasN*)dados;
    // Agora verificamos aux->disparados antes de usar aux
    if(aux->disparados == NULL) return;

    int d = getTypeInfoSrbT(aux->t, r);  
    int n = VALOR_INVALIDO;
    
    switch(d) {
        case TPC:
            n = getNCirculo(i);
            break;
        case TPL:
            n = getNLinha(i);
            break;
        case TPR:
            n = getNRetangulo(i);
            break;
        case TPT:
            n = getNTexto(i);
            break;
        default:
            return;  // Tipo desconhecido, ignora
    }

    if(n != VALOR_INVALIDO && aux->n_alvo == n) {
        Coord ponto;
        ponto.x = ancx;
        ponto.y = ancy;
        inserirLista(aux->pontos, &ponto);
        inserirLista(aux->disparados, r);
    }
}



void informarSVGTXTatingidos(FILE *svg, FILE *txt, SmuTreap t, Node r, Info i) {
    if(r == NULL || i == NULL) return;
    int tipo = getTypeInfoSrbT(0, r);
    double xsvg, ysvg;
    int id_atingido;
    switch(tipo) {
        case TPC:
            id_atingido = getICirculo(i);
            xsvg = getXCirculo(i); ysvg = getYCirculo(i);
            break;
        case TPL:
            id_atingido = getILinha(i);
            xsvg = getX1Linha(i); ysvg = getY1Linha(i);
            break;
        case TPR:
            id_atingido = getIRetangulo(i);
            xsvg = getXRetangulo(i); ysvg = getYRetangulo(i);
            break;
        case TPT:
            id_atingido = getITexto(i);
            xsvg = getXTexto(i); ysvg = getYTexto(i);
            break;
        default:
            return;
    }
    Estilo disp_style = criarEstilo("sans", "b", "5px");
    if(disp_style == NULL) return;
    insertTextSVG(svg, criarTexto(5000, xsvg, ysvg, "red", "red", 'm', "x", disp_style, true, -1));
    fprintf(txt, "%d %s / Posicao: %.2lf %.2lf \n", getIDsForma(i, tipo), DescritorParaForma(tipo), xsvg, ysvg);
    free(disp_style);
}

int IDAtingidosRepeticao(Node r) {
    int tipo = getTypeInfoSrbT(0, r);
    Info f = getInfoSmuT(0, r);
    switch(tipo) {
        case TPC:
            return getICirculo(f);
            break;
        case TPL:
            return getILinha(f);
            break;
        case TPR:
            return getIRetangulo(f);
            break;
        case TPT:
            return getITexto(f);
            break;
        default:
            return -1;
            break;
    }
}

bool isIDEqual(Node r, Lista l) {
    int idA = IDAtingidosRepeticao(r);
    if(idA < 0) return false;

    int id_rep;
    for(Celula p = getInicioLista(l); p != NULL; p = getProxLista(p)) {
        id_rep = getConteudoCelula(p);
        if(id_rep == idA)
            return false;
    }
    return true;
}



void executarAtingidos(SmuTreap t, Node r, double x, double y, FILE *svg, FILE *txt, Lista rep, Lista disp) {
    Lista atingidos = criarLista();
    bool disp_atingido = false;
    if(atingidos == NULL) return;

    printf("entrou executarAtingidos\n");
    if(!getInfosAtingidoPontoSmuT(t, x, y, PontoInternoFormas, atingidos)) return;
    
    printf("Lista atingidos:\n");
    while(getInicioLista(atingidos) != NULL) {
        Node ating = getConteudoInicioLista(atingidos);
        printf("atingido: %p\n", ating);

        
        
        removerInicioLista(atingidos);
        
        for(Celula p = getInicioLista(disp); p != NULL; p = getProxLista(p)) {
            Node temp = getConteudoCelula(p);
            if(temp == ating)
            disp_atingido = true;
        }
        
        
        
        if(isIDEqual(ating, rep) && !disp_atingido) {
            
            int id = IDAtingidosRepeticao(ating);
            if(id < 0) return;
            informarSVGTXTatingidos(svg, txt, t, ating, getInfoSmuT(t, ating));
            removeNoSmuT(t, ating);
            printf("%p atingido removido\n", ating);

            inserirLista(rep, id);
        }
        disp_atingido = false;
    }
    liberarLista(atingidos);
}

bool dispararFormas(SmuTreap t, Node r, double sen0, double cos0, double hip, FILE *svg, FILE *txt, Lista rep, Lista disp) {

    double x = -27, y = -27;

    if(r == NULL) return false;
    int d = getTypeInfoSrbT(t, r);
    printf("DESCRITOR FORMA: %d\n", d);

    Info f = getInfoSmuT(t, r);
    if(f == NULL) printf("FORMA DISPARADO NULA\n");
    if(f == NULL) return false;

    fprintf(txt, "Forma Disparada:\n");
    if(d == 0) {
        x = getXCirculo(f) + calculaAreaC(f)*cos0;
        y = getYCirculo(f) + calculaAreaC(f)*sen0;
        fprintf(txt, "%d Circulo / Posicao Inicial: %.2lf, %.2lf / Posicao Final: %.2lf, %.2lf / Distancia Lancamento: %.2lf\n", getICirculo(f), getXCirculo(f), getYCirculo(f), x, y, calculaAreaC(f));
    } 
    else if(d == 1) {
        x = getX1Linha(f) + calculaAreaL(f)*cos0;
        y = getY1Linha(f) + calculaAreaL(f)*sen0;
        fprintf(txt, "%d Linha / Posicao Inicial: %.2lf, %.2lf / Posicao Final: %.2lf, %.2lf / Distancia Lancamento: %.2lf\n", getILinha(f), getX1Linha(f), getY1Linha(f), x, y, calculaAreaL(f));
    }
    else if(d == 2) {
        x = getXRetangulo(f) + calculaAreaR(f)*cos0;
        y = getYRetangulo(f) + calculaAreaR(f)*sen0;
        fprintf(txt, "%d Retangulo / Posicao Inicial: %.2lf, %.2lf / Posicao Final: %.2lf, %.2lf / Distancia Lancamento: %.2lf\n", getIRetangulo(f), getXRetangulo(f), getYRetangulo(f), x, y, calculaAreaR(f));
    }
    else if(d == 3) {
        x = getXTexto(f) + calculaAreaT(f)*cos0;
        y = getYTexto(f) + calculaAreaT(f)*sen0;
        fprintf(txt, "%d Texto / Posicao Inicial: %.2lf, %.2lf / Posicao Final: %.2lf, %.2lf / Distancia Lancamento: %.2lf\n", getITexto(f), getXTexto(f), getYTexto(f), x, y, calculaAreaT(f));
    }
    else {
        printf("sem descritor forma\n");
        return false;
    }
    Estilo disp_style = criarEstilo("sans", "b", "5px");
    insertTextSVG(svg, criarTexto(5000, x, y, "purple", "purple", 'm', "#", disp_style, true, -1));

    fprintf(txt, "Atingidos: \n");
    printf("%p\nX: %.2lf / Y: %.2lf\n", r, x, y);

    executarAtingidos(t, r, x, y, svg, txt, rep, disp);
    printf("no disparado removido\n");
    return true;
}


void disp(SmuTreap t, int id, int n, FILE *svg, FILE *txt) {
    // achar linha com ID = id
    BuscaLinha *dados = malloc(sizeof(BuscaLinha));
    dados->id_alvo = id;
    dados->linha = NULL;
    dados->t = t;
    
    visitaProfundidadeSmuT(t, verificaoIDLinha, dados);

    double hip, sen0, cos0;
    double x1, x2, y1, y2;
    
    if(dados->linha == NULL) {
        printf("Nao existe linha com este id\n\n");
        free(dados);
        return;
    }
    
    x1 = getX1Linha(dados->linha);
    x2 = getX2Linha(dados->linha);
    y1 = getY1Linha(dados->linha);
    y2 = getY2Linha(dados->linha);
    free(dados);
    
    hip = sqrt(pow(x1-x2, 2) + pow(y1-y2, 2));
    sen0 = (y2-y1)/hip;
    cos0 = (x2-x1)/hip;
    


    FormasN *disparar = malloc(sizeof(FormasN));
    disparar->disparados = criarLista();
    disparar->pontos = criarLista();
    disparar->n_alvo = n;
    disparar->t = t;
    visitaProfundidadeSmuT(t, verifFormasN, disparar); 
    // lista disparados de nos para disparar
    // lista pontos de ponto para verificacao 
    
    printf("antes do for disparos\n");
    int cont = 1;
    Lista atingidos = criarLista();
    Lista rep = criarLista();

    while(getInicioLista(disparar->disparados) != NULL) {
        
        printf("disparo %d:\n", cont);
        cont++;

        
        
        // disparar nova direcao
        Node disparo = getConteudoInicioLista(disparar->disparados);


        printf("%p\n", disparo);
        if(disparo == NULL) {
            printf("DISPARO NULL\n");
        }

        
        removerInicioLista(disparar->disparados);
            
        if(dispararFormas(t, disparo, sen0, cos0, hip, svg, txt, rep, disparar->disparados)) {

            printf("Depois de atingidos: %p\n", disparo);
            if(disparo != NULL) {
                removeNoSmuT(t, disparo);
            } 
        }
        printf("saiu disparo individual\n\n");
    }
    
    liberarLista(disparar->disparados);
    liberarLista(disparar->pontos);
    liberarLista(atingidos);
    free(disparar);
}





typedef struct {
    Lista nodes;
    int n_alvo;
} Clones;

void verifFormasClonagem(Node r, Info i, double ancx, double ancy, void *dados) {
    Clones *aux = (Clones*)dados;
    
    int d = getTypeInfoSrbT(0, r);  
    Info forma = getInfoSmuT(0, r);
    int n = -20;
    switch(d) {
        case TPC:
            n = getNCirculo(forma);
            break;
        case TPL:
            n = getNLinha(forma);
            break;
        case TPR:
            n = getNRetangulo(forma);
            break;
        case TPT:
            n = getNTexto(forma);
            break;
        default:
            return;
    }

    if(aux->n_alvo == n && n != -20) {
        aux->n_alvo = n;
        inserirLista(aux->nodes, r);
    }
}

void cln(SmuTreap t, int n, double dx, double dy, int *maiorID) {

    int m = *maiorID;

    Clones *clones = malloc(sizeof(Clones));
    clones->nodes = criarLista();
    clones->n_alvo = n;

    visitaProfundidadeSmuT(t, verifFormasClonagem, clones);

    int tam = tamLista(clones->nodes);
    int aumentoID = 1;
    while(getInicioLista(clones->nodes) != NULL) {
        Node remocao = getConteudoInicioLista(clones->nodes);
        Info forma = getInfoSmuT(t, remocao);
        int tipo = getTypeInfoSrbT(t, remocao);
        switch(tipo) {
            case TPC:
                insertSmuT(t, getXCirculo(forma)+dx, getYCirculo(forma)+dy, criarCirculo(m+aumentoID, getXCirculo(forma)+dx, getYCirculo(forma)+dy, getRCirculo(forma), "red", "red", false, getNCirculo(forma)), tipo, calculaParametroBBCirculo);
                break;
            case TPL:
                insertSmuT(t, getX1Linha(forma)+dx, getY1Linha(forma)+dy, criarLinha(m+aumentoID, getX1Linha(forma)+dx, getY1Linha(forma)+dy, getX2Linha(forma)+dx, getY2Linha(forma)+dy, "red", false, getNLinha(forma)), tipo, calculaParametroBBLinha);
                break;
            case TPR:
                insertSmuT(t, getXRetangulo(forma)+dx, getYRetangulo(forma)+dy, criarRetangulo(m+aumentoID, getXRetangulo(forma)+dx, getYRetangulo(forma)+dy, getWRetangulo(forma), getHRetangulo(forma), "red", "red", false, getNRetangulo(forma)), tipo, calculaParametroBBRetangulo);
                break;
            case TPT:
                insertSmuT(t, getXTexto(forma)+dx, getYTexto(forma)+dy, criarTexto(m+aumentoID, getXTexto(forma)+dx, getYTexto(forma)+dy, "red", "red", getATexto(forma), getTextTexto(forma), getStyle(forma), false, getNTexto(forma)), tipo, calculaParametroBBTexto);
                break;
            default:
                return;
        }
        removerInicioLista(clones->nodes);
        aumentoID = aumentoID + 1;
    }
    liberarLista(clones->nodes);
    free(clones);
    *maiorID = m + tam;
}


void selr(SmuTreap t, int n, double x, double y, double w, double h, FILE *txt, FILE *svg) {
    Lista l = criarLista();
    int tipo;

    if(getInfosDentroRegiaoSmuT(t, x, y, w, h, BBinternoRegiao, l)) {
        fprintf(txt, "Selecionados: \n");
        while(getInicioLista(l) != NULL) {
            Node aux = getConteudoInicioLista(l);
            Info forma = getInfoSmuT(t, aux);
            tipo = getTypeInfoSrbT(t, aux);

            switch(tipo) {
                case TPC:
                    fprintf(txt, "%d Circulo %.2lf %.2lf\n", getICirculo(forma), getXCirculo(forma), getYCirculo(forma));
                    insertCircleSVG(svg, criarCirculo(5000, getXCirculo(forma), getYCirculo(forma), 1.5, "red", "red", true, -1));
                    setNCirculo(forma, n);
                    break;
                case TPL:
                    fprintf(txt, "%d Linha %.2lf %.2lf\n", getILinha(forma), getX1Linha(forma), getY1Linha(forma));
                    insertCircleSVG(svg, criarCirculo(5000, getX1Linha(forma), getY1Linha(forma), 1.5, "red", "red", true, -1));
                    setNLinha(forma, n);
                    break;
                case TPR:
                    fprintf(txt, "%d Retangulo %.2lf %.2lf\n", getIRetangulo(forma), getXRetangulo(forma), getYRetangulo(forma));
                    insertCircleSVG(svg, criarCirculo(5000, getXRetangulo(forma), getYRetangulo(forma), 1.5, "red", "red", true, -1));
                    setNRetangulo(forma, n);
                    break;
                case TPT:
                    fprintf(txt, "%d Texto %.2lf %.2lf\n", getITexto(forma), getXTexto(forma), getYTexto(forma));
                    insertCircleSVG(svg, criarCirculo(5000, getXTexto(forma), getYTexto(forma), 1.5, "red", "red", true, -1));
                    setNTexto(forma, n);
                    break;
                default: 
                    return;
            }
            removerInicioLista(l);
        }
    } 
    liberarLista(l);
}

int getIDsForma(Info i, int descritor) {
    switch(descritor) {
        case 0:
            return getICirculo(i);
            break;
        case 1:
            return getILinha(i);
            break;
        case 2:
            return getIRetangulo(i);
            break;
        case 3:
            return getITexto(i);
            break;
        default:
            printf("Descritor invalido\n");
            return -1;
    }
}


void blowSVG(FILE *svg, Info i, int descritor) {
    double x, y;
    switch(descritor) {
        case TPC:
            x = getXCirculo(i); y = getYCirculo(i);
            break;
        case TPL:
            x = getX1Linha(i); y = getY1Linha(i);
            break;
        case TPR:
            x = getXRetangulo(i); y = getYRetangulo(i);
            break;
        case TPT:
            x = getXTexto(i); y = getYTexto(i);
            break;
        default:
            return;
    }

    Estilo ating_style = criarEstilo("sans", "b", "8px");
    insertTextSVG(svg, criarTexto(666, x, y, "red", "red", 'm', "X", ating_style, true, -1));
}

void blow(SmuTreap t, int id, FILE *txt, FILE *svg) {

    VInfo dados = malloc(sizeof(VerificacaoInfo));
    dados->id_alvo = id;
    dados->auxpararemocao = NULL;
    dados->ancx = -127; 
    dados->ancy = -127;
    dados->descritor = -20;
    int tam;

    Lista l = criarLista();

    visitaProfundidadeSmuT(t, verificaoIDIgual, dados);

    if(dados->auxpararemocao != NULL) {
        fprintf(txt, "Removida: %d %s %.2lf %.2lf\n", dados->id_alvo, DescritorParaForma(dados->descritor), dados->ancx, dados->ancy);
        if(getInfosAtingidoPontoSmuT(t, dados->ancx, dados->ancy, PontoInternoFormas, l)) {
            tam = tamLista(l);

            int id_atingidos;
            
            fprintf(txt, "Atingidos:\n");
            for(int i = 0; i<tam && getInicioLista(l) != NULL; i++) {
                Node temp = getConteudoInicioLista(l);
                Info forma = getInfoSmuT(t, temp);
                int d = getTypeInfoSrbT(t, temp);
                fprintf(txt, "%d %s\n", getIDsForma(forma, d), DescritorParaForma(d));

                blowSVG(svg, forma, d);

                removeNoSmuT(t, temp);
                removerInicioLista(l);
            }
        }
    } else {
        printf("Nao existe node com este ID\n\n");
    }

    liberarLista(l);
    return;
}

typedef struct {
    Node auxpararemocao;
    double x, y;
    int descritor, id_alvo;
    double w, h;
    double ancx, ancy;
} VInfoSpy;

void verificaoSpy(Node r, Info i, double ancx, double ancy, void *dados) {
    VInfoSpy *aux = (VInfoSpy*)dados;
    
    int d = getTypeInfoSrbT(0, r);
    int id = -1;
    switch(d) {
        case TPC:
            id = getICirculo(i);
            break;
        case TPL:
            id = getILinha(i);
            break;
        case TPR:
            id = getIRetangulo(i);
            break;
        case TPT:
            id = getITexto(i);
            break;
        default:
            return -1;
    }

    if(aux->id_alvo == id) {
        aux->auxpararemocao = r;
        aux->descritor = d;
        Info bb = getBoundingBoxSmuT(0, r, &aux->x, &aux->y, &aux->w, &aux->h);
        aux->ancx = ancx;
        aux->ancy = ancy;
    }
}


void spy(SmuTreap t, int id, FILE *txt, FILE *svg) {
    VInfoSpy *dados = malloc(sizeof(VInfoSpy));
    dados->id_alvo = id;
    dados->descritor = -20;
    dados->x = -127;
    dados->y = -127;
    dados->w = -127;
    dados->h = -127;
    dados->ancx = -127;
    dados->ancy = -127;
    dados->auxpararemocao = NULL;
    visitaProfundidadeSmuT(t, verificaoSpy, dados);

    Lista lr = criarLista();
    Lista lt = criarLista();
    int tam, d;

    if(dados->auxpararemocao != NULL) {
        insertCircleSVG(svg, criarCirculo(7777, dados->ancx, dados->ancy, 1.5, "green", "green", true, -1));
        switch(dados->descritor) {
            case TPR:
                fprintf(txt, "Contidas Dentro do Retangulo: \n");
                if(getInfosDentroRegiaoSmuT(t, dados->x, dados->y, dados->w, dados->h, BBinternoRegiao, lr)) {
                    tam = tamLista(lr);
                    for(int i = 0; i < tam && getInicioLista(lr) != NULL; i++) {
                        Node n = getConteudoInicioLista(lr);
                        d = getTypeInfoSrbT(t, n);
                        Info info = getInfoSmuT(t, n);

                        if(n != dados->auxpararemocao) {

                            switch(d) {
                                case TPC:
                                    fprintf(txt, "%d Circulo\n", getICirculo(info));
                                    break;
                                case TPL:
                                    fprintf(txt, "%d Linha\n", getILinha(info));
                                    break;
                                case TPR:
                                    fprintf(txt, "%d Retangulo\n", getIRetangulo(info));
                                    break;
                                case TPT:
                                    fprintf(txt, "%d Texto\n", getITexto(info));
                                    break;
                                default:
                                    break;
                            }
                        }
                        removerInicioLista(lr);
                    }

                }
                break;
            case TPT:
                fprintf(txt, "Exatemente na coordenada do texto: \n");
                if(getInfosAtingidoPontoSmuT(t, dados->ancx, dados->ancy, PontoInternoFormas, lt)) {
                    tam = tamLista(lt);
                    for(int i = 0; i < tam && getInicioLista(lt) != NULL; i++) {
                        Node n = getConteudoInicioLista(lt);
                        d = getTypeInfoSrbT(t, n);
                        Info info = getInfoSmuT(t, n);

                        

                            switch(d) {
                                case TPC:
                                    fprintf(txt, "%d Circulo\n", getICirculo(info));
                                    break;
                                case TPL:
                                    fprintf(txt, "%d Linha\n", getILinha(info));
                                    break;
                                case TPR:
                                    fprintf(txt, "%d Retangulo\n", getIRetangulo(info));
                                    break;
                                case TPT:
                                    fprintf(txt, "%d Texto\n", getITexto(info));
                                    break;
                                default:
                                    break;
                            }
                        
                        removerInicioLista(lt);
                    }
                }
                break;
            case TPL:
                fprintf(txt, "INVALIDO para spy!! Linha identificado.\n");
                break;
            case TPC:
                fprintf(txt, "INVALIDO para spy!! Circulo identificado.\n");
                break;
            default:
                return;
        }
        liberarLista(lr);
        liberarLista(lt);

    } else {
        printf("Nao existe node com este id\n");
    }
    free(dados);
    return;
}



typedef struct {
    Node auxpararemocao;
    double x, y;
    int descritor, id_alvo;
    double w, h;
    double ancx, ancy;
} VInfoCmflg;

void verificaoCmflg(Node r, Info i, double ancx, double ancy, void *dados) {
    VInfoCmflg *aux = (VInfoCmflg*)dados;
    
    int d = getTypeInfoSrbT(0, r);
    int id = -1;
    switch(d) {
        case TPC:
            id = getICirculo(i);
            break;
        case TPL:
            id = getILinha(i);
            break;
        case TPR:
            id = getIRetangulo(i);
            break;
        case TPT:
            id = getITexto(i);
            break;
        default:
            return;
    }

    if(aux->id_alvo == id) {
        aux->auxpararemocao = r;
        aux->descritor = d;
        Info bb = getBoundingBoxSmuT(0, r, &aux->x, &aux->y, &aux->w, &aux->h);
        aux->ancx = ancx;
        aux->ancy = ancy;
    }
}


void cmflg(SmuTreap t, int id, char *cb, char *cp, double w, FILE *svg) {
    VInfoCmflg *dados = malloc(sizeof(VInfoCmflg));
    dados->id_alvo = id;
    dados->descritor = -20;
    dados->x = -127;
    dados->y = -127;
    dados->w = -127;
    dados->h = -127;
    dados->ancx = -127;
    dados->ancy = -127;
    dados->auxpararemocao = NULL;
    visitaProfundidadeSmuT(t, verificaoCmflg, dados);

    Lista lretangulo = criarLista();
    Lista ltexto = criarLista();
    int tam, d;

    if(dados->auxpararemocao != NULL) {
        insertCircleSVG(svg, criarCirculo(7777, dados->ancx, dados->ancy, 1.5, "green", "green", true, -1));
        switch(dados->descritor) {
            case TPR:
                if(getInfosDentroRegiaoSmuT(t, dados->x, dados->y, dados->w, dados->h, BBinternoRegiao, lretangulo)) {
                    tam = tamLista(lretangulo);
                    for(int i = 0; i < tam && getInicioLista(lretangulo) != NULL; i++) {
                        Node n = getConteudoInicioLista(lretangulo);
                        removerInicioLista(lretangulo);

                        if(n == NULL || n == dados->auxpararemocao)
                            continue;

                        d = getTypeInfoSrbT(t, n);
                        Info info = getInfoSmuT(t, n);

                        if(n != dados->auxpararemocao) {

                            switch(d) {
                                case TPC:
                                    setCorbCirculo(info, cb); setCorpCirculo(info, cp);
                                    setSWCirculo(info, w);
                                    break;
                                case TPL:
                                    setCorLinha(info, cb);
                                    setSWLinha(info, w);
                                    break;
                                case TPR:
                                    setCorbRetangulo(info, cb); setCorpRetangulo(info, cp);
                                    setSWRetangulo(info, w);
                                    break;
                                case TPT:
                                    setCorbTexto(info, cb); setCorpTexto(info, cp);
                                    setSWTexto(info, w);
                                    break;
                            }
                        }
                    }
                }
                break;
            case TPT:
                if(getInfosDentroRegiaoSmuT(t, dados->ancx, dados->ancy, dados->w, dados->h, BBinternoRegiao, ltexto)) {
                    tam = tamLista(ltexto);
                    for(int i = 0; i < tam && getInicioLista(ltexto) != NULL; i++) {
                        Node n = getConteudoInicioLista(ltexto);
                        removerInicioLista(ltexto);

                        //if(n == NULL || n == dados->auxpararemocao)
                        //    continue;

                        d = getTypeInfoSrbT(t, n);
                        Info info = getInfoSmuT(t, n);

                        

                        switch(d) {
                            case TPC:
                                setCorbCirculo(info, cb); setCorpCirculo(info, cp);
                                setSWCirculo(info, w);
                                break;
                            case TPL:
                                setCorLinha(info, cb);
                                setSWLinha(info, w);
                                break;
                            case TPR:
                                setCorbRetangulo(info, cb); setCorpRetangulo(info, cp);
                                setSWRetangulo(info, w);
                                break;
                            case TPT:
                                setCorbTexto(info, cb); setCorpTexto(info, cp);
                                setSWTexto(info, w);
                                break;
                        }
                        
                    }
                }
                break;

            case TPL:
                printf("Invalido!! Linha identificada\n");
                break;
            case TPC:
                printf("Invalido!! Circulo identificada\n");
                break;
            default:
                return;
        }
        liberarLista(lretangulo);
        liberarLista(ltexto);

    } else {
        printf("Nao existe node com este id\n");
    }
    free(dados);
    return;
}

