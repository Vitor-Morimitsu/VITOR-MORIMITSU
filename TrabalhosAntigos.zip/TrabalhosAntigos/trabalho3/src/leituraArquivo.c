#include "leituraArquivo.h"

#define MAX_SIZE 1000

ArqLeitura abreArquivoLeitura(char *fn) {
    FILE* arq = fopen(fn, "r");
    if(arq == NULL) {
        printf("Erro na abertura do arquivo: %s\n", fn);
        exit(1);
    }
    return arq;
}

ArqLeitura abreArquivoEscrita(char *fn) {
    FILE* arq = fopen(fn, "w");
    if(arq == NULL) {
        printf("Erro na abertura do arquivo: %s\n", fn);
        exit(1);
    }
    return arq;
}

bool leituraLinha(FILE* arq, char *linha, int max_size) {
    if (fgets(linha, max_size, arq) != NULL) {
        return true;
    } else {
        return false;
    }
}

void getParametroI(char *linha, int i) { 
    char* token = strtok(linha, " ");
    for (int j = 0; j < i; j++) {
        if (token == NULL) {
            return; 
        }
        token = strtok(NULL, " ");
    }
}

void fechaArquivoLeitura(FILE* arq) {
    fclose(arq);
}