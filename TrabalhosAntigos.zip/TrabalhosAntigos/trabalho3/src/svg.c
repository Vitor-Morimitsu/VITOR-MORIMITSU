#include <stdio.h>
#include <stdlib.h>
#include "leituraArquivo.h"
#include "circulo.h"
#include "retangulo.h"
#include "linha.h"
#include "texto.h"
#include "boundingbox.h"
#include "smutreap.h"

void startSVG(ArqLeitura saida) {
    fprintf(saida, "<svg xmlns:svg=\"http://www.w3.org/2000/svg\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\">\n");
}   

void insertCircleSVG(ArqLeitura saida, Circulo c) {
    fprintf(saida, "<circle id=\"%d\" style=\"fill:%s;fill-opacity:0.5;stroke:%s\" r=\"%lf\" cy=\"%lf\" cx=\"%lf\" stroke-width=\"%lf\" />\n", getICirculo(c), getCorpCirculo(c), getCorbCirculo(c), getRCirculo(c), getYCirculo(c), getXCirculo(c), getSWCirculo(c));
}

void insertRectSVG(ArqLeitura saida, Retangulo r) {
    fprintf(saida, "<rect id=\"%d\" style=\"fill:%s;fill-opacity:0.5;stroke:%s\" height=\"%lf\" width=\"%lf\" y=\"%lf\" x=\"%lf\" stroke-width=\"%lf\" />\n", getIRetangulo(r),getCorpRetangulo(r), getCorbRetangulo(r), getHRetangulo(r), getWRetangulo(r), getYRetangulo(r), getXRetangulo(r), getSWRetangulo(r));
}

void insertLineSVG(ArqLeitura saida, Linha l) {
    fprintf(saida, "<line id=\"%d\" x1=\"%lf\" y1=\"%lf\" x2=\"%lf\" y2=\"%lf\" stroke=\"%s\" stroke-width=\"%lf\" />\n", getILinha(l), getX1Linha(l), getY1Linha(l), getX2Linha(l), getY2Linha(l), getCorLinha(l), getSWLinha(l));
}

void insertTextSVG(ArqLeitura saida, Texto t) {
    char a = getATexto(t);
    switch(a) {
        case 'i':
            fprintf(saida, "<text id=\"%d\" font-size=\"%s\" line-height=\"0\" text-anchor=\"start\" fill=\"%s\" stroke=\"%s\" font-family=\"%s\" y=\"%lf\" x=\"%lf\" stroke-width=\"%lf\" ><![CDATA[%s]]></text>\n", getITexto(t), getSize(getStyle(t)), getCorpTexto(t), getCorbTexto(t), getFamily(getStyle(t)) , getYTexto(t), getXTexto(t), getSWTexto(t) ,getTextTexto(t));
            break;
        case 'm':
            fprintf(saida, "<text id=\"%d\" font-size=\"%s\" line-height=\"0\" text-anchor=\"middle\" fill=\"%s\" stroke=\"%s\" font-family=\"%s\" y=\"%lf\" x=\"%lf\" stroke-width=\"%lf\" ><![CDATA[%s]]></text>\n", getITexto(t), getSize(getStyle(t)), getCorpTexto(t), getCorbTexto(t) ,getFamily(getStyle(t)) , getYTexto(t), getXTexto(t), getSWTexto(t) ,getTextTexto(t));
            break;
        case 'f':
            fprintf(saida, "<text id=\"%d\" font-size=\"%s\" line-height=\"0\" text-anchor=\"end\" fill=\"%s\" stroke=\"%s\" font-family=\"%s\" y=\"%lf\" x=\"%lf\" stroke-width=\"%lf\" ><![CDATA[%s]]></text>\n", getITexto(t), getSize(getStyle(t)), getCorpTexto(t), getCorbTexto(t), getFamily(getStyle(t)) , getYTexto(t), getXTexto(t), getSWTexto(t) ,getTextTexto(t));
            break;
    }
}

void closeSVG(ArqLeitura saida) {
    fprintf(saida, "</svg>\n");
}

void gerarSVG(Node r, Info i, double x, double y, void *aux) {
    int descritor, id;
    descritor = getTypeInfoSrbT(0, r);
    switch(descritor) {
        case 0:
            insertCircleSVG(aux, i);
            break;
        case 1:
            insertLineSVG(aux, i);
            break;
        case 2:
            insertRectSVG(aux, i);
            break;
        case 3:
            insertTextSVG(aux, i);
            break;
    }
}

