#include "qry.h"
#include "svg.h"

#define MAX_SIZE 10000

void LeituraCompletaQry(FILE* arqQry, FILE **stxt, FILE **ssvg2, char *dot2, SmuTreap t, int *maiorID) {
    int id, n;
    double x, y, w, h, dx, dy;
    char cb[300], cp[300], comandoQRY[30];

    char linha[MAX_SIZE];
    char aux[MAX_SIZE];

    while(leituraLinha(arqQry, linha, 1000)) {
        aux[0] = '\0'; // Esvazia a variavel aux e comando a cada iteracao
        comandoQRY[0] = '\0';
        strcpy(aux, linha);
        sscanf(aux, "%s", comandoQRY);


        if(strcmp(comandoQRY, "selr") == 0) {
            sscanf(aux, "%s %d %lf %lf %lf %lf", comandoQRY, &n, &x, &y, &w, &h);
            fprintf(*stxt, "\n[*] selr %d %.2lf %.2lf %.2lf %.2lf\n", n, x, y, w, h);
            selr(t, n, x, y, w, h, *stxt, *ssvg2);
            insertRectSVG(*ssvg2, criarRetangulo(5000, x, y, w, h, "red", "white", true, -1));
            insertCircleSVG(*ssvg2, criarCirculo(5000, x, y, 1.00, "red", "red", true, -1));
        }
        else if (strcmp(comandoQRY, "seli") == 0) {
            sscanf(aux, "%s %d %lf %lf", comandoQRY, &n, &x, &y);
            fprintf(*stxt, "\n[*] seli %d %.2lf %.2lf\n", n, x, y);
            seli(t, n, x, y);
        }
        else if (strcmp(comandoQRY, "disp") == 0) {
            sscanf(aux, "%s %d %d", comandoQRY, &id, &n);
            fprintf(*stxt, "\n[*] disp %d %d\n", id, n);
            disp(t, id, n, *ssvg2, *stxt);
        }
        else if (strcmp(comandoQRY, "transp") == 0) {
            sscanf(aux, "%s %d %lf %lf", comandoQRY, &id, &x, &y);
            fprintf(*stxt, "\n[*] trasnp %d %.2lf %.2lf\n", id, x, y);
            transp(t, id, x, y, *stxt);
        }

        else if (strcmp(comandoQRY, "cln") == 0) {
            sscanf(aux, "%s %d %lf %lf", comandoQRY, &n, &dx, &dy);
            fprintf(*stxt, "\n[*] cln %d %.2lf %.2lf\n", n, dx, dy);
            cln(t, n, dx, dy, maiorID);

        }

        else if (strcmp(comandoQRY, "spy") == 0) {
            sscanf(aux, "%s %d", comandoQRY, &id);
            fprintf(*stxt, "\n[*] spy %d\n", id);
            spy(t, id, *stxt, *ssvg2);
        }
        else if (strcmp(comandoQRY, "cmflg") == 0) {
            sscanf(aux, "%s %d %s %s %lf", comandoQRY, &id, cb, cp, &w);
            fprintf(*stxt, "\n[*] cmflg %d %s %s %.2lf\n", id, cb, cp, w);
            cmflg(t, id, cb, cp, w, *ssvg2);
        }
        else if (strcmp(comandoQRY, "blow") == 0) {
            sscanf(aux, "%s %d", comandoQRY, &id);
            fprintf(*stxt, "\n[*] blow %d\n", id);
            blow(t, id, *stxt, *ssvg2);
        }
    }
    visitaProfundidadeSmuT(t, gerarSVG, *ssvg2);
    printDotSmuTreap(t, dot2);
}

void ProcessaQry(const char* pathqry, const char* dirsaida, const char* nomearqsaida, const char* nomeqry, SmuTreap t, int *maiorID) {
    char* pathqry2 = (char*)malloc(sizeof(char)*(strlen(pathqry)+6+strlen(nomeqry)));
    pathqry2[0] = '\0';
    strcpy(pathqry2, pathqry);
    strcat(pathqry2, nomeqry);
    printf("Diretório do arquivo qry: %s\n", pathqry2);
    FILE* arqqry = fopen(pathqry2, "r");
    if (arqqry==NULL) {
        fprintf(stderr, "Erro na abertura do arquivo QRY: %s\n", pathqry2);
        fclose(arqqry);
        exit(1);
    }
    printf("Diretorio de saida: %s\n", dirsaida);

    char svg2[512];
    svg2[0]='\0';
    strcat(svg2, dirsaida);
    strcat(svg2, nomearqsaida);
    strcat(svg2, ".svg");

    char saidatxt[512];
    saidatxt[0]='\0';
    strcat(saidatxt, dirsaida);
    strcat(saidatxt, nomearqsaida);
    strcat(saidatxt, ".txt");
    printf("Diretório do arquivo svg2: %s\nDiretório do arquivo txt: %s\n", svg2, saidatxt);

    FILE* ssvg2 = fopen(svg2, "w");
    if (ssvg2==NULL) {
        fprintf(stderr, "Erro na criação do arquivo SVG: %s\n", svg2);
        fclose(arqqry);
        fclose(ssvg2);
        exit(1);
    }

    fprintf(ssvg2, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    fprintf(ssvg2, "<svg width=\"2000\" height=\"2000\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\">\n");

    FILE* stxt = fopen(saidatxt, "w");
    if (stxt==NULL) {
        fprintf(stderr, "Erro na criação do arquivo TXT: %s\n", saidatxt);
        fclose(arqqry);
        fclose(ssvg2);
        fclose(stxt);
        exit(1);
    }

    char saidadot2[512];
    saidadot2[0] = '\0';
    strcat(saidadot2, dirsaida);
    strcat(saidadot2, nomearqsaida);
    strcat(saidadot2, ".dot");
    printf("Diretorio do arquivo dot1: %s\n", saidadot2);

    LeituraCompletaQry(arqqry, &stxt, &ssvg2, saidadot2, t, maiorID);

    fprintf(ssvg2, "</svg>\n");
    fclose(arqqry);
    fclose(ssvg2);
    fclose(stxt);
}
