#ifndef FUNCOESQRY_H
#define FUNCOESQRY_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include "smutreap.h"


/*
    Arquivo .h relacionada as funcoes de comando do arquivo .qry, especificadas na descricao do trabalho.
*/

/// @brief recebe como parametro um retangulo e usa a selecao n para identificar os nodes e formas que se encontram completamente internos a ele
/// @param t SmuTreap t
/// @param n identificador de selecao n
/// @param x ancora x do retangulo selr
/// @param y ancora y do retangulo selr
/// @param w largura w do retangulo selr
/// @param h altura h do retangulo selr
/// @param txt arquivo txt a ser escrito 
/// @param svg arquivo svg a ser escrito 
void selr(SmuTreap t, int n, double x, double y, double w, double h, FILE *txt, FILE *svg); 

/// @brief seleciona uma forma com as coordenadas x e y e troca seu id de selecao
/// @param t SmuTreap t
/// @param n identificador de selecao n
/// @param x ancora x a ser buscada
/// @param y ancora y a ser buscada
void seli(SmuTreap t, int n, double x, double y);  

/// @brief usa as formas identificadas pela selecao n e as dispara de acordo com a direcao e sentido de uma linha de identificador id
/// @param t SmuTreap t
/// @param id identificador id da linha 
/// @param n identificador de selecao n
/// @param svg arquivo svg a ser escrito
/// @param txt arquivo txt a ser escrito 
void disp(SmuTreap t, int id, int n, FILE *svg, FILE *txt);  

/// @brief retorna em um arquivo txt as formas que estao contidas inteiramente dentro de um retangulo com identificador id ou na coordenada do texto de identificador id
/// @param t SmuTreap t
/// @param id identificador id de um texto ou retangulo
/// @param txt arquivo txt a ser escrito 
/// @param svg arquivo svg a ser escrito 
void spy(SmuTreap t, int id, FILE *txt, FILE *svg);  

/// @brief usa as formas identificadas pela selecao n e as clona (duplica) para uma nova posicao transladada por dx e dy
/// @param t SmuTreap t
/// @param n identificador de selecao n
/// @param dx translacao no eixo x
/// @param dy translacao no eixo y
/// @param maiorID maior id identificado no .geo
void cln(SmuTreap t, int n, double dx, double dy, int *maiorID);  

/// @brief transporta a forma com identificador id para uma nova posicao x e y passada como parametro
/// @param t SmuTreap t
/// @param id identificador id 
/// @param x nova ancora x
/// @param y nova ancora y
/// @param txt arquivo txt a ser escrito 
void transp(SmuTreap t, int id, double x, double y, FILE *txt);  

/// @brief troca as cores da borda e preenchimento e a largura da borda das formas inteiramente internas a um retangulo de identificador id ou na mesma coordenaa de um texto de identificador id
/// @param t SmuTreap t
/// @param id identificador id de um retangulo ou texto
/// @param cb nova cor da borda 
/// @param cp nova cor de preenchimento
/// @param w nova largura da borda
/// @param svg arquivo svg a ser escrito 
void cmflg(SmuTreap t, int id, char *cb, char *cp, double w, FILE *svg);

/// @brief explode a forma que possue o id passado por parametro, as formas que contem esta forma tambem sao destruidas
/// @param t SmuTreap t
/// @param id identificador da forma id
/// @param txt arquivo txt a ser escrito
/// @param svg arquivo svg a ser escrito
void blow(SmuTreap t, int id, FILE *txt, FILE *svg);

#endif
