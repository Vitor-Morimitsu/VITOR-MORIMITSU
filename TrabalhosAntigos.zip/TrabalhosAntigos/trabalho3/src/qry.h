#ifndef QRY_H
#define QRY_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "leituraArquivo.h"
#include "funcoesqry.h"
#include "smutreap.h"
#include "circulo.h"
#include "retangulo.h"
#include "texto.h"
#include "linha.h"
#include "boundingbox.h"

/*
    Arquivo .h relacionado ao processamento e leitura do .qry.
*/

/// @brief realiza a leitura completa do arquivo .qry e altera a SmuTreap t de acordo com seus comandos
/// @param arqQry arquivo .qry a ser lido
/// @param stxt arquivo de texto gerado após a leitura do .qry
/// @param ssvg2 arquivo svg gerado após a leitura do .qry
/// @param dot2 arquivo dot gerado após a leitura do .qry
/// @param t SmuTreap t
/// @param maiorID mairo id registrado na leitura do .geo
void LeituraCompletaQry(FILE* arqQry, FILE **stxt, FILE **ssvg2, char *dot2, SmuTreap t, int *maiorID);

/// @brief realiza a preparação e processamento do arquivo .qry a ser lido
/// @param pathqry path do arquivo .qry a ser acessado e lido
/// @param dirsaida path do diretorio de saida
/// @param nomearqsaida nome concatenado dos arquvios de saidas gerados
/// @param nomeqry nome do arquivo qry
/// @param t SmuTreap t
/// @param maiorID maior id registrado na leitura do .geo
void ProcessaQry(const char* pathqry, const char* dirsaida, const char* nomearqsaida, const char* nomeqry, SmuTreap t, int *maiorID);

#endif
