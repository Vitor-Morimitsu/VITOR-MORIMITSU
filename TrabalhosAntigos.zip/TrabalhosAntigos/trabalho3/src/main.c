#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "smutreap.h"
#include "boundingbox.h"
#include "geo.h"
#include "svg.h"
#include "leituraArquivo.h"
#include "qry.h"
#include "funcoesqry.h"
#include "lista.h"
#include "strings.h"

// main com entrada dos argumentos que serao lidos
int main(int argc, char* argv[]) {
    // criacao de strings pra dirEntrada, geo, qry e dirSaida
    char *dirEntrada = NULL, *arquivoGeo = NULL, *arquivoQry = NULL, *dirSaida = NULL;

    int prioridadeMaxima = 10000, hitCount = 3; double promotionRate = 1.1;  
    int existegeo = 0, existeqry = 0;

    // loop para leitura dos parametros
    for (int i = 1; i < argc; i++) {
        // acoes no diretorio de dirEntrada
        if (strcmp(argv[i], "-e") == 0 ) {
            dirEntrada = trataDirEntrada(argv[i+1]);
            existegeo = 1;
        // passagem dos argumentos para a string aquivoGeo
        } 
        else if (strcmp(argv[i], "-f") == 0 ) {
            arquivoGeo = (char*)malloc(sizeof(char)*(strlen(argv[i + 1]) + 5));
            if(arquivoGeo==NULL){
                printf("Erro na alocação de memória da string!\n");
                exit(1);
            }
            strcpy(arquivoGeo, argv[i + 1]);
        // passagem dos argumentos para a strigng arquivoQry
        } 
        else if (strcmp(argv[i], "-q") == 0 ) {
            arquivoQry = (char*)malloc(sizeof(char)*(strlen(argv[i + 1]) + 5));
            if(arquivoQry==NULL){
                printf("Erro na alocação de memória da string!\n");
                exit(1);
            }
            strcpy(arquivoQry, argv[i + 1]);
            existeqry = 1;
        // acoes no dirSaida
        } 
        else if (strcmp(argv[i], "-o") == 0 ) {
            dirSaida = trataDirEntrada(argv[i+1]);
        }
        else if (strcmp(argv[i], "-p") == 0) {
            prioridadeMaxima = atoi(argv[i+1]);
        }
        else if (strcmp(argv[i], "-hc") == 0) {
            hitCount = atoi(argv[i+1]);
        }
        else if (strcmp(argv[i], "-pr") == 0) {
            promotionRate = atof(argv[i+1]);
        }
    }

    char *nomegeo = getNomeGeo(arquivoGeo);
    SmuTreap smutreap;
    int maiorID = 0;

    if(existegeo){
        char* entradageo = (char*)malloc(sizeof(char)*(strlen(dirEntrada)+strlen(arquivoGeo)+2));
        if(!entradageo) exit(1);
        entradageo[0] = '\0';
        strcat(entradageo, dirEntrada);
        strcat(entradageo, arquivoGeo);
        smutreap = ProcessaGeo(entradageo, dirSaida, nomegeo, &hitCount, &promotionRate, &prioridadeMaxima, &maiorID);
    } else{
        smutreap = ProcessaGeo(arquivoGeo, dirSaida, nomegeo, &hitCount, &promotionRate, &prioridadeMaxima, &maiorID);
    }


    if(existeqry) {
        char* nomearqsaida = concatenaNomeQry(nomegeo, getNomeQry(arquivoQry));
        ProcessaQry(dirEntrada, dirSaida, nomearqsaida, arquivoQry, smutreap, &maiorID);
    }
    
    killSmuTreap(smutreap);

    return 0;
}